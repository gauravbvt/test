package com.mindalliance.channels.matching

import net.didion.jwnl.dictionary.Dictionary
import net.didion.jwnl.JWNL
import edu.stanford.nlp.tagger.maxent.MaxentTagger

// TODO -- GPL

import edu.stanford.nlp.ling.HasWord
import edu.stanford.nlp.ling.HasTag
import net.didion.jwnl.data.Synset
import net.didion.jwnl.dictionary.MorphologicalProcessor
import net.didion.jwnl.data.IndexWord
import net.didion.jwnl.data.POS
import shef.nlp.wordnet.similarity.SimilarityMeasure

// TODO -- GPL

import edu.stanford.nlp.ling.TaggedWord
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.util.ChannelsApplication

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 15, 2008
 * Time: 7:14:23 PM
 */
class SemanticMatcher {

    static final double POWER = 0.6 // between 0 and 1, lower value lifts asymptotic scoring curve more
    static final double BEST_MATCH_FACTOR = 1.0 // how much weight to give best match vs average match (1.0 -> 1/2, 2.0 -> 2/3 etc.)

    static final String TAGGER_TRAINED_DATA = 'data/wsj3t0-18-bidirectional/train-wsj-0-18.holder'
    static final String JWNL_PROPERTIES = 'jwnl_properties.xml'
    static final String SIMILARITY_DATA = 'ic-bnc-resnik-add1.dat'

    static SemanticMatcher instance  // singleton

    private Dictionary dictionary
    private MaxentTagger tagger
    private MorphologicalProcessor morpher
    private SimilarityMeasure similarityMeasure
    private Logger logger

    static SemanticMatcher getInstance() {
        if (!instance) {
            instance = new SemanticMatcher()
            initializeJWNL()
            instance.dictionary = Dictionary.getInstance()
            instance.morpher = instance.dictionary.morphologicalProcessor
            instance.tagger = new MaxentTagger(getTrainedData())
            instance.similarityMeasure = initializeSimilarityMeasure()
            instance.logger = LoggerFactory.getLogger(instance.class)
        }
        return instance
    }

    private static String getTrainedData() {
        return ChannelsApplication.get().servletContext.getInitParameter("trained-data") ?: 'data/wsj3t0-18-bidirectional/train-wsj-0-18.holder'
    }

    static initializeJWNL() {
        JWNL.initialize(getJWNLProperties())
    }

    private static InputStream getJWNLProperties() {
        URL url = SemanticMatcher.class.getResource("jwnl_properties.xml")
        String dict = ChannelsApplication.get().servletContext.getInitParameter("wordnet-data") ?: 'data/wordnet-2.0/dict'
//        String dict = "./data/wordnet-2.0/dict"
        String template = url.text.replaceFirst("_WORDNET_DICT_", dict)

        return new ByteArrayInputStream(template.bytes);
    }

    static SimilarityMeasure initializeSimilarityMeasure() {
        // return SimilarityMeasure.newInstance([simType: "shef.nlp.wordnet.similarity.JCn", infocontent: SIMILARITY_DATA])
        URL url = SemanticMatcher.class.getResource(SIMILARITY_DATA)
        SimilarityMeasure sm = (SimilarityMeasure) SimilarityMeasure.newInstance([simType: "shef.nlp.wordnet.similarity.JCn", infocontent: url.toExternalForm()])
        return sm
    }

    static boolean matches(String text, String otherText, Level minLevel) {
        Level level = getInstance().semanticProximity(text, otherText)
        return level >= minLevel
    }

    static Level bestMatch(List<String> strings, String string) {
        Level max = Level.NONE
        strings.each {s ->
            Level level = semanticProximity(string, s)
            if (level > max) max = level
        }
        return max
    }

    Level semanticProximity(String text, String otherText) {
        if (text.trim().size() == 0 || otherText.trim().size() == 0) return Level.NONE
        logger.debug("==== Matching: [$text] and [$otherText]")
        // Do POS analysis on each text
        List words = posAnalyze(text)
        List otherWords = posAnalyze(otherText)
        // Get the synsets for the common nouns in each text
        double conceptualSimilarity = computeSynsetsSimilarity(extractPhrases(words),
                extractPhrases(otherWords))
        logger.debug("Conceptual similarity = $conceptualSimilarity")
        // Calculate shared proper noun ratio between texts
        double instanceOverlap = computeInstanceOverlap(extractProperNouns(words),
                extractProperNouns(otherWords))
        // Combine both measures into a proximity rating
        logger.debug("Instance overlap = $instanceOverlap")
        double score = conceptualSimilarity
        if (instanceOverlap) {// instance overlap is a big deal
            double boost = conceptualSimilarity * instanceOverlap
            logger.debug("$boost : boost from instance overlap = conceptualSimilarity * instanceOverlap")
            score = minimum(1.0, score + boost)
        }
        score = Math.pow(score, POWER) // to lift the curve
        Level matchingLevel = matchingLevel(score)
        logger.debug("---- Match is ${matchingLevel}")
        return matchingLevel
    }

    private Level matchingLevel(double score) {
        if (score > 1.0) throw new Exception("Illegal matching score")
        if (score > 0.75) return Level.VERY_HIGH
        if (score > 0.5) return Level.HIGH
        if (score > 0.25) return Level.MEDIUM
        if (score > 0) return Level.LOW
        else return Level.NONE
    }

    private List<HasWord> posAnalyze(String text) {
        logger.debug("POS analysis: [$text]")
        List sentences = tagger.tokenizeText(new StringReader(text))
        sentences = tagger.process(sentences)
        List<HasWord> words = []
        sentences.each {sentence ->
            sentence.each {word ->
                words.add(word)
            }
        }
        return words
    }

    // Collect all individual nouns or verbs, all adjective + noun phrases, and all noun + noun phrases
    private List<HasWord> extractPhrases(List<HasWord> words) {
        Set<HasWord> phrases = new HashSet<HasWord>()
        String phrase = ""
        words.each {word ->
            if (isVerb(word)) {
                logger.debug("Found phrase [$word]")
                phrases.add(word)
                phrase = "" // reset phrase
            }
            else if (isAdjective(word)) {
                phrase = word.value() // start a new phrase with it
            }
            else if (isCommonNoun(word)) {
                logger.debug("Found phrase [$word]")
                phrases.add(word)
                if (phrase.size() > 0) {
                    phrase += " ${word.value()}"
                    TaggedWord taggedWord = new TaggedWord(phrase, (String) word.tag())
                    logger.debug("Found phrase [$taggedWord]")
                    phrases.add(taggedWord)
                    phrase = ""
                }
                else {
                    phrase = word.value() // start a new phrase with it
                }
            }
            else {
                phrase = "" // reset the phrase
            }

        }
        return phrases as List<HasWord>
    }

    private List<String> extractProperNouns(List<HasWord> words) {
        Set<String> properNouns = new HashSet<String>()
        String composed = ""
        words.each {word ->
            if (isProperNoun(word)) {
                if (composed.size() > 0) composed += " "
                composed += "${word.value()}"
            }
            else {
                if (composed.size() > 0) {
                    properNouns.add(composed)
                    logger.debug("Proper noun [$composed]")
                    composed = "" // reset composed
                }
            }
        }
        if (composed) {
            properNouns.add(composed)
            logger.debug("Proper noun [$composed]")
        }
        return properNouns as List<String>
    }

    private boolean isCommonNoun(HasWord word) {
        return word instanceof HasTag && ['NN', 'NNS'].contains(word.tag())
    }

    private boolean isVerb(HasWord word) {
        return word instanceof HasTag && ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ'].contains(word.tag())
    }

    private boolean isAdjective(HasWord word) {
        return word instanceof HasTag && ['JJ'].contains(word.tag())
    }

    private boolean isProperNoun(HasWord word) {
        return word instanceof HasTag && ['NNP', 'NNPS'].contains(word.tag())
    }

    private double computeSynsetsSimilarity(List words, List otherWords) {
        List<Synset> synsets = findSynsets(words)
        List<Synset> otherSynsets = findSynsets(otherWords)
        double sim1 = computeCombinedSimilarity(synsets, otherSynsets)
        double sim2 = computeCombinedSimilarity(otherSynsets, synsets)
        return (sim1 + sim2) / 2.0
    }

    private List<Synset> findSynsets(List<HasWord> words) {
        List<Synset> synsets = []  // should be a set of synsets, not a list
        words.each {word ->
            POS pos = posOf(word)
            IndexWord indexWord = morpher.lookupBaseForm(pos, word.value())
            if (indexWord) {
                indexWord.synsetOffsets.each {offset ->
                    Synset synset = dictionary.getSynsetAt(pos, offset)
                    if (!synsets.any {it.offset == synset.offset}) {
                        synsets.add(synset)
                        logger.debug("[$word] => $synset")
                    }
                }
            }
        }
        return synsets
    }

    private POS posOf(HasWord word) {
        if (isCommonNoun(word)) return POS.NOUN
        else if (isVerb(word)) return POS.VERB
        else throw new IllegalArgumentException("No recognized POS for $word")
    }

    private double computeCombinedSimilarity(List<Synset> synsets, List<Synset> otherSynsets) {
        if (!synsets || !otherSynsets) return 0.0
        List similarities = []
        double overallBest = 0.0
        synsets.each {synset ->
            double best = 0.0
            otherSynsets.each {otherSynset ->
                best = maximum(best, similarity(synset, otherSynset))
            }
            logger.debug("$best is best match score for $synset")
            similarities.add(best)
            overallBest = maximum(overallBest, best)
        }
        logger.debug("$overallBest for overall best match")
        double sum = 0.0
        similarities.each {sum += it}
        double average = sum / similarities.size()
        logger.debug("$average for average best match in ${similarities.size()}")
        double score = ((BEST_MATCH_FACTOR * overallBest) + average) / (1 + BEST_MATCH_FACTOR)
        return score
    }

    private double maximum(double x, double y) {
        return (x > y) ? x : y
    }

    private double minimum(double x, double y) {
        return (x < y) ? x : y
    }

    private double similarity(Synset synset, Synset otherSynset) {
        if (synset.offset == otherSynset.offset) return 1.0
        double similarity = similarityMeasure.getSimilarity(synset, otherSynset)
        similarity = minimum(1.0, similarity) // cap it at 1.0
        logger.debug("Similarity = $similarity for $synset and $otherSynset")
        return similarity
    }

    private double computeInstanceOverlap(List<String> properNouns, List<String> otherProperNouns) {
        List<String> shared = (List<String>) properNouns.intersect(otherProperNouns)
        int minSampleSize = minimum(properNouns.size(), otherProperNouns.size())
        double score = (minSampleSize) ? (shared.size() / minSampleSize) as double : 0.0
        return score
    }
/*
Calculating the semantic proximity between strings A and B
==========================================================

-- Two strings are compared for semantic proximity and a fuzzy measure is returned (none, low, medium, high, very high or highest)

If the strings are identical, return HIGHEST
If any string is empty, return NONE

Find phrases in each string
  tokenize into parts-of-speech (POS set)
  extract phrases from POS set (phrase = noun, verb, adjective + noun or noun + noun)

Calculate synsets similarity between the phrases in A and the phrases in B

  find all unique synsets for the phrases in each string
    for each phrase
      lookup its canonical form
      lookup the Wordnet synsets, if any, for the canonical form

  measure the proximity synsets of A to the synsets of B
      for each synset of A
        find the highest proximity measure (Jiang and Conrath) with a synset in B
      find the overall best match of any synset in A with a synset in B
      calculate the average of all best matches of synsets in A siwht a synset in B
      proximity of A to B = (K * overall_best) / (1 + K) --- where K is tuned to 1

  measure the proximity synsets of B to the synsets of A
    ...

  average of the two proximity measures => CONCEPTUAL_SIMILARITY

Calculate the shared proper noun ratio between POS sets of A and B
  for each string
    extract the list (composed) proper nouns
  calculate how many are in both strings
  size of overlap / size of smallest POS set => INSTANCE_OVERLAP

Combine both measures into a semantic proximity rating
  OVERLAP_BOOST = CONCEPTUAL_SIMILARITY * INSTANCE_OVERLAP
  SCORE = min(1.0, CONCEPTUAL_SIMILARITY + OVERLAP_BOOST) ^ P -- where P is between 0 and 1 and tuned to 0.6

Convert score to fuzzy measure
  > 0.75  => VERY_HIGH
  > 0.5   => HIGH
  > 0.25  => MEDIUM
  > 0     => LOW
  = 0     => NONE

     */

}