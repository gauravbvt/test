package com.mindalliance.channels.ifm.vocabulary

import com.mindalliance.channels.ifm.ContainedElement
import com.mindalliance.channels.ifm.Conceptual
import com.mindalliance.channels.ifm.project.InProject
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 9:46:51 PM
 */
abstract class Category extends ContainedElement implements Conceptual, InProject {

    String name = ''
    String description = ''
    List<Ref> narrowed = []

    boolean isDefined() {
        return super.isDefined() && name
    }

    public boolean implies(Ref other) {
        return other as boolean && (this == other || ancestors().contains(other))
    }

    public void narrow(Ref other) {
        this.addNarrowed(other)
    }

    public List<Ref> ancestors() {
        List<Ref> ancestors = []
        ancestors.addAll(narrowed)
        narrowed.each {ancestors.addAll(it.ancestors())}
        return ancestors
    }

    public boolean narrows(Ref other) {
        return this.narrowed.contains(other)
    }

    public boolean broadens(Ref other) {
        return other.narrowed.contains(this.reference)
    }

}