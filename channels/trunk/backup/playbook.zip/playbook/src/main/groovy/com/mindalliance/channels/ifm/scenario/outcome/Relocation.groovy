package com.mindalliance.channels.ifm.scenario.outcome

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.location.Location

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 1:53:20 PM
 */
class Relocation extends ContextChange {  // A movable locatable element (place or resource) has a new location

    Ref locatable
    Location location = new Location()

    boolean isDefined() {
        return locatable as boolean && location.defined
    }
}