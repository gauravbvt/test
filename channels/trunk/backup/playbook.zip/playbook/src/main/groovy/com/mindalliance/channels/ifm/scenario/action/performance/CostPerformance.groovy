package com.mindalliance.channels.ifm.scenario.action.performance

import com.mindalliance.channels.ifm.Cost
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 26, 2008
 * Time: 4:00:03 PM
 */
class CostPerformance extends Performance {

    CostPerformance() {
        defaultValue = new Cost()
        minimized = true
    }

    static CostPerformance minimized() {
        return new CostPerformance(defaultValue: new Cost(), minimized: true)
    }

    static CostPerformance maximized() {
        return new CostPerformance(defaultValue: new Cost(), minimized: false)
    }

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['cost'])
    }

    Cost getCost() {
        return (Cost)defaultValue
    }

    Cost getCost(Ref resource) {
        return (Cost)getValue(resource)
    }

}