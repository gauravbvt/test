package com.mindalliance.channels.ifm

import com.mindalliance.channels.ifm.project.Project
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.util.ChannelsApplication
import com.mindalliance.channels.mem.ApplicationMemory

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Mar 19, 2008
 * Time: 2:08:19 PM
 */
class Channels extends ContainerElement {

    static final String UNNAMED = 'UNNAMED'

    List<Ref> projects = []
    List<Ref> users = []

    @Override
    protected List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['allItems', 'currentProject', 'currentScript', 'uNAMMED'])
    }

    Ref findContainer(Class c) {
        return null               // root container
    }

    void makeRoot() {
        Ref root = ApplicationMemory.getRoot()
        this.id = root.id
        this.db = root.db
    }

    static Channels instance() {
        return (Channels) ChannelsApplication.current().getChannels().deref()
    }

    static Ref reference() {   // CAUTION: this will *not* force an initial load of Channels root data
        ChannelsApplication.current().getRoot()
    }

    // Queries

    List<String> findAllProjectNamesExceptFor(Ref project) {
        return (projects - project).collect {it.name}
    }

    List<String> findAllUserIdsExceptFor(Ref user) {
        return (List<String>)(users - user).collect {it.userId}
    }

    Ref findProjectNamed(String name) {
        Ref ref = (Ref) projects.find {project -> project as boolean && project.name == name}
        return ref
    }

    Ref findUser(String uid) {
        return (Ref) users.find {user -> user as boolean && user.userId == uid}
    }

    List<Ref> findProjectsForUser(Ref user) {
        List<Ref> result = []
        projects.each {project ->
            if (project as boolean && project.isParticipant(user)) result.add(project)
        }
        return result
    }

    List<Ref> findUsersNotInProject(Ref project) {
        List<Ref> results
        results = (List<Ref>) users.findAll {user ->
            user as boolean &&
                    project.participations.every {part -> part as boolean && part.user != user}
        }
        return results
    }

    List<Ref> findAllProjectsOfUser(Ref user) {
        return (List<Ref>) projects.findAll {project -> project.participations.any {part -> part.user == user}}
    }


    // end queries

    static List adminClasses() {
        [User.class]
    }

    static List contentClasses() {
        [User.class, Project.class]
    }

    static boolean isSet(Ref ref) {  // always called in application scope
        return ref != null && (ref.isComputed() || ref.isAttached() || ChannelsApplication.current().isStored(ref))
    }
    
}