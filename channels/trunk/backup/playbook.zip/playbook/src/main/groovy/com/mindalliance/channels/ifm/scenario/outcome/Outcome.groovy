package com.mindalliance.channels.ifm.scenario.outcome

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.Timespan
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 1:39:18 PM
 */
abstract class Outcome extends BeanImpl {  // a change in a scenario's context (agentables, locatables, activatables)

    Timespan delay = new Timespan() // from start of event or end of information act

}