package com.mindalliance.channels.analysis.scenario

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 24, 2008
 * Time: 11:10:20 AM
 */
class Reality {  // all occurrences that can co-exist with a given occurrence in a scenario

    Ref occurrence

    static Reality from(Ref occurrence) {
        return new Reality(occurrence:occurrence)
    }

    List<Ref> getOccurrences() {
        Ref scenario = occurrence.scenario
        return scenario.occurrences.findAll {occ ->
            occ == occurrence ||
            (Plan.compatible(occurrence, occ) &&             // one occurrence's plan includes the other's
            Timeline.compatible(occurrence, occ))           // no contingency conflict in occurrences' timelines
        }
    }

}