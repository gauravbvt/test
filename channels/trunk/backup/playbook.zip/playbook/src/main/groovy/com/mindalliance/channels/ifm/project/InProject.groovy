package com.mindalliance.channels.ifm.project

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.Referenced

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jul 19, 2008
 * Time: 9:45:58 AM
 */
interface InProject extends Referenced {   // element *can* be in a project

    Ref getProject()

}