package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.resource.organization.Organization
import com.mindalliance.channels.matching.TagAnalyst
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.ifm.Defineable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 8:53:42 PM
 */
class OrganizationDefinition extends Definition {

    List<TagSet> tagSets = [] // ORed TagSets (the tags in each TagSet are ANDed) -- classification
    OrganizationSpecification parentOrganizationSpec = new OrganizationSpecification()  // spec of a parent organization (or the parent's parent etc.)
    LocationDefinition locationSpec = new LocationDefinition() // where the organization is located
    LocationDefinition jurisdictionSpec = new LocationDefinition() // the jurisdiction of the organization

    Class<? extends Defineable> getMatchingDomainClass() {
        return Organization.class
    }

    boolean matchesAll() {
        return !TagAnalyst.tagSetsDefined(tagSets) && parentOrganizationSpec.matchesAll() && locationSpec.matchesAll() && jurisdictionSpec.matchesAll()
    }

    protected MatchResult doMatch(Defineable bean) {
        Organization organization = (Organization)bean
        Level minLevel = Level.HIGHEST
        Map<String, Object> matches = [:]
        StringBuilder summary = new StringBuilder()
        // tagSet match
        Level level = TagAnalyst.bestTagSetMatch(tagSets, organization.tags)
        summary.append("${level.confidence()} tags ok")
        // parent etc. organization
        List<Defineable> ancestors = organization.ancestors.collect {it.deref()}
        minLevel = findMatchLevel(ancestors, parentOrganizationSpec, minLevel, summary, matches)
        // location
        minLevel = findMatchLevel(organization.location, locationSpec, minLevel, summary, matches)
        // jurisdiction
        minLevel = findMatchLevel(organization.jurisdiction, jurisdictionSpec, minLevel, summary, matches)
        return new MatchResult(level: minLevel, summary: summary.toString(), matches: matches)
    }

    boolean implies(MatchingDomain matchingDomain) {
        OrganizationDefinition other = (OrganizationDefinition)matchingDomain
        if (other.matchesAll()) return true
        // all of the other's tagSets must closely match at least one of mine
        if (!TagAnalyst.implyTagSets(tagSets, other.tagSets)) return false
        if (!parentOrganizationSpec.implies(other.parentOrganizationSpec)) return false
        if (!locationSpec.implies(other.locationSpec)) return false
        if (!jurisdictionSpec.implies(other.jurisdictionSpec)) return false
        return true
    }

}
