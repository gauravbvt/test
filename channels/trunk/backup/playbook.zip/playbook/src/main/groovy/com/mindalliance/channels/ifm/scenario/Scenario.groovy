package com.mindalliance.channels.ifm.scenario

import com.mindalliance.channels.ifm.ContainerElement
import com.mindalliance.channels.ifm.project.InProject
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ref.Referenceable
import com.mindalliance.channels.mem.ApplicationMemory
import com.mindalliance.channels.mem.NoSessionCategory
import com.mindalliance.channels.ifm.Channels
import com.mindalliance.channels.ifm.scenario.action.*
import com.mindalliance.channels.support.util.CountedSet
import com.mindalliance.channels.ifm.scenario.event.Violation
import com.mindalliance.channels.ifm.scenario.event.Event

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 25, 2008
 * Time: 7:25:52 PM
 */

class Scenario extends ContainerElement implements InProject, InScenario {

    String name = Channels.UNNAMED
    String description = ''
    List<String> goals = []
    // scope
    List<ProfileExtension> profileExtensions = []
    List<Ref> groups = []  // dynamic sets of agentables defined by specification
    List<Ref> toggledActivatables = [] // activatables with default activation toggled (policy, place, media, resource)
    // Occurrences
    List<Ref> events = []
    List<Ref> tasks = []
    List<Ref> communications = []
    List<Ref> violations = []

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['occurrences', 'actions', 'eventsOrViolations'])
    }

    Set<String> keyProperties() {
        return ['name', 'description'] as Set<String>
    }


    protected List<String> childProperties() {
        return (List<String>) (super.childProperties() + ['groups', 'events', 'tasks', 'communications', 'violations'])
    }


    boolean hasOccurrence(Ref occ) {
        return occurrences.contains(occ)
    }


    Set<Class<?>> childClasses() {
        Set<Class<?>> result = new HashSet<Class<?>>();
        result.addAll(super.childClasses())

        // Events
        result.addAll([Event.class, Violation.class])

        // Information acts
        result.addAll([
                Task.class, Communication.class])
        // Groups
        result.addAll([Group.class])

        return result
    }

    /**
     * Return classes a project participant can add.
     */
    static List<Class<? extends Referenceable>> contentClasses() {
        List<Class<? extends Referenceable>> result = new ArrayList<Class<? extends Referenceable>>()
        result.addAll([Task.class, Communication.class, Group.class, Event.class, Violation.class])
        return result
    }

    void addContents(List<Ref> results) {
        results.addAll(tasks)
        results.addAll(communications)
        results.addAll(groups)
        results.addAll(events)
        results.addAll(violations)

    }

    String toString() {
        return name ?: Channels.UNNAMED
    }

    void beforeStore(ApplicationMemory memory) {
        super.beforeStore(memory)
        if (!events) {
            use(NoSessionCategory) {
                Event initialEvent = new Event(name: 'Initiating event', description: '(automatically created)')
                this.addElement(initialEvent)
                memory.store(initialEvent)
            }
        }
    }

    Ref persist() {
        super.persist()
        if (!events) {
            Event initialEvent = new Event(name: 'Initiating event', description: '(automatically created)')
            initialEvent.persist()
            this.addElement(initialEvent)
            initialEvent.persist()
        }
        return this.reference
    }


    List<Ref> getOccurrences() {
        return (List<Ref>) (events + actions)
    }

    List<Ref> getActions() {
        return (List<Ref>) (tasks + communications)
    }

    List<Ref> getEventsOrViolations() {
        return (List<Ref>)(events + violations)
    }



    // QUERIES       -- TODO : Review queries

    List<Ref> findAllAgentables() {
        return (List<Ref>) (groups + project.findAllAgentables())
    }

    List<String> findAllInformationTagsForEvent(Ref event) {
        CountedSet countedSet = new CountedSet();
        if (event as boolean) {
            findAllInformationAbout(event).each {info ->
                if (info.tag) countedSet.add(info.tag)
            }
        }
        return countedSet.toList()
    }

    List<Ref> findActionsOfType(String type) {
        return (List<Ref>) actions.findAll {act -> act as boolean && act.type == type}
    }

    List<Ref> findAllLocatables() {
        List<Ref> locatables = []
        locatables.addAll(events)
        locatables.addAll(project.findAllLocatables())
        return locatables
    }



/*    List<Ref> findCandidatePriors(Ref occurrence) {
        return occurrences - occurrence
    }

    List<Ref> findPriorActions(Ref event, String type) {
        return (List<Ref>) actions.findAll {act ->
            act as boolean && act.type == type && event.isAfter(act)
        }
    }

    List<Ref> findPriorActionsOfType(String type, Ref event) {
        return (List<Ref>) actions.findAll {act -> act as boolean && act.type == type && !act.isAfter(event)}
    }

    Ref findEventNamed(String name) {
        return (Ref) events.find {event -> event as boolean && event.name == name}
    }

    List<Ref> findAllAgentablesExcept(def holder, String propPath) {
        List<Ref> agents = findAllAgentables()
        List<Ref> except = (List<Ref>) ([] + RefUtils.get(holder, propPath))    // works with Objects that are not Lists
        agents.removeAll(except)
        return agents
    }


    List<Ref> findAllOccurrences() {
        return occurrences
    }

    List<Ref> findAllOccurrencesExcept(Ref occurrence) {
        return occurrences - occurrence
    }

    List<Ref> findAllActionsForAgent(Ref agent) {
        return (List<Ref>) actions.findAll {act ->
            act as boolean && agent as boolean &&
                    ((act.actor == agent) || (act.isFlowAct() && act.targetAgent == agent))
        }
    }

    // Find all topics that are used or apply to an event based on information acts with information about it
    List<String> findAllTopicsUsedInActionsAbout(Ref event) {
        TreeSet<String> topics = new TreeSet<String>()
        actions.each {ref ->
            if (ref as boolean) {
                Action act = (Action) ref.deref()
                if (act.hasInformation() && act.information.event == event) { // act has information about the event
                    act.information.eois.each {eoi ->
                        topics.add(eoi.topic)                     // topics used
                    }
                    act.information.eventTypes.each {et ->
                        topics.addAll(et.allTopics())                 // topics from assigned eventTypes
                    }
                }
            }
        }
        return topics as List
    }


    List<Ref> findAllPriorOccurrencesOf(Ref occurrence) {
        return (List<Ref>) this.occurrences.findAll {occ ->
            occ as boolean && occurrence.isAfter(occ)
        }
    }

    List<Ref> findAllJurisdictionables() {
        return (List<Ref>) findAllAgentables().findAll {agent -> agent.hasJurisdiction()}
    }

    List<Ref> findAllAgentablesLocatedInPlacesOfTypeImplying(Ref placeType) {
        return (List<Ref>) findAllAgentables().findAll {agent ->
            agent.hasLocation() && agent.location.isAPlace() && agent.location.place.placeType as boolean && agent.location.place.placeType.implies(placeType)
        }
    }

    List<Ref> findAllAgentablesWithJurisdictionsInPlacesOfTypeImplying(Ref placeType) {
        return (List<Ref>) findAllAgentables().findAll {agent ->
            agent.hasJurisdiction() && agent.jurisdiction.isAPlace() && agent.jurisdiction.place.placeType as boolean && agent.jurisdiction.place.placeType.implies(placeType)
        }
    }

    List<Ref> findAllAgentablesLocatedInAreasOfTypeImplying(Ref areaType) {
        return (List<Ref>) findAllAgentables().findAll {agent -> agent.hasLocation() && (geoLoc = agent.location.effectiveGeoLocation) && geoLoc.isDefined() && geoLoc.areaType.implies(areaType)}
    }

    List<Ref> findAllAgentablesWithJurisdictionsInAreasOfTypeImplying(Ref areaType) {
        return (List<Ref>) findAllAgentables().findAll {agent -> agent.hasJurisdiction() && (geoLoc = agent.jurisdiction.effectiveGeoLocation) && geoLoc.isDefined() && geoLoc.areaType.implies(areaType)}
    }*/

    // end queries

}