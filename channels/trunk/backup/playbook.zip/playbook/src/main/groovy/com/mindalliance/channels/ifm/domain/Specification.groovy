package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ref.Referenceable
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.util.RefUtils
import com.mindalliance.channels.ifm.Defineable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 9:38:48 AM

 A matching domain defined by extension (enumeration of Referenceables) and/or intension (alternate definitions)

 When negated:
    Succeeding =
        specification does not match all (it is not the universal set),
        and the enumeration does not contain (reference to) the bean tested for inclusion,
        and no description matches the bean well

 When affirmed:
    Succeeding =
        specification matches all (it is the universal set),
        or the enumeration contains (a reference to) to bean for inclusion,
        or at least one description matches the bean well

*/
abstract class Specification extends MatchingDomain {

    String description  = '' // a brief description of the specification
    boolean negated = false  // if negated, the matching domain is the complement of the specification
    List<Ref> enumeration = []   // specification by enumeration
    List<Definition> definitions = [] // OR by definitions (ORed)

    abstract Class<? extends Defineable> getMatchingDomainClass()

    String toString() {
        return "${this.class.name}: $description"
    }

    String getLabel() {
        return RefUtils.deCamelCase(RefUtils.shortClassName(this)).split(' ')[0]
    }

    // BEANIMPL

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() +
                                ['enumerable', 'enumerated', 'defined', 'matchingDomainClass', 'label'])
    }


    boolean isDefined() {
        return true
    }

    String about() {
        StringBuilder sb = new StringBuilder()
        sb.append("any of ")
        enumeration.each {ref ->
            if (ref as boolean) {
                sb.append(ref.deref().about())
                sb.append(' ')
            }
        }
        definitions.each {d ->
            sb.append("$d ")
        }
        return sb.toString().trim()
    }

    // end BEANIMPL


    // MATCHING DOMAIN

    boolean matchesAll() {  // undefined matches any instance of instance class
        return !isEnumerated() && !hasDefinitions() && !negated
    }

    // Match bean as of start of information act
    MatchResult match(Defineable bean) {
        assert bean as boolean && bean.isDefined() // never attempt matching undefined beans (they are inoperative)
        if (!this.matchingDomainClass.isAssignableFrom(bean.class))
            throw new IllegalArgumentException("Can't match bean: expecting a ${this.matchingDomainClass.name}")
        if (negated)
            return matchNegated(bean)
        else
            return matchAffirmed(bean)
    }

    boolean matches(Defineable bean, Level level) {
        MatchResult result = match(bean)
        return result.level >= level;
    }
    
    // A narrows B if and only if any instance matching A also matches B (A defines an equal or smaller matching domain)
    // iow: A's matching domain is a subset of B's matching domain
    boolean implies(MatchingDomain matchingDomain) {
        if (matchingDomain.class != this.class) throw new IllegalArgumentException("Expecting a ${this.class.name}")
        Specification specification = (Specification)matchingDomain
        if (matchesAll() && specification.matchesAll()) return true // both define a universal matching domain
        if (negated != specification.negated) return false
        if (negated)
            return impliesNegated(specification)
        else
            return impliesAffirmed(specification)
    }

    // END DEFINITION

    boolean isEnumerated() {
        return !enumeration.isEmpty()
    }

    boolean hasDefinitions() {
       return definitions.any { it.isDefined() }
    }

    // PRIVATE

    private MatchResult matchAffirmed(Defineable bean) {
        if (matchesAll()) return new MatchResult(matched: Level.HIGHEST, summary:'Anything matches')
        if (isEnumerated())  {
          if  (enumeration.contains(((Referenceable)bean).reference))
                    return new MatchResult(matched:Level.HIGHEST, summary: "$bean one of the listed elements")
        }
        if (hasDefinitions()) {
            Level max = Level.NONE
            MatchResult bestMatch = null
            Definition bestDefinition = null
            Map<String, MatchResult> matches = [:]
            definitions.each {d ->
                MatchResult result = d.match(bean)
                matches["$d"] = result
                if (result.level > max) {
                    max = result.level
                    bestMatch = result
                    bestDefinition = d
                }
            }
            MatchResult result = new MatchResult(level:max, summary:"${max.confidence()} of matching '$bestDefinition'", matches: matches)
            return result
        }
        return new MatchResult(matched: Level.NONE, summary: "No match")
    }

    private MatchResult matchNegated(Defineable bean) {
        if (matchesAll()) return new MatchResult(level: Level.NONE, summary: "Nothing can possibly match")
        if (isEnumerated())  { // if bean referenced -> failure
            if  (enumeration.contains(((Referenceable)bean).reference))
                return new MatchResult(level:Level.NONE, summary: "$bean found in exception list")
        }
        if (hasDefinitions()) { // if bean matches a definition -> failure
            if (hasDefinitions()) {
                Level max = Level.NONE
                MatchResult bestMatch = null
                Definition bestDefinition = null
                Map<String, MatchResult> matches = [:]
                definitions.each {d ->
                    MatchResult result = d.match(bean)
                    matches["$d"] = result
                    if (result.level > max) {
                        max = result.level
                        bestMatch = result
                        bestDefinition = d
                    }
                }
                MatchResult result = new MatchResult(level:max.opposite(), summary:"${max.confidence()} of matching exception '$bestDefinition'", matches: matches)
                return result
            }
        }
        return new MatchResult(matched: Level.HIGHEST, successes:["No exception matched"])
    }

    /*
        (not A) subset of (not B) <=> B subset A
    */
    private boolean impliesNegated(Specification specification) {
        return specification.impliesAffirmed(this)
    }

    /*
        This specification narrows other specification if
            enumeration is a subset
            AND all definitions narrow one of the other specification's descriptions
            (the described matching domain is a subset of specification's described matching domain)
     */
    private boolean impliesAffirmed(Specification specification) {
        if (specification.matchesAll()) return true // specification "defines" a universal matching domain
        if (!enumeration.minus(specification.enumeration).isEmpty()) return false // if narrowing specification's enumeration is not a subset, then it is not narrowing
        if (!definitions.every {d -> specification.definitions.any {other -> d.implies(other)}}) return false
        return true
    }

}