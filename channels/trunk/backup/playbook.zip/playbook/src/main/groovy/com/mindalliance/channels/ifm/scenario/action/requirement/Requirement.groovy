package com.mindalliance.channels.ifm.scenario.action.requirement

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.Probability
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 12:52:45 PM
 */
abstract class Requirement extends BeanImpl {    // Something required of the actor of an information act

    // Action can't start until 100% critical requirement met
    // Else missed requirement impacts probability of success
    Probability criticality = new Probability(value:100) // probability of failure of act if requirement not met

}