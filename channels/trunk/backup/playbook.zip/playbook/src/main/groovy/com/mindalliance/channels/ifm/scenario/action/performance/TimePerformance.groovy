package com.mindalliance.channels.ifm.scenario.action.performance

import com.mindalliance.channels.ifm.Timespan
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 26, 2008
 * Time: 3:22:43 PM
 */
class TimePerformance extends Performance {

    TimePerformance() {
        defaultValue = new Timespan(amount:0)
        minimized = true
    }

    static TimePerformance minimized() {
        return new TimePerformance(defaultValue: new Timespan(amount:0), minimized: true )
    }

    static TimePerformance maximized() {
        return new TimePerformance(defaultValue: new Timespan(amount:0), minimized: false )
    }

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['timespan'])
    }
    
    Timespan getTimespan() {
        return (Timespan)defaultValue
    }

    Timespan getTimespan(Ref resource) {
        return (Timespan)getValue(resource)
    }
}