package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ifm.domain.FactDefinition
import com.mindalliance.channels.ifm.domain.InformationDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 3, 2008
 * Time: 8:12:50 PM
 */
class InformationSource extends Information { // about a source of information (be it knowledge, commands, sharing authorizations, information sources, information needs ...)

    Ref resource   // who is a source  -- an agenteable
    InformationDefinition informationSpec = new FactDefinition()  // for what kind of information

    boolean isDefined() {
        return super.defined && resource as boolean && informationSpec.isDefined()
    }

    String toString() {
        return "Source for ${informationSpec.description}"
    }

    public String makeLabel(int maxWidth) {
        // TODO
    }
}