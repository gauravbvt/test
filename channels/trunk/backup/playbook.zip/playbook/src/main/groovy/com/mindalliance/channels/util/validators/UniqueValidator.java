package com.mindalliance.channels.util.validators;

import com.mindalliance.channels.query.Query;
import org.apache.wicket.validation.validator.AbstractValidator;
import org.apache.wicket.validation.IValidatable;

import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 8, 2008
 * Time: 10:13:25 AM
 */
public class UniqueValidator  extends AbstractValidator {   // validate that X is not in the result set of a query


        private Object target;  // target of query
        private Query query;

        public UniqueValidator(Object target, Query query) {
            this.target = target;
            this.query = query;
        }

        @Override
        protected String resourceKey() {
            return "Unique";
        }

        protected void onValidate(IValidatable validatable) {
            Object item = validatable.getValue();
            List results = (List) query.execute(target);
            if (!isUnique(item, results)) {
                error(validatable);
            }
        }

        private boolean isUnique(Object item, List results) {
            for (Object result : results) {
               if (result instanceof String) {
                   if (((String)item).equalsIgnoreCase((String)result)) {
                       return false;
                   }
               }
               else {
                   if (result == item) {
                       return false;
                   }
               }
            }
            return true;
        }

    public static UniqueValidator inQuery(Object target, Query query) {
        return new UniqueValidator(target, query);
    }


}
