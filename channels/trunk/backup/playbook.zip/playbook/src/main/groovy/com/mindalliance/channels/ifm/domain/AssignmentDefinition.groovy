package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ifm.information.Assignment

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 2, 2008
 * Time: 9:37:08 AM
 */
class AssignmentDefinition extends InformationDefinition {

    MatchResult doSpecificMatch(Information information, Level level, StringBuilder summary, Map<String, Object> matches) {
        return null  //Todo
    }

    Class<? extends Defineable> getMatchingDomainClass() {
        return Assignment.class
    }

}