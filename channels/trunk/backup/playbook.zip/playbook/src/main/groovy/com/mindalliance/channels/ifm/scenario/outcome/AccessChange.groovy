package com.mindalliance.channels.ifm.scenario.outcome

import com.mindalliance.channels.ifm.resource.AccessRight
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 2:00:17 PM
 */
class AccessChange extends ContextChange { // Change to the access rights of a resource

    Ref resource
    boolean added = true    // else removed
    AccessRight accessRight = new AccessRight()

    boolean isDefined() {
        return resource as boolean && accessRight.defined
    }
    
}