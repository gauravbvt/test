package com.mindalliance.channels.graph.support

import com.mindalliance.channels.query.Query
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ref.impl.AbstractReferenceableImpl
import com.mindalliance.channels.ref.impl.ComputedRef

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jul 28, 2008
 * Time: 1:31:45 PM
 */
class Networking extends AbstractReferenceableImpl {  // scope is the resource's project

    Ref resource
    Ref otherResource

    private int cachedSize = -1

    static Networking makeNetworking(Ref resource, Ref otherResource) {
        return new Networking(resource: resource, otherResource: otherResource)
    }

    boolean isDefined() {
        return resource as boolean && otherResource as boolean
    }

    Ref getReference() {
       return new ComputedRef(getId())
    }

    List<Ref> getRelationships() {
        return (List<Ref>) resource.project.relationships.findAll {rel -> (rel.fromResource == resource && rel.toResource == otherResource) ||
                                                                              (rel.fromResource == otherResource && rel.toResource == resource) }
    }

    List<Ref> getAgreements() {
        List<Ref> agreements = (List<Ref>)Query.execute(resource.project, "findAllAgreementsBetween", resource, otherResource)
        agreements += (List<Ref>)Query.execute(resource.project, "findAllAgreementsBetween", otherResource, resource)
        return agreements
    }

    List<Ref> getFlowActs() {
        List<Ref> acts = (List<Ref>) Query.execute(resource.project, "findAllCommunicationsBetween", resource, otherResource)
        acts += (List<Ref>) Query.execute(resource.project, "findAllCommunicationsBetween", otherResource, resource)
        return acts
    }

    int size() {
        if (cachedSize == -1) {
            int count = 0
            List<Ref> rels = this.relationships
            count += rels.size()
            List<Ref> agrs = this.agreements
            count += agrs.size()
            List<Ref> fas = this.flowActs
            count += fas.size()
            if (resource.hasAccessTo(otherResource)) count++
            if (otherResource.hasAccessTo(resource)) count++
            if (resource.hasJobWith(otherResource)) count++
            if (otherResource.hasJobWith(resource)) count++
            cachedSize = count
        }
        return cachedSize
    }

   public boolean isConstant() {
        return true;
    }

    public String makeLabel(int maxWidth) {
        return "${size()}";
    }

    public String about() {
        return "Networking between ${resource.about()} and ${otherResource.about()}";
    }

    public String getId() {
        return "${this.class.name},makeNetworking,$resource,$otherResource";
    }
}