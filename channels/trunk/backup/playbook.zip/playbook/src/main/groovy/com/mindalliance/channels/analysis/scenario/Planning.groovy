package com.mindalliance.channels.analysis.scenario

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 24, 2008
 * Time: 11:23:57 AM
 */
class Planning {   // the plans that compose a scenario

    Ref scenario

    static Planning from(Ref scenario) {
        return new Planning(scenario: scenario)
    }

    List<Plan> getRootPlans() {
        return [] // TODO
    }

}