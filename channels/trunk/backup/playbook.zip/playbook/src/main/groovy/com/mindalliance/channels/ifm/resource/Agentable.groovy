package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.responsibility.Responsibility
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ifm.Named
import com.mindalliance.channels.ifm.Described
import com.mindalliance.channels.ifm.Locatable
import com.mindalliance.channels.Identified
import com.mindalliance.channels.ifm.Referenced
import com.mindalliance.channels.ifm.Accessible
import com.mindalliance.channels.ifm.Relatable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 14, 2008
 * Time: 8:11:48 PM
 */

// Can be converted into an Agent (with a dynamic profile queryable as of a given information act)
interface Agentable extends Referenced, Defineable, Named, Described, Locatable, Accessible, Relatable {
    // and responsible
    List<Ref> getRoles()
    List<Responsibility> getResponsibilities()
    boolean hasRole(Ref role)

}