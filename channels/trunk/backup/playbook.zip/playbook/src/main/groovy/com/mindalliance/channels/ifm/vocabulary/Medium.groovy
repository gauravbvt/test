package com.mindalliance.channels.ifm.vocabulary

import com.mindalliance.channels.ifm.*
import com.mindalliance.channels.ifm.domain.AgentSpecification
import com.mindalliance.channels.ifm.project.InProject
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.support.Level

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 25, 2008
 * Time: 3:28:11 PM
 */
class Medium extends ContainedElement implements Named, Described, Activatable, InProject {   // Communication medium

    String name = ''
    String description = ''
    TagSet tags = new TagSet()
    boolean activated = true   // activated by default
    AgentSpecification broadcastsTo = null // null => no broadcast, undefined AgentSpecification  = broadcasts to all
    Timespan minDelay = new Timespan(amount:0)  // minimal communication delay (sets lower bound on Communication duration)
    Probability reliability = new Probability() // probability that a communication will succeed using this medium if effective
    Level security = Level.NONE
    List<Ref> interoperableWith = [] // other communication media
    TagSet formats = new TagSet() // formats it can transmit

    @Override
    protected List transientProperties() {
        return (List<String>) (super.transientProperties() + ['broadcastMedium'])
    }

    Set keyProperties() {
        return (super.keyProperties() + ['name', 'description', 'tags']) as Set
    }

    boolean isDefined() {
        return name && tags.isDefined()
    }

    boolean isBroadcastMedium() {
        return broadcastsTo != null
    }

}