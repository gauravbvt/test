package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.query.Query
import org.apache.commons.collections.CollectionUtils
import com.mindalliance.channels.ifm.Jurisdictionable
import com.mindalliance.channels.mem.ApplicationMemory
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.resource.organization.InOrganization
import com.mindalliance.channels.ifm.responsibility.Responsibility

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 11:21:56 AM
*/
class Position extends AbstractResource implements InOrganization, Agentable, Jurisdictionable {

    Location jurisdiction = new Location()
    List<Ref> roles = []           // assigned roles
    List<Responsibility> responsibilities = []   // ad hoc responsibilities (not per roles)
    List<Ref> adminPositions = []  // who manages the position

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['responsibilities'])
    }

    void beforeStore(ApplicationMemory memory) {
        super.beforeStore(memory)
        if (jurisdiction.isDefined()) jurisdiction.detach()
    }

    boolean isDefined() {
        return super.isDefined() && roles
    }

    boolean isLocatedWithin(Location loc) {
        return super.isLocatedWithin(loc) || jurisdiction.isWithin(loc)
    }

    boolean hasJurisdiction() {
        return jurisdiction.isDefined()
    }

    boolean hasRole(Ref role) {
        return (this.roles.any {resRole -> resRole.implies(role) })
    }

    List<Responsibility> getResponsibilities() {
        List<Responsibility> allResponsibilities = []
        getRoles().each {role -> if (role as boolean) allResponsibilities.addAll(role.responsibilities)}
        return allResponsibilities
    }

    // Queries

    List<Ref> findOtherPositionsInOrganization(List<Ref> positions) {
        List<Ref> otherPositions = new ArrayList<Ref>()
        if (organization != null) {
            List<Ref> allPositions = (List<Ref>)Query.execute(organization, "findAllPositions");
            otherPositions.addAll(CollectionUtils.subtract(allPositions, positions))
        }
        return otherPositions
    }

    List<Ref> findAllInPosition() {
        return (List<Ref>)organization.jobs.findAll{job -> job.position == this.reference}
    }

    // End queries

}