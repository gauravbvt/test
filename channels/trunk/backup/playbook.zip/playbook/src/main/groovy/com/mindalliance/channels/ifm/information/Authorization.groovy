package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.domain.ActionDefinition
import com.mindalliance.channels.ifm.domain.ActionDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 3, 2008
 * Time: 7:09:40 PM
 */
class Authorization extends Information {  // Authorization to carry out a specified information act

    Ref fromResource // agentable authorizing
    Ref toResource // agentable being/to be authorized
    ActionDefinition actionSpec = new ActionDefinition()

    boolean isDefined() {
       return super.defined && fromResource as boolean && toResource as boolean && !actionSpec.matchesAll()
    }

    String toString() {
        return "Authorization to do: ${actionSpec.description}"
    }

    public String makeLabel(int maxWidth) {
        // todo
    }
}