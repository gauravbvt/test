package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.impl.ReferenceableImpl
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.util.drools.RuleBaseSession
import com.mindalliance.channels.collaboration.Comment

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Mar 19, 2008
* Time: 12:36:45 PM
*/
abstract class ModelElement extends ReferenceableImpl implements Serializable {

    Date createdOn = new Date()
    Date lastModified = new Date()
    List<Comment> comments = []

    @Override
    protected List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['containerElement', 'childElement',
                                                             'elementIssues', 'elementInvalidations', 'problems'])
    }

    Set keyProperties() {
        return (super.keyProperties() + ['createdOn', 'lastModified']) as Set
    }


/*    Set hiddenProperties() {
        return (super.hiddenProperties() + ['projectElement', 'scenarioElement']) as Set
    }*/

     void changed() {
       lastModified = new Date()
       super.changed()
    }

    boolean isChildElement() {
        return false
    }

    boolean isContainerElement() {
        return false
    }

    List<Ref> getElementIssues() {
         return RuleBaseSession.current().query("elementIssues", [this.id], "_issue").collect{it.reference}
    }

    List<Ref> getElementInvalidations() {
        return RuleBaseSession.current().query("elementInvalids", [this.id], "_invalid").collect{it.reference}
    }

    List<Ref> getProblems() {
        return (List<Ref>)(getElementIssues() + getElementInvalidations())
    }

}