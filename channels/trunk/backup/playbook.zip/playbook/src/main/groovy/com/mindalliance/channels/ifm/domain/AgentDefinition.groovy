package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.analysis.scenario.agent.Agent
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ifm.vocabulary.Role
import com.mindalliance.channels.analysis.scenario.agent.AgentRelationship

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 18, 2008
 * Time: 4:19:50 PM
 */
class AgentDefinition extends Definition { // Specification of responsibilized resources

    List<Ref> roles = [] // ORed  -- with what roles? -- if list empty, don't care about roles
    OrganizationSpecification organizationSpec = new OrganizationSpecification()  // roles assigned by what kind of organization?
    LocationDefinition locationSpec = new LocationDefinition()  // located where
    LocationDefinition jurisdictionSpec = new LocationDefinition() // with what jurisdiction?
    RelationshipDefinition relationshipSpec = new RelationshipDefinition()  // ORed -- and is in a relationship matching one of these

    Class<? extends Defineable> getMatchingDomainClass() {
        return Agent.class
    }

    boolean matchesAll() {
        return roles.isEmpty() && relationshipSpec.matchesAll() && locationSpec.matchesAll() && jurisdictionSpec.matchesAll() && organizationSpec.matchesAll()
    }

    protected MatchResult doMatch(Defineable bean) {
        Agent agent = (Agent) bean
        Level minLevel = Level.HIGHEST
        Map<String, Object> matches = [:]
        StringBuilder summary = new StringBuilder()
        // Roles
        if (roles.isEmpty()) {
            matches['roles'] = 'Any role ok. '
            summary.append('Any role ok. ')
        }
        else {
            List<Role> matchingRoles = (List<Role>) agent.roles.findAll {role -> roles.any {srole -> role.implies(srole)}}
            if (matchingRoles) {  // all of the prescribed roles must be implied by at least one of the job's roles
                matches['roles'] = Level.HIGHEST   // role matching is all or none
                summary.append("Roles ${matchingRoles.name} ok. ")
            }
            else {
                matches['roles'] = Level.NONE
                return new MatchResult(level: Level.NONE, summary: "No role is ok. ", matches: matches)
            }
        }
        // Employer organization
        minLevel = findMatchLevel(agent.organization, organizationSpec, minLevel, summary, matches)
       // Location
        minLevel = findMatchLevel(agent.location, locationSpec, minLevel, summary, matches)
        // Jurisdiction
        minLevel = findMatchLevel(agent.jurisdiction, jurisdictionSpec, minLevel, summary, matches)
        // Relationships
        List<AgentRelationship> agentRelationships = agent.relationships.collect {it.forAgent(agent)} // put relationships in same dynamic context as agent being matched
        minLevel = findMatchLevel((List<Defineable>)agentRelationships, relationshipSpec, minLevel, summary, matches)
        return new MatchResult(level: minLevel, summary: summary.toString(), matches: matches)
    }

    boolean implies(MatchingDomain matchingDomain) {
        AgentDefinition other = (AgentDefinition) matchingDomain
        if (other.matchesAll()) return true
        // all roles in others implied by a role in this
        if (other.roles && !other.roles.every {orl -> roles.any {rl -> rl.implies(orl)}}) return false
        if (!organizationSpec.implies(other.organizationSpec)) return false
        if (!locationSpec.implies(other.locationSpec)) return false
        if (!jurisdictionSpec.implies(other.jurisdictionSpec)) return false
        if (!relationshipSpec.implies(other.relationshipSpec)) return false
        return true;
    }

}