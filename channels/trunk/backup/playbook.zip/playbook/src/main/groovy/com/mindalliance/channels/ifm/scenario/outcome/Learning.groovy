package com.mindalliance.channels.ifm.scenario.outcome

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ifm.information.Fact

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 1:46:38 PM
 */
class Learning extends Outcome {  // information is acquired by a resource without being told (no communication)

    Ref resource
    Information information = new Fact()

    public isDefined() {
        return resource as boolean && information.defined
    }
}