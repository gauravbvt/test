package com.mindalliance.channels.ifm.scenario.action

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.analysis.scenario.agent.Agent
import com.mindalliance.channels.ifm.scenario.action.performance.CostPerformance
import com.mindalliance.channels.ifm.scenario.action.performance.ProbabilityPerformance
import com.mindalliance.channels.ifm.scenario.Occurrence
import com.mindalliance.channels.ifm.scenario.action.performance.TimePerformance
import com.mindalliance.channels.ifm.Timespan
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.scenario.Group
import com.mindalliance.channels.support.util.CountedSet
import com.mindalliance.channels.ifm.scenario.action.requirement.Requirement
import com.mindalliance.channels.ifm.scenario.timing.Timing
import com.mindalliance.channels.ifm.scenario.timing.ActionTiming
import com.mindalliance.channels.ifm.scenario.timing.ActionTiming

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 17, 2008
 * Time: 1:27:48 PM
 */
// An information act is a transaction; it either completely succeeds or it completely fails
abstract class Action extends Occurrence {

    String plan = ''
    Ref actor // an agentable Resource; a Job, Position ("some Job with Position"), Organization ("some Job in Organization") or Group (specification of agents as a team)
    Timing timing = new ActionTiming()
    TimePerformance duration = TimePerformance.minimized()
    CostPerformance cost = CostPerformance.minimized()
    ProbabilityPerformance probabilityOfSuccess = ProbabilityPerformance.maximized()   // probability of success based on actor's capabilities alone
    List<Requirement> requirements =[] // requirements on the actor for performing the act successfully

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['defaultDuration', 'actorAgent'])
    }

    Set hiddenProperties() {
        return (super.hiddenProperties() + ['actorAgent', 'actorIsGroup', 'defaultDuration']) as Set
    }

    String toString() {
        return name ?: "Unnamed"
    }

    Agent getActorAgent() {
        if (actor as boolean)
            return Agent.from((Agentable) actor.deref(), this)
        else
            return null
    }

    Timespan getDefaultDuration() {
        return duration.timespan      // default duration, irrespective of actor's capabilities
    }

    boolean actorIsGroup() {
        return actor as boolean && actor.deref() instanceof Group
    }

    // Queries

    List<String> findAllAlternatePlans() {
        // Find all subPlan names of followers of antecedent
        CountedSet plans = new CountedSet()
        scenario.actions.each {act ->
            if (act as boolean && act.antecedent == antecedent) {
                String otherPlan = act.plan
                if (otherPlan) plans.add(otherPlan)
            }
        }
        if (plan) plans.add(plan)
        return plans.toList()
    }

    // End queries

}