package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.impl.BeanImpl

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 17, 2008
 * Time: 1:57:58 PM
 */
class TagSet extends BeanImpl {

    List<String> tags = []

    static TagSet from(List<String> tags) {
        return new TagSet(tags:tags)
    }

    Object asType(Class type) {
        if (type == Boolean.class || type == boolean) {
            return tags as boolean
        }
        else {
            return super.asType(type)
        }
    }

    boolean isDefined() {
        return !tags.isEmpty()
    }

    String toString() {
        return tags ? tags.sort().join(',') : 'NO TAGS'
    }
}