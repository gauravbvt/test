package com.mindalliance.channels.graph

import com.mindalliance.channels.support.models.Container
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.scenario.event.Event
import org.apache.log4j.Logger
import com.mindalliance.channels.ref.Referenceable
import com.mindalliance.channels.ifm.resource.Resource
import com.mindalliance.channels.query.Query
import com.mindalliance.channels.analysis.scenario.Timeline
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.information.InformationNeed
import com.mindalliance.channels.ifm.scenario.action.*
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.analysis.scenario.Timeline
import com.mindalliance.channels.ifm.information.InformationNeed
import com.mindalliance.channels.ifm.scenario.event.Event

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 7, 2008
 * Time: 2:47:44 PM
 */
class InfoFlow extends ChannelsGraph {

    Set<Ref> acts = new HashSet()
    Set<Ref> agents = new HashSet()
    Set<Ref> events = new HashSet() // events that are not information acts
    List links = []

    InfoFlow(Container container) {
        super(container)
    }

    List<Ref> allElements() {
        List<Ref> elements = []
        elements.addAll(acts)
        elements.addAll(events)
        elements.addAll(agents)
        return elements
    }

    Map getStyleTemplate() {
        return super.getStyleTemplate() + [
                aboutEdge: [dir: 'none', style: 'dashed', fontsize: ChannelsGraph.LABEL_FONT_SIZE],
                flowEdge: [fontsize: ChannelsGraph.LABEL_FONT_SIZE]
        ]
    }

    void buildContent(GraphVizBuilder builder) {
        processData()
        buildAgents(builder)
        buildEvents(builder)
        buildLinks(builder)
        super.buildContent(builder)
    }

    void processData() {
        container.iterator().each {ref ->
            Referenceable el = ref.deref()
            switch (el) {
                case Agentable.class: processAgent((Agentable) el); break
                case Action.class: processAct((Action) el); break
                case Event.class: processEvent((Event) el); break
                case Timeline.class: processScenario((Timeline) el); break
                default: Logger.getLogger(this.class).warn("Can't display $el in info flow")
            }
        }
    }

    void processScenario(Timeline pb) {   // TODO -- not needed?
        pb.events.each {ref -> if (ref as boolean) processEvent((Event) ref.deref())}
        pb.actions.each {ref -> if (ref as boolean) processAct((Action) ref.deref())}
    }

    void processAgent(Agentable agent) {
        switch (agent) {
            case Resource.class: processResource((Resource) agent); break
            default: processScenarioAgent(agent); break
        }
    }

    // Add all acts this resource is actor or target of in all scenarios in resource's project
    void processResource(Resource res) {
        List<Ref> resourceActs = (List<Ref>)Query.execute(res, "findAllActionsWhereAgent")
        resourceActs.each { processAct(it) }
        agents.add(res.reference)
    }

    // Add all acts agent is actor or target of in agent's scenario
    void processScenarioAgent(Agentable agent) {
        Timeline scenario = agent.scenario
        assert scenario
        List<Ref> scenarioActs = (List<Ref>)Query.execute(scenario, "findAllActionsForAgent", agent.reference)
        scenarioActs.each { processAct(it) }
    }

    // Add all acts with information/need about the event
    void processEvent(Event event) {
        events.add(event.reference)
        List<Ref> aboutEventActs = (List<Ref>)Query.execute(event, "findAllActionsAboutEvent")
        aboutEventActs.each { processAct(it) }
    }

    void processAct(Ref ref) {
        if (ref as boolean) processAct((Action)ref.deref())
    }

    // Add act, actor and target agents
    void processAct(Action act) { // only keep acts that have all required agents set (otherwise flow is undefined)
        boolean valid = act.actor as boolean
        if (act.isFlowAct() && !(act.targetAgent as boolean)) valid = false
        if (valid) {
            acts.add(act.reference)
            agents.add(act.actor)
            if (act.isFlowAct()) agents.add(act.targetAgent)
        }
    }

    // Add agent nodes, containing its acts and info/needs/responsibilities/agreements from any acts where actor or target (based on akind of ct). Setup links.
    void buildAgents(GraphVizBuilder builder) {
        agents.each {agentRef ->
            Agentable agent = agentRef.deref()
            builder.cluster(name: "_${nameFor(agent)}", label: labelFor(agent), URL: urlFor(agent), template: 'agent') {
                builder.node(name: nameFor(agent), label: '?', template: 'invisible')
                buildActsAndInfoForAgent(agentRef, builder)
            }
        }
    }

    void buildActsAndInfoForAgent(Ref agentRef, GraphVizBuilder builder) {
        acts.each {actRef ->
            Action act = actRef.deref()
            // Actor's acts
            if (act.actor == agentRef) {
                builder.node(name: nameFor(act), label: labelFor(act), URL: urlFor(act), template: templateFor(act))
            }
            // Actor's acquired information
            if (act instanceof Communication && (act.targetAgent == agentRef || act.actor == agentRef)) {
                Information info = act.information
                String name = "${new Random().nextLong()}"
                builder.node(name: name, label: labelFor(info), URL: urlFor(act), template: 'info')
                links.add([nameFor(act), name, durationToText(act.startTime), 'flowEdge'])
                if (info.event as boolean) {
                    Event subject = (Event) info.event.deref()
                    events.add(info.event)
                    links.add([name, nameFor(subject), 'about', 'aboutEdge'])
                }
            }
            // Actor's task-acquired information needs
            if (act instanceof Task && act.actor == agentRef) {
                act.informationNeeds.each {need ->
                    String name = "${new Random().nextLong()}"
                    builder.node(name: name, label: labelFor(need), URL: urlFor(act), template: 'need')
                    links.add([nameFor(act), name, "at ${durationToText(act.startTime)} needs", 'aboutEdge'])
                    buildInformationNeed(need, name)
                }
            }
            if (act instanceof Communication && (act.targetAgent == agentRef)) {
                InformationNeed need = act.informationNeed
                String name = "${new Random().nextLong()}"
                builder.node(name: name, label: labelFor(need), URL: urlFor(act), template: 'need')
                links.add([nameFor(act), name, durationToText(act.startTime), 'flowEdge'])
                buildInformationNeed(need, name)
            }
        }
    }

/*    private boolean areSame(Ref agent, Ref other) { // both same fresh Ref, or both are either stale or null
        boolean same
        if (agent as boolean && other as boolean && agent == other) {
            same = true
        }
        else if (!(agent as boolean) && !(other as boolean)) {
            same = true
        }
        return true
    }*/

    void buildInformationNeed(InformationNeed need, String name) {
        if (need.isAboutSpecificEvents()) {
            List<Ref> subjects = need.informationSpec.eventSpec.enumeration
            subjects.each {ref ->
                Event subject = (Event) ref.deref()
                if (!subject instanceof Action) {
                    events.add(subject.reference)
                    links.add([name, nameFor(subject), '', 'aboutEdge'])
                }
                else {
                    if (acts.contains(ref)) links.add([name, nameFor(subject), '', 'aboutEdge'])
                }
            }
        }
        else {
            List<Ref> refs = need.informationSpec.eventSpec.definitions.priorEventSpec.enumeration
            refs.flatten().each {ref ->
                if (ref) {
                    Event priorOfSubject = (Event) ref.deref()
                    if (!priorOfSubject instanceof Action) {
                        events.add(ref)
                        links.add([name, nameFor(priorOfSubject), 'about event following', 'aboutEdge'])
                    }
                    else {
                        if (acts.contains(ref)) links.add([name, nameFor(priorOfSubject), 'about event following', 'aboutEdge'])
                    }
                }
            }
        }
    }

    void buildEvents(GraphVizBuilder builder) {
        events.each {eventRef ->
            Event event = (Event) eventRef.deref()
            builder.node(name: nameFor(event), label: labelFor(event), URL: urlFor(event), template: templateFor(event))
        }
    }

    void buildLinks(GraphVizBuilder builder) {
        links.each {link ->
            builder.edge(source: link[0], target: link[1], label: link[2], template: link[3])
        }
    }

}