package com.mindalliance.channels.ifm.scenario.action.requirement

import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.domain.FactDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 1:19:07 PM
 */
class InformationRequirement extends Requirement {  // actor must have matching information

    InformationDefinition informationSpec = new FactDefinition()

    boolean isDefined() {
        return !informationSpec.matchesAll()
    }

}