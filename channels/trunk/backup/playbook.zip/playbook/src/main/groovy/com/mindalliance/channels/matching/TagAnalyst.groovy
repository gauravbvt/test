package com.mindalliance.channels.matching

import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.TagSet

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 17, 2008
 * Time: 9:05:37 AM
 */
class TagAnalyst {

    static Level match(String tag1, String tag2) {
        // hook stuff here
        if (!tag1 && !tag2) return Level.HIGHEST // no tagging => match
        return SemanticMatcher.getInstance().semanticProximity(tag1, tag2)
    }

    // Find maximum tagSet matching level
    static Level bestTagSetMatch(List<TagSet> tagSets, TagSet tagSet) {
        Level max = Level.NONE
        if (tagSet as boolean) {
            tagSets.each {ts ->
                Level level = matchTagSets(ts, tagSet)
                max = (level > max) ? level : max
            }
        }
        return max
    }

    // Find best match between tags in tagSet and single tag
    static Level bestTagSetMatch(TagSet tagSet, String tag) {
        Level max = Level.NONE
        if (tagSet as boolean) {
           tagSet.tags.each { t ->
               Level level =  SemanticMatcher.getInstance().semanticProximity(t, tag)
               if (level > max) max = level
           }
        }
        return max
    }

    // Find best match between a tag in tagSet1 and a tag in tagSet2
    static Level bestTagSetMatch(TagSet tagSet1, TagSet tagSet2) {
        Level max = Level.NONE
        if (tagSet1 as boolean && tagSet2 as boolean) {
           tagSet1.tags.each { tag ->
               Level level =  bestTagSetMatch(tagSet2, (String)tag)
               if (level > max) max = level
           }
        }
        return max
    }

    // Calculate matching level of two tagSets:
    // For each tag in tag in TagSet1 find best matching counterpart in tagSet2, and return the lesser matching level among them
    static Level matchTagSets(TagSet tagSet1, TagSet tagSet2) {
        if (!tagSet1 as boolean || !tagSet2 as boolean) return Level.NONE // no matching
        Level min = Level.VERY_HIGH
        tagSet1.tags.each {t1 ->
            Level max = Level.NONE
            tagSet2.tags.each {t2 ->
                Level level = match(t1, t2)
                max = (level > max) ? level : max
            }
            min = (max < min) ? max : min
        }
        return min
    }

    // True if each tagSet in tagSet2 matches closely at least one tagSet in tagSet1
    static boolean implyTagSets(List<TagSet> tagSets1, List<TagSet> tagSets2) {
        boolean implied = tagSets2.every {ts2 -> tagSets1.any {ts1 -> matchTagSets(ts1, ts2) > Level.MEDIUM}}
        return implied
    }

    // True if every tag in tagSet2 is matched by a tag in tagSet1
    static boolean implyTagSets(TagSet tagSet1, TagSet tagSet2) { // whether tagSet1 implies tagSet2
        boolean implied = tagSet2.every {tag2 -> tagSet1.any {tag1 -> match(tag1, tag2) > Level.MEDIUM}}
        return implied
    }

    static boolean tagSetsDefined(List<TagSet> tagSets) {
        return tagSets.any {ts -> ts.isDefined()}
    }

    static     // Walk down the topics as attribute name lists, matching each attribute name
    Level matchTopics(List<String> topic, List<String> otherTopic) {
        if (!topic && !otherTopic) return Level.HIGHEST
        if (!topic || !otherTopic) return Level.NONE
        Level level = match((String)topic[0], (String)otherTopic[0])
        if (level > Level.NONE) {
            Level restLevel = matchTopics(topic[1..topic.size()-1], otherTopic[1..otherTopic.size()-1])
            level = (restLevel < level) ? restLevel : level
        }
        return level
    }

}