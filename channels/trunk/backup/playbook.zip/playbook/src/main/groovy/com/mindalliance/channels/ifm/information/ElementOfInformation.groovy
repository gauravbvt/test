package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.matching.TagAnalyst

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Mar 29, 2008
 * Time: 1:06:55 PM
 */
class ElementOfInformation extends BeanImpl implements Defineable {

    List<String> topic = []     // a sequence of attribute names (e.g. vehicle.door) -- empty means "this"
    String content = ''         // something about the topic (e.g. "unlocked")

    boolean isDefined() {
        return topic || content
    }

    // Semantic matching of two EOIs -- both of the same intent (intent is descriptive vs prescriptive)
    // Return least match level of tag, topic and, possibly, content
    Level match(ElementOfInformation eoi) {     // this matches eoi if topic matches
        Level minLevel = TagAnalyst.matchTopics(topic, eoi.topic)
        if (!(eoi.content && content)) {   // if any is empty, then content matches completely
            level = Level.HIGHEST
        }
        else {
            level = TagAnalyst.match(content, eoi.content)
        }
        return (level < minLevel) ? level : minLevel
    }

    Level matchSpecified(ElementOfInformation eoiSpec) {  // is this EOI specified by other (prescriptive intent)?
        // if eoiSpec's content is empty, my topic attribute names must match all those of, or the leading ones of, eoiSpec's topic
        // e.g. vehicle.door.handle[broken] matches eoi spec car.door.handle[] or vehicle.door[] or car[] or []
        // else my topic must match the full eoiSpec's topic, and if not empty my content must match eoiSpec's content
        if (eoiSpec.topic.size() > topic.size()) return Level.NONE
        Level level
        if (!eoiSpec.content) {
            List<String> subTopic = topic[0..eoiSpec.topic.size() - 1]
            level = TagAnalyst.matchTopics(subTopic, eoiSpec.topic)
        }
        else {
            level = TagAnalyst.matchTopics(topic, eoiSpec.topic)
            if (level > Level.NONE && content) {
                Level contentMatchLevel = TagAnalyst.match(content, eoiSpec.content)
                level = (contentMatchLevel < level) ? contentMatchLevel : level
            }
        }
        return level
    }


}