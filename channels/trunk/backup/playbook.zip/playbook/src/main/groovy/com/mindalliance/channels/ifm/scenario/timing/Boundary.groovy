package com.mindalliance.channels.ifm.scenario.timing

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ref.impl.BeanImpl

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 4:55:38 PM
 */
abstract class Boundary extends BeanImpl {

    Ref occurrence

    abstract boolean isStart()
    abstract boolean isEnd()
    abstract boolean isOutcomeBoundary()

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['outcomeBoundary'])
    }

    boolean isDefined() {
        return occurrence as boolean
    }

}