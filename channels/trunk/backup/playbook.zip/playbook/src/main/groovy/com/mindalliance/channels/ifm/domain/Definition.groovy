package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.Defineable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 9:41:46 AM
 *
 * A matching domain defined by intention
 */
abstract class Definition extends MatchingDomain {

    abstract protected MatchResult doMatch(Defineable bean)
    abstract protected boolean doesImply(MatchingDomain matchingDomain)

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['matchingDomainClass'])
    }

    String toString() {
        return description ?: 'NO DESCRIPTION'
    }

    boolean isDefined() {
        return true
    }

    MatchResult match(Defineable bean) {
        assert bean.isDefined()
        return doMatch(bean)
    }

    boolean matches(Defineable bean, Level level) {
        MatchResult result = match(bean)
        return result.level >= level
    }

    boolean implies(MatchingDomain matchingDomain) {
        if (!matchingDomain.class.isAssignableFrom(this.class)) {
            throw new IllegalArgumentException("Can't match incompatible domains")
        }
        if (matchingDomain.matchesAll()) return true
        if (this.matchesAll()) return false // this matchesAll and other does not match all
        return doesImply(matchingDomain)
    }

    boolean covers(MatchingDomain matchingDomain) {
        return matchesAll() || matchingDomain.implies(this)
    }

}