package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.project.InProject

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 17, 2008
 * Time: 3:08:42 PM
 */
interface InResource extends InProject {

    Ref getResource()

}