package com.mindalliance.channels.util

import com.mindalliance.channels.ifm.Channels
import com.mindalliance.channels.ifm.User
import com.mindalliance.channels.ifm.project.Participation
import com.mindalliance.channels.ifm.project.Project
import com.mindalliance.channels.ifm.scenario.Scenario
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ref.Referenceable
import com.mindalliance.channels.util.ChannelsApplication
import com.mindalliance.channels.ifm.scenario.event.Event

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 21, 2008
 * Time: 8:33:56 AM
 */

class BlankSlate {

    static void load() {
        // Channels root
        Channels channels = new Channels()
        channels.makeRoot()
        // Admin user
        User admin = new User(userId: "admin", name: 'Administrator', password: "admin")
        admin.admin = true
        admin.manager = true
        admin.analyst = true
        channels.addUser(store(admin))
        // Default project with participation and script with event
        Project p = new Project()
        Participation participation = new Participation(
                        user: admin.getReference(),
                        manager: true)
        p.addParticipation(participation)
        store(participation)
        Scenario scenario = new Scenario()
        Event event = new Event()
        scenario.addEvent(event)
        store(event)
        p.addScenario(scenario)
        store(scenario)
        channels.addProject(p)
        store(p)
        store(channels)
    }

    static private Ref store(Referenceable referenceable) {
        return ChannelsApplication.current().store(referenceable)
    }


}