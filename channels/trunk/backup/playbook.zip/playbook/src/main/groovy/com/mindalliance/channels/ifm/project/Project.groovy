package com.mindalliance.channels.ifm.project

import com.mindalliance.channels.ifm.Described
import com.mindalliance.channels.ifm.vocabulary.Place
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.util.ChannelsSession
import com.mindalliance.channels.util.RefUtils
import org.apache.wicket.Session
import com.mindalliance.channels.ifm.resource.organization.Organization
import com.mindalliance.channels.ifm.resource.Person
import com.mindalliance.channels.ifm.Named
import com.mindalliance.channels.support.util.CountedSet
import com.mindalliance.channels.util.drools.RuleBaseSession
import com.mindalliance.channels.ifm.location.GeoLocation
import com.mindalliance.channels.ifm.Channels
import com.mindalliance.channels.ifm.project.Participation
import com.mindalliance.channels.ref.Referenceable
import com.mindalliance.channels.ifm.ContainerElement
import com.mindalliance.channels.ifm.vocabulary.Medium
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.scenario.action.Communication
import com.mindalliance.channels.ifm.scenario.action.Action
import com.mindalliance.channels.ifm.vocabulary.Risk
import com.mindalliance.channels.ifm.vocabulary.Role
import com.mindalliance.channels.ifm.scenario.Scenario
import com.mindalliance.channels.ifm.scenario.action.Task
import com.mindalliance.channels.ifm.Jurisdictionable
import com.mindalliance.channels.ifm.scenario.action.Communication

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Mar 19, 2008
 * Time: 2:10:46 PM
 */
class Project extends ContainerElement implements Named, Described {

    String name = Channels.UNNAMED     // must be unique among projects
    String description = ''
    List<String> goals = []
    List<Ref> participations = []
    List<Ref> scenarios = []          // includes occurrences and groups
    // resources
    List<Ref> persons = []
    List<Ref> organizations = []      // includes positions, systems and jobs
    // vocabulary
    List<Ref> places = []
    List<Ref> mediums = []
    List<Ref> roles = []
    List<Ref> risks = []

    @Override
    protected List transientProperties() {
        return (List<String>) (super.transientProperties() + ['allIssues', 'allInvalidations', 'allProblems', 'resources'])
    }

    protected List childProperties() {
        return (List<String>) (super.childProperties() + ['participations', 'persons', 'organizations', 'places', 'scenarios', 'situations', 'mediums', 'roles', 'risks'])
    }

    Set<Class<?>> childClasses() {
        Set<Class<?>> result = super.childClasses()

        result.addAll([Participation.class, Place.class, Scenario.class, Situation.class, Medium.class, Person.class,
                Organization.class, Role.class, Risk.class])
        return result
    }

    Set keyProperties() {
        return (super.keyProperties() + ['name', 'description']) as Set
    }


    static Ref current() {
        ChannelsSession session = (ChannelsSession) Session.get()
        return session.project
    }

    Boolean isParticipant(Ref user) {
        return findParticipation(user) as boolean;
    }

    Boolean isManager(Ref user) {
        Ref ref = findParticipation(user)
        return ref as boolean && ref.manager;
    }

    /**
     * Return project contents that a participant can add.
     */
    static List contentClasses() {
        // When changing this method, don't forget to update the next one...
        List<Class<? extends Referenceable>> result = new ArrayList<Class<? extends Referenceable>>()
        result.addAll([Participation.class, Organization.class, Place.class, Medium.class,
                Scenario.class, Person.class, Role.class, Risk.class])
        result.addAll(Scenario.contentClasses())
        result.addAll(Organization.contentClasses())
        return result
    }

    void addContents(List<Ref> result) {
        result.addAll(organizations)
        organizations.each { it.addContents(result) }
        result.addAll(persons)
        result.addAll(places)
        result.addAll(situations)
        result.addAll(mediums)
        result.addAll(scenarios)
        result.addAll(participations)
        result.addAll(roles)
        result.addAll(risks)
        scenarios.each { it.addContents(result) }
        result.addAll(allProblems)
    }

    /**
     * Return system objects that a project manager can add.
     */
    static List managerClasses() {
        [Project.class]
    }

    void addManagerContents(List<Ref> result) {
        // Projects are added in UserScope.getContents()
    }

    Ref persist() {
        super.persist()
        if (!scenarios) {
            Scenario s = new Scenario(description: '(automatically created)')
            s.persist()
            this.addScenario(s)
        }
        if (!participations) {
            Participation p = new Participation(user: ChannelsSession.get().getUser(), manager: true)
            p.persist()
            this.addParticipation(p)
        }
        return this.reference
    }

    String toString() { name ?: "Unnamed" }

    List<Ref> getResources() {
        return findAllResources()
    }

    // Rulebase queries

    List<Ref> getAllInvalidations() {
        List<Ref> invalids = RuleBaseSession.current().query("invalidsInProject", [this.id], "_invalid").collect {it.reference}
        return invalids
    }

    List<Ref> getAllIssues() {
        List<Ref> issues = RuleBaseSession.current().query("issuesInProject", [this.id], "_issue").collect {it.reference}
        return issues
    }

    List<Ref> getAllProblems() {
        return (List<Ref>) (getAllInvalidations() + getAllIssues())
    }

    // end rulebase queries

    // Queries

    static List<Ref> findProjectsOfUser(Ref user) {
        return Channels.instance().findProjectsForUser(user)
    }

    List<Ref> findNonParticipatingUsers() {
        return (List<Ref>) Channels.instance().users.findAll {user -> !participations.any {part -> part.user == user && part.project == this.reference}}
    }

    List<Ref> findAllResources() {
        return findAllResourcesExcept(null)
    }

    Ref findPersonNamed(String name) {
        return (Ref) persons.find {it as boolean && it.name == name}
    }

    Ref findOrganizationNamed(String name) {
        return (Ref) organizations.find {it as boolean && it.name == name}
    }

    List<Ref> findAllResourcesExcept(Ref resource) {
        List<Ref> resources = []
        resources.addAll(persons.findAll {res -> res as boolean && res != resource })
        resources.addAll(organizations.findAll {res -> res as boolean && res != resource })
        organizations.each {org ->
            resources.addAll(org.systems.findAll {res -> res as boolean && res != resource })
            resources.addAll(org.positions.findAll {res -> res as boolean && res != resource })
            resources.addAll(org.jobs.findAll {res -> res as boolean && res != resource })
        }
        return resources
    }

    List<Ref> findAllAgentables() {
        List<Ref> agentables = []
        agentables.addAll(organizations)
        organizations.each {org ->
            agentables.addAll(org.systems)
            agentables.addAll(org.positions)
            agentables.addAll(org.jobs)
        }
        return agentables
    }

    List<Ref> findAllAgentablesExcept(def holder, String propPath) {
        Ref party = (Ref) RefUtils.get(holder, propPath)
        return (List<Ref>) findAllResourcesExcept(party).findAll {it instanceof Agentable}
    }

    Ref findScenarioNamed(String name) {
        return (Ref) scenarios.find {scenario ->
            scenario as boolean && scenario.name == name
        }
    }

    Ref findParticipation(Ref user) {
        Ref p = (Ref) participations.find {p -> p as boolean && p.user == user }
        return p
    }


    List<String> findAllPlaceNames() {
        List<String> names = []
        places.each {place -> if (place as boolean) names.add(place.name)}
        return names
    }

    Ref findPlaceNamed(String placeName) {
        Ref namedPlace = (Ref) places.find {place -> place as boolean && place.name == placeName }
        return namedPlace
    }

    // Find all organizations that are not
    // - the organization
    // -  a sub organization of some organization
    // - a parent organization (transitively) of the organization
    List<Ref> findCandidateParentOrganizationsFor(Ref organization) {
        List<Ref> candidates = (List<Ref>) organizations.findAll {org ->
            org as boolean &&
                    org != organization &&
                    !organization.ancestors.contains(org) &&
                    !org.ancestors.contains(organization)
        }
        return candidates
    }

    List<Ref> findAllPositionsAnywhere() {
        List<Ref> allPositions = []
        organizations.each {org -> if (org as boolean) allPositions.addAll(org.positions) }
        return allPositions
    }

    List<Ref> findAgreementsWhereBeneficiary(Ref org) {
        return organizations.agreements.flatten().findAll {agr -> agr.beneficiary == org}
    }

    List<Ref> findAllPlacesInAreasOfTypeImplying(Ref areaType) {
        GeoLocation geoLoc
        return (List<Ref>) places.findAll {place -> (geoLoc = place.findGeoLocation()) && geoLoc.isDefined() && geoLoc.areaType.implies(areaType) }
    }

    List<Ref> findAllAgentablesLocatedInAreasOfTypeImplying(Ref areaType) {
        return (List<Ref>) findAllAgentables().findAll {agent -> agent.hasLocation() && (geoLoc = agent.location.effectiveGeoLocation) && geoLoc.isDefined() && geoLoc.areaType.implies(areaType)}
    }

    List findAllAgentablesWithJurisdictionsInAreasOfTypeImplying(Ref areaType) {
        return (List<Ref>) findAllAgentables().findAll {agent -> agent.hasJurisdiction() && (geoLoc = agent.jurisdiction.effectiveGeoLocation) && geoLoc.isDefined() && geoLoc.areaType.implies(areaType)}
    }

    List<String> findAllRelationshipTags() {
        CountedSet countedSet = new CountedSet();
        // Permanent relationships
        findAllResources().relationships.flatten().each {
            rel ->
            if (rel as boolean) {
                if (rel.tag) countedSet.add(rel.tag)
                if (rel.reverseTag) countedSet.add(rel.reverseTag)
            }
        }
        // TODO -- Implement Tag tabulation to keep track of all tag usage (counted sets) per element type (in specifications as well)
        return countedSet.toList()
    }

    List<String> findCapabilityTags() {
        CountedSet countedSet = new CountedSet()
        countedSet.addAll(findAllResources().capabilities.flatten().tag)
        return countedSet.toList();
    }


    List<Ref> findAllPurposes() {
        CountedSet countedSet = new CountedSet();
        organizations.policies.flatten().each {pol -> if (pol as boolean) countedSet.addAll(pol.limitationsOnUse.allPurposes)}
        organizations.agreements.each {agr ->
            if (agr as boolean) {
                countedSet.addAll(agr.limitationsOnUse.allPurposes)
            }
        }
        scenarios.each {scenario ->
            if (scenario as boolean) {
                scenario.allActions.each {act ->
                    if (act as boolean && act.type == "Communication") {
                        countedSet.addAll(act.allPurposes)
                    }
                }
            }
        }
        return countedSet.toList()

    }

    List<Ref> findAllCommunicationsBetween(Ref actor, Ref target) {
        List<Ref> flowActs = scenarios.allAction.flatten().findAll {act ->
            (act as boolean && act instanceof Communication) &&
                    ((act.actor == actor || (actor instanceof Organization && act.actor.hasResource(it)))) &&
                    (act.targetAgent as boolean && (act.targetAgent == target || (target instanceof Organization && target.hasResource(act.targetAgent))))
        }
        return flowActs
    }

    List<Ref> findAllJobsOf(Ref individual) {
        return (List<Ref>) organizations.jobs.flatten().findAll {job -> job.individual == individual}
    }

    List<Ref> findAllIndividuals() {
        return persons + organizations.systems.flatten()
    }

    List<String> findAllEventTags() {    // TODO -- use some persistent TagCounter
        CountedSet countedSet = new CountedSet();
        scenarios.events.flatten().each {event ->
            countedSet.add(event.tag)
        }
        scenarios.actions.flatten().each {ref ->
            Action act = (Action) ref.deref()
            if (act instanceof Communication) {
                countedSet.addAll(act.allInformations.tag)
            }
        }
        return countedSet.toList()
    }

    List<String> findAllTaskTags() {
        CountedSet countedSet = new CountedSet();
        scenarios.actions.flatten().each {act ->
            if (act instanceof Task) {
                countedSet.addAll(act.tags.tags)
            }
        }
        return countedSet.toList()
    }

    List<String> findAllOrganizationTags() {
        CountedSet countedSet = new CountedSet();
        organizations.tags.flatten().each {tagSet ->
            countedSet.addAll(tagSet.tags)
        }
        return countedSet.toList()
    }

    List<String> findAllPlaceTags() {
        CountedSet countedSet = new CountedSet();
        places.tags.flatten().each {tagSet ->
            countedSet.addAll(tagSet.tags)
        }
        return countedSet.toList()
    }

    List<Ref> findAllLocatables() {
        List<Ref> locatables = []
        locatables.addAll(findAllResources())
        return locatables
    }

    List<Ref> findAllJurisdictionables() {
        return (List<Ref>) findAllResources().findAll {it instanceof Jurisdictionable}
    }

    List<String> findAllTopicsAbout(Ref event) { // find candidate topics for EOIs
        CountedSet countedSet = new CountedSet()
        if (event as boolean) {
            scenarios.each {scenario ->
                scenario.finAllInformationAbout(event).each {info ->
                    countedSet.addAll(info.eois.flatten().topic)
                }
            }
        }
        return countedSet.toList()
    }

    // End queries


}