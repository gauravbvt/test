package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.matching.TagAnalyst
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ifm.information.ElementOfInformation
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.util.RefUtils

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 1, 2008
 * Time: 2:14:58 PM
 */
class Fact extends Information { // something that increases one's knowledge of the world

    Ref knowable // about what -- if null, knowledge is about "the world", else about an identified, knowable model element
    String tag = '' // what knowable is viewed as
    List<ElementOfInformation> eois = [] // what's known by sources
    boolean negated = false // when negated, if no EOIs => "<knowable> is not a <tag>", else => "<knowable> is a <tag> but not with these EOIs"

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['knowableTag'])
    }

    boolean isDefined() {
        return super.defined && eois.every {it.isDefined()}
    }

    String toString() {
        return "Fact about ${knowableTag}${negated ? ' (negated)' : ''}"
    }

    String getKnowableTag() {
        return tag ?: 'NOT CATEGORIZED'
    }

/*
    // About the same knowable (same classification) and all my eois strongly match the other information's eois, irrespective of sources and ttl
    boolean isComprisedIn(Information information) {
        if (!super.isComprisedIn(information)) return false
        Knowledge otherKnowledge = (Knowledge)information
        if (knowable != otherKnowledge.knowable) return false // about same knowable
        if (negated != otherKnowledge.negated) return false // both affirmative or negative
        // matching classification?
        if (TagAnalyst.match(tag, otherKnowledge.tag) < Level.HIGH) return false
        // matching EOIs
        if (eois && !otherKnowledge.eois.every {oeoi ->               // todo - correct if negated?
                eois.any {eoi -> eoi.match(oeoi) > Level.MEDIUM}}) return false
        return true
    }
*/

    String makeLabel(int maxWidth) {
        assert isDefined()
        String label = RefUtils.summarize(toString(), maxWidth)
        eois.each {eoi ->
            label += "|${RefUtils.summarize(eoi.topic, maxWidth)}"
        }
        return label
    }


}