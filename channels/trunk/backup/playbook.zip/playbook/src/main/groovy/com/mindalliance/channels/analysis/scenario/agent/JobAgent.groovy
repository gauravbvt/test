package com.mindalliance.channels.analysis.scenario.agent

import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ifm.resource.Relationship
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.responsibility.Responsibility
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ifm.information.InformationNeed
import com.mindalliance.channels.ifm.resource.organization.Organization
import com.mindalliance.channels.ifm.resource.Job
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ifm.information.InformationNeed

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 18, 2008
 * Time: 10:09:27 PM
 */
class JobAgent extends Agent {

    Job job

    Agentable getAgentable() {
        return job
    }

    public Location getLocation() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<Relationship> getRelationships() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<Ref> getRoles() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<Responsibility> getResponsibilities() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean canNotifyWith(Agent agent, Information information) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean canQueryAbout(Agent agent, InformationNeed informationNeed) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Location getJurisdiction() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Organization getOrganization() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<Information> getInformations() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<InformationNeed> getInformationNeeds() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<Ref> getSourcesFor(InformationDefinition informationSpec) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}