package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.Named
import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.analysis.scenario.agent.AgentRelationship
import com.mindalliance.channels.analysis.scenario.agent.Agent

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 10:45:25 AM
*/
class Relationship extends BeanImpl implements Named {

    Ref withResource  
    String tag = ''    // Simple tag because don't want to conflate multiple relationships into one
    String reverseTag = '' // used to infer Links from toResource to the resource with this relationship

    @Override
    protected List transientProperties() {
        return (List<String>) (super.transientProperties() + ['name'])
    }

    String getName() {
        return tag
    }

    String toString() {
        return name ?: "?"
    }

    boolean isDefined() {
        return tag && withResource as boolean
    }

    AgentRelationship forAgent(Agent agent) {
        return new AgentRelationship(relationship: this, agent: agent)
    }

}