package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ifm.information.Authorization

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 2, 2008
 * Time: 9:38:25 AM
 */
class SharingAuthorizationDefinition extends InformationDefinition {

    MatchResult doSpecificMatch(Information information, Level level, StringBuilder summary, Map<String, Object> matches) {
        return null  //Todo
    }

     Class<? extends Defineable> getMatchingDomainClass() {
        return Authorization.class
    }

}