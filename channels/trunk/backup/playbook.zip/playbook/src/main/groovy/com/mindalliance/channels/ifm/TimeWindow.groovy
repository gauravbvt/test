package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 5, 2008
 * Time: 2:54:07 PM
 */
class TimeWindow extends BeanImpl {
    // default is "forever"
    Ref action                  // reference point: from the end of this act, or if null, start of scenario
    Timespan start = new Timespan()     // delay relative to reference point, default is 0
    Timespan duration = new Timespan() // 0 means open-ended duration

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['forever'])
    }

    boolean isDefined() {
        return true
    }

    boolean isForever() {
        return !action as boolean && !start.defined && !duration.defined
    }

}