package com.mindalliance.channels.ifm.scenario.action

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.analysis.scenario.agent.Agent
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ifm.TagSet

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 17, 2008
 * Time: 1:39:07 PM
 */
// Communication of information(s) from actor to target
class Communication extends Action {

    Ref target                          // transmitted to whom
    TagSet format = new TagSet()        // in what format(s)
    Ref medium                          // over what medium
    boolean encrypted = false           // if encrypted, only intended recipient(s) can see info
    List<Ref> intendedRecipients = []   // intended recipients if different from target
    List<Information> informations  = []    // what is transmitted

    boolean isDefined() {
        return super.isDefined() && informations.any {it.defined} && target as boolean && medium as boolean && format.defined
    }

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['targetAgent', 'allPurposes'])
    }

    Agent getTargetAgent() {
        return Agent.from((Agentable) target.deref(), this)
    }

    String about() {
        return "Communication of: ${informations.collect {it.about}.join(',')}"
    }

    List<String> getAllPurposes() {
        return informations.usageRestriction.flatten().purposes
    }

}