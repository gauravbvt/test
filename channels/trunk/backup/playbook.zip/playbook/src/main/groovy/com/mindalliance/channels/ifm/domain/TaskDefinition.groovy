package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.scenario.action.Task
import com.mindalliance.channels.ifm.Timespan
import com.mindalliance.channels.matching.SemanticMatcher
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.matching.TagAnalyst
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 8:56:10 PM
 */
class TaskDefinition extends Definition {

    List<TagSet> tagSets = [] // ORed TagSets (the tags in each TagSet are ANDed) -- classification -> what the task is
    List<String> purposes = [] // ORed -- specific purposes  -> why do the task
    TagSet eventOutcomeTagSet = new TagSet() // OR-ed self-evident classfication of expected (optional) outcome event(s)    
    Timespan responseDelay = new Timespan(amount:0)  // max delay after trigger -- no max delay if 0 (not used in matching)

    Class<? extends Defineable> getMatchingDomainClass() {
        return Task.class
    }

    boolean matchesAll() {
        return !TagAnalyst.tagSetsDefined(tagSets)
    }

    protected MatchResult doMatch(Defineable bean) {
        Task task = (Task)bean
        Level minLevel = Level.HIGHEST
        Map<String, Object> matches = [:]
        StringBuilder summary = new StringBuilder()
        // Tags
        Level level = TagAnalyst.bestTagSetMatch(tagSets, task.tags)
        matches['task tags'] = level
        summary.append("${level.confidence()} tags ok")
        if (level < minLevel) minLevel = level
        if (purposes) {
            level = SemanticMatcher.getInstance().bestMatch(purposes, task.purpose)
            matches['purpose'] = level
            summary.append("${level.confidence()} purpose ok")
            if (level < minLevel) minLevel = level
        }
        // Task has at least one outcome event with matching tags
        if (eventOutcomeTagSet.isDefined()) {
            List<Ref> outcomeEvents = task.outcomeEvents
            level = TagAnalyst.bestTagSetMatch(eventOutcomeTagSet , TagSet.from(outcomeEvents.tag.flatten()))
            matches['outcome event tags'] = level
            summary.append("${level.confidence()} outcome event tags ok")
            if (level < minLevel) minLevel = level
        }
        // TODO -- response delay match
        return new MatchResult(level: minLevel, summary: summary.toString(), matches: matches)
    }

    protected boolean doesImply(MatchingDomain matchingDomain) {
        TaskDefinition other = (TaskDefinition)matchingDomain
        if (other.matchesAll()) return true
        if (!TagAnalyst.implyTagSets(tagSets, other.tagSets)) return false
        if (other.purposes && !other.purposes.every{osp ->
                purposes.any{sp -> SemanticMatcher.matches(sp, osp, Level.HIGH) }}) return false
        if (other.responseDelay.isDefined() && !responseDelay.isShorterOrEqualTo(other.responseDelay)) return false
        return true
    }


}