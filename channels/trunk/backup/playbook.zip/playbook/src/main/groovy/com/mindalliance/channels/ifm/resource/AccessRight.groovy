package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.domain.AgentSpecification
import com.mindalliance.channels.util.RefUtils
import com.mindalliance.channels.ifm.Described
import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.Overridable
import com.mindalliance.channels.ifm.domain.FactDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 13, 2008
 * Time: 9:12:36 AM
 */
// Access restrictions to a Resource
class AccessRight extends BeanImpl implements Described, Overridable {

    String description = ''
    AgentSpecification granteeSpec = new AgentSpecification()  // who can access this resource, any if not defined
    InformationDefinition informationSpec = new FactDefinition()   // about what kind of information
    boolean canNotify = true   // notifications accepted?
    boolean canQuery = true    // queries accepted?
    List<Ref> preferredMediumTypes = []  // using what communication media  (in order of preferrence)

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['summary'])
    }

    String toString() {
        return description ?: "?"
    }

    boolean isDefined() {
        return true // in default state, anyone has complete access anytime anyhow
    }

    boolean isRestrictive() {
        return !granteeSpec.matchesAll() || !informationSpec.matchesAll() || !canNotify || !canQuery
    }

    String getSummary() {
        return RefUtils.summarize(this.toString(), 20)
    }

    public boolean overrides(Overridable other) {
        AccessRight otherAccessRight = (AccessRight) other
        if (!granteeSpec.implies(otherAccessRight.granteeSpec)) return false
        if (!informationSpec.implies(otherAccessRight.informationSpec)) return false
        return true
    }
}