package com.mindalliance.channels.analysis.scenario.agent

import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ifm.Jurisdictionable
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.resource.Job
import com.mindalliance.channels.ifm.resource.Position
import com.mindalliance.channels.ifm.resource.Relationship
import com.mindalliance.channels.ifm.resource.organization.Organization
import com.mindalliance.channels.ifm.responsibility.Responsibility
import com.mindalliance.channels.ifm.scenario.Group
import com.mindalliance.channels.ifm.scenario.Occurrence
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ifm.information.InformationNeed
import com.mindalliance.channels.ref.Ref
import org.apache.wicket.authorization.strategies.role.Roles

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 20, 2008
 * Time: 10:11:12 AM
 */

// agent = resource + agent state at occurrence + resource's profile in occurrence's scenario
abstract class Agent implements Defineable, Jurisdictionable {   // An agentable at the start of an information act with combined static and dynamic profile

    Occurrence occurrence // if occurrence == null => agentable at time zero

    abstract Location getLocation()

    abstract Location getJurisdiction()

    abstract Organization getOrganization()

    abstract List<Relationship> getRelationships()

    abstract List<Roles> getRoles()

    abstract List<Responsibility> getResponsibilities()

    abstract boolean canNotifyWith(Agent agent, Information information)

    abstract boolean canQueryAbout(Agent agent, InformationNeed informationNeed)

    abstract List<Information> getInformations()

    abstract List<InformationNeed> getInformationNeeds()

    abstract List<Ref> getSourcesFor(InformationDefinition informationSpec)

    static Agent from(Agentable agentable) {
        return from(agentable, null)  // static view of the agentable resource
    }

    static Agent from(Agentable agentable, Occurrence occurrence) {  // TODO - mixin ProfileExtension for agentable resource if any from scenario
        assert agentable as boolean && occurrence as boolean
        switch(agentable) {
            case Job.class: return fromJob((Job)agentable, occurrence)
            case Position.class: return fromPosition((Position)agentable, occurrence)
            case Organization.class: return fromOrganization((Organization)agentable, occurrence)
            case Group.class: return fromGroup((Group)agentable, occurrence)
        }
    }

    static Agent fromJob(Job job, Occurrence occurrence) {
        return new JobAgent(agentable: job, occurrence: occurrence)
    }

    static Agent fromPosition(Position position, Occurrence occurrence) {
        return new PositionAgent(agentable: position, occurrence: occurrence)
    }

    static Agent fromOrganization(Organization organization, Occurrence occurrence) {
        return new OrganizationAgent(agentable: organization, occurrence: occurrence)
    }

    static Agent fromGroup(Group group, Occurrence occurrence) {
        return new GroupAgent(agentable: group, occurrence: occurrence)
    }

    abstract Agentable getAgentable()

    String getId() {
        return agentable.id
    }

    Ref getReference() {
        return agentable.reference
    }

    String getName() {
        return agentable.name
    }

    String getDescription() {
        return agentable.description + " (at $action)"
    }

    boolean isDefined() {
        return agentable != null && agentable.isDefined()
    }

    boolean hasRole(Ref role) {
        return roles.id.contains(role.id)
    }

     /*List results = RuleBaseSession.query("agentLocation", [agentable.id, action.id], "_location")
        if (results) {
            assert results.size() == 1
            return (Location) results[0]
        }
        else {
            return agentable.location
        }*/

    /*List<Relationship> relationships = (List<Relationship>) Query.execute(action.getProject(), "findAllRelationshipsOf", agentable.reference)
        List<Link> results = (List<Link>) RuleBaseSession.query("agentLinks", [agentable.id, action.id], "_link")
        for (Link link: results) {
            Relationship rel = new Relationship(fromResource: agentable.reference, toResource: link.toAgent.reference, name: link.relationshipName)
            relationships.add(rel)
        }
        return relationships*/

}