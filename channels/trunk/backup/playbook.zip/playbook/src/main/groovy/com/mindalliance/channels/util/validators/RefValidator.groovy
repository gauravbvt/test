package com.mindalliance.channels.util.validators

import org.apache.wicket.validation.validator.AbstractValidator
import org.apache.wicket.validation.IValidatable
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 7, 2008
 * Time: 11:03:03 AM
 */
class RefValidator extends AbstractValidator {

    private String property;

    RefValidator(String property) {
        this.property = property
    }

    static RefValidator onProperty(String propertyName) {
        return new RefValidator(propertyName)
    }

    protected void onValidate(IValidatable validatable) {
        Ref ref = (Ref)validatable.getValue()
        (!ref.isFresh()) error(validatable)
    }

    @Override
    protected String resourceKey() {
        return "RefValid";
    }

    @Override
    protected Map variablesMap(IValidatable validatable) {
        return super.variablesMap(validatable) + [property:property]
    }


}