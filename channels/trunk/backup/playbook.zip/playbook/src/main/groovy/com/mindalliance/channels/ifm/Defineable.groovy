package com.mindalliance.channels.ifm
/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 25, 2008
 * Time: 12:45:58 PM
 */
interface Defineable {

    boolean isDefined()    // undefined elements should be "inoperative"

}