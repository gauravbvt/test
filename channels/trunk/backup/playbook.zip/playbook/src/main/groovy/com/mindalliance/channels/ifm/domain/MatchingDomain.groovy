package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.Described
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.util.RefUtils
import com.mindalliance.channels.ref.impl.BeanImpl

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 9:34:22 AM
 */
abstract class MatchingDomain extends BeanImpl implements Described {

    String description = ''

    abstract Class<? extends Defineable> getMatchingDomainClass() // what can be matched
    abstract boolean matchesAll() // matching any instance of matched class -- i.e. represents universal domain
    abstract boolean matches(Defineable bean, Level level) // matches at least at the given level
    abstract MatchResult match(Defineable bean)
    abstract boolean implies(MatchingDomain matchingDomain) // is this matching domain a subset?

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['matchingDomainClass', 'label'])
    }

    String getLabel() {
        return RefUtils.deCamelCase(RefUtils.shortClassName(this))
    }

    protected Level findMatchLevel(Defineable bean, MatchingDomain domain, Level minLevel, StringBuilder summary, Map<String, Object> matches) {
        if (minLevel == Level.NONE) return Level.NONE // nothing to do
        if (domain.matchesAll()) {
            matches[domain.label] = Level.HIGHEST  // universal match
            summary.append("Any ${domain.label} ok. ")
            return minLevel
        }
        else {
            if (!bean || !bean.isDefined()) {
                matches[domain.label] = Level.NONE
                summary.append("No ${domain.label}")
                return Level.NONE
            }
            else {
                MatchResult res = domain.match(bean)
                matches[domain.label] = res
                summary.append("${res.level.confidence()} ${domain.label} ok. ")
                return (res.level < minLevel) ? res.level : minLevel
            }
        }
    }

    // Use best match from list against domain
    protected Level findMatchLevel(List<Defineable> list, MatchingDomain domain, Level minLevel, StringBuilder summary, Map<String, Object> matches) {
        if (domain.matchesAll()) {
            matches[domain.label] = Level.HIGHEST  // universal match
            summary.append("Any ${domain.label} ok. ")
        }
        else {
            if (!list || !list.any {it.isDefined()}) {
                matches[domain.label] = Level.NONE
                summary.append("No ${domain.label} to match. ")
                return Level.NONE
            }
            else {
                // look for the best match in list
                Level maxLevel = Level.NONE
                MatchResult bestMatch = null
                Defineable bestBean = null
                list.each {bean ->
                    if (bean.isDefined()) {
                        MatchResult res = domain.match(bean)
                        if (res.level > maxLevel) {
                            maxLevel = res.level
                            bestMatch = res
                            bestBean = bean
                        }
                    }
                }
                matches[domain.label] = bestMatch
                summary.append("${bestMatch.level.confidence()} ${domain.label} $bestBean is ok (best match). ")
                return (maxLevel < minLevel) ? maxLevel : minLevel
            }
        }

    }

}