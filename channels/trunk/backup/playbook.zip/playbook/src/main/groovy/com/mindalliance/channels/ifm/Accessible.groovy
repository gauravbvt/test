package com.mindalliance.channels.ifm

import com.mindalliance.channels.ifm.resource.AccessRight

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 24, 2008
 * Time: 3:33:13 PM
 */
interface Accessible {

    List<AccessRight> getAccessRights()

}