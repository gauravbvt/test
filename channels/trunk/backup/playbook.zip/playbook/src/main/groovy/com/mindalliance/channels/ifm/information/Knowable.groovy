package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ifm.Referenced

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 3, 2008
 * Time: 3:48:31 PM
 */
interface Knowable extends Referenced, Communicable {    // a identifable model element that can be known to agents in a scenario

    List<ElementOfInformation> eoisFrom(List<String> topic)
    String impliedTag()

}