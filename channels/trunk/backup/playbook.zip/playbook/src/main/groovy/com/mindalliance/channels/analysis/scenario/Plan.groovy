package com.mindalliance.channels.analysis.scenario

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 24, 2008
 * Time: 11:25:19 AM
 */
class Plan {   // a plan named in a scenario

    String name
    Ref scenario
    List<Plan> children = []

    // one's plan includes the other
    static boolean compatible(Ref occ1, Ref occ2) {
        List<String> planPath1 = occ1.planPath
        List<String> planPath2 = occ2.planPath
        return (includes(planPath1, planPath2) || includes(planPath2, planPath1))
    }

    // true if otherPlanPath is the same as or extends planPath
    static boolean includes(List<String> planPath, List<String> otherPlanPath) {
        if (planPath.isEmpty()) return true
        if (otherPlanPath.isEmpty()) return false
        if (planPath[0] != otherPlanPath[0])  return false
        return includes(planPath.size() > 1 ? planPath[1..planPath.size()-1] : [],
                        otherPlanPath.size() > 1 ? otherPlanPath[1..otherPlanPath.size()-1] : [])
    }

}