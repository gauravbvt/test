package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.impl.BeanImpl

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 26, 2008
 * Time: 3:42:22 PM
 */
class Probability extends BeanImpl implements Comparable {

    int value = 100

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['floatValue'])
    }

    static Probability fromValue(int val) {
        return new Probability(value:val)
    }

    boolean isDefined() {
        return true
    }

    String toString() {
        return "$value%"
    }

    int compareTo(Object other) {
        if (!other instanceof Probability) throw new IllegalArgumentException("Must compare to a Probability, not a ${other.class.name}")
        Probability prob = (Probability)other
        if (value == prob.value) return 0
        if (value < prob.value) return -1
        return 1
    }

    void setValue(int val) {
        value = Math.max(0, Math.min(val, 100))
    }

    float getFloatValue() {
        return (value / 100) as float
    }

}