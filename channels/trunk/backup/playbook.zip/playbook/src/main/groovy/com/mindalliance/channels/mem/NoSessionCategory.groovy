package com.mindalliance.channels.mem

import com.mindalliance.channels.ref.impl.ReferenceableImpl
import com.mindalliance.channels.ref.Referenceable
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.util.drools.RuleBaseSession

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Mar 23, 2008
 * Time: 6:34:00 PM
 */
class NoSessionCategory {

    // REFERENCEABLE

    // Changes on out-of-session element allowed
    static void checkModifyingAllowed(ReferenceableImpl self) {
        // OK to modify
    }

    // Don't raise change event
/*    static void doSetProperty(ReferenceableImpl self, String name, def value) {
        String setterName = "set${name[0].toUpperCase()}${name.substring(1)}"
        self."$setterName"(value)
    }*/

    static void propertyChanged(ReferenceableImpl self, String name, def old, def value) {
       // Do nothing
    }


    // Can't persist new elements out of session
    static void persist(ReferenceableImpl self) {
        throw new Exception("Must be within session to persist")
    }

    // Dereference only from application memory
    static Referenceable retrieve(SessionMemory self, Ref reference, Referenceable dirtyRead) {
        if (dirtyRead) {
            return dirtyRead
        }
        else {
            return self.retrieveFromApplicationMemory(reference)
        }
    }

    static void fireAllRules(RuleBaseSession ruleBaseSession) {
        // do nothing
    }
}