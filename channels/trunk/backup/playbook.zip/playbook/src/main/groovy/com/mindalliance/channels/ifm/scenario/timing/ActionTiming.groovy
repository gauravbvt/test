package com.mindalliance.channels.ifm.scenario.timing

import com.mindalliance.channels.ifm.scenario.action.performance.TimePerformance
import com.mindalliance.channels.ifm.scenario.timing.Timing

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 2:06:25 PM
 */
class ActionTiming extends Timing {

    TimePerformance delay = new TimePerformance() // from start or end of prior
    // condition applies only if timing is from end of an information act

}