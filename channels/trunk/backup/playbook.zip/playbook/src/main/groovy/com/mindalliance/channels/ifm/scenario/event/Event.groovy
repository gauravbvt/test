package com.mindalliance.channels.ifm.scenario.event

import com.mindalliance.channels.ifm.*
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ifm.scenario.timing.EventTiming
import com.mindalliance.channels.ifm.scenario.timing.Timing
import com.mindalliance.channels.ifm.scenario.Occurrence
import com.mindalliance.channels.ifm.scenario.event.Consequence
import com.mindalliance.channels.ifm.scenario.timing.Timing

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 17, 2008
 * Time: 9:24:42 AM
 */
// Something of consequence becomes true somewhere at some point in time
// How it is classified and accounted is the point of views of individual agents
// that they may share with others fully or partially, dispute and confirm
class Event extends Occurrence implements Locatable {

    Timing timing = new EventTiming()
    Timespan defaultDuration = new Timespan()
    Location location = new Location()
    String tag = '' // self-evident classification
    List<Consequence> consequences = []

    Set keyProperties() {
        return (super.keyProperties() + ['name']) as Set
    }

    Set hiddenProperties() {
        return (super.hiddenProperties() + ['defaultDuration']) as Set
    }
    
    // END QUERIES

}