package com.mindalliance.channels.ifm.responsibility

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.Named
import com.mindalliance.channels.ifm.Described
import com.mindalliance.channels.ifm.Channels

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Mar 29, 2008
* Time: 9:05:53 AM
*/
// Responsibility of a Responsibility to any agent with a given role, possibly within a given type of organization
// and possiblylimited to some location
abstract class Responsibility extends BeanImpl implements Named, Described {

    String name = ''
    String description = ''

    String toString() {
        return "${name ?: Channels.UNNAMED}"
    }

    String about() {
        return description ?: '?'
    }

    boolean isDefined() {
        return true
    }
    
}