package com.mindalliance.channels.ifm.scenario.timing

import com.mindalliance.channels.ifm.Timespan
import com.mindalliance.channels.ifm.scenario.timing.Timing

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 2:05:24 PM
 */
class EventTiming extends Timing {

    Timespan delay = new Timespan()

}