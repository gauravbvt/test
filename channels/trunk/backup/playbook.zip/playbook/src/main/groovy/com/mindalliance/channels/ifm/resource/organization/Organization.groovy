package com.mindalliance.channels.ifm.resource.organization

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.mem.ApplicationMemory
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.resource.organization.Policy
import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.ifm.ContainerElement
import com.mindalliance.channels.ifm.responsibility.Responsibility
import com.mindalliance.channels.ifm.resource.Resource
import com.mindalliance.channels.ifm.resource.ContactInfo
import com.mindalliance.channels.ifm.resource.AccessRight
import com.mindalliance.channels.ifm.resource.Relationship
import com.mindalliance.channels.ifm.resource.Position
import com.mindalliance.channels.ifm.resource.System
import com.mindalliance.channels.ifm.resource.organization.SharingAgreement
import com.mindalliance.channels.ifm.resource.Job
import com.mindalliance.channels.ifm.resource.Capability
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.Documentation
import com.mindalliance.channels.ref.Referenceable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 17, 2008
 * Time: 11:24:14 AM
 */
class Organization extends ContainerElement implements Resource, Agentable {   // a company, agency, team, matrix etc.

    String name = ''
    String description = ''
    TagSet tags = new TagSet()                  // kind of organization
    Ref parent         // parent organization
    boolean activated = true // activated by default
    List<ContactInfo> contactInfos = []         // contact info to "front desk"
    Location location = new Location()
    List<AccessRight> accessRights = []                // who can access "front desk"
    List<Relationship> relationships = []       // relationship for the organization as a whole
    List<Capability> capabilities = []          // capabilitities for the organization as a whole
    List<InformationDefinition> knowledge = []  // expertise for ...
    Documentation documentation = new Documentation()


    List<Ref> positions = []
    List<Ref> jobs = []
    List<Ref> systems = []
    List<Ref> policies = []
    List<Ref> agreements = []
    Location jurisdiction = new Location()

    static List contentClasses() {
        // When changing this method, don't forget to update the next one...
        List<Class<? extends Referenceable>> result = new ArrayList<Class<? extends Referenceable>>()
        result.addAll([Position.class])
        result.addAll([Job.class])
        result.addAll([System.class])
        result.addAll([SharingAgreement.class])
        result.addAll([Policy.class])
        return result
    }

    void addContents(List<Ref> result) {
        result.addAll(positions)
        result.addAll(jobs)
        result.addAll(systems)
        result.addAll(policies)
        result.addAll(agreements)
    }

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['resources', 'ancestors', 'roles'])
    }


    protected List<String> childProperties() {
        return (List<String>) (super.childProperties() + ['positions', 'systems', 'policies', 'agreements', 'jobs'])
    }

    public Set<Class<?>> childClasses() {
        return super.childClasses() + [
                Position.class, System.class, Policy.class, SharingAgreement.class, Job.class
        ] as Set<Class<?>>
    }

    void beforeStore(ApplicationMemory memory) {
        super.beforeStore(memory)
        jurisdiction.detach()
        location.detach()
    }

    @Override
    void changed(String propName) {
        if (propName == 'jurisdiction') {
            jurisdiction.detach()
        }
        if (propName == 'location') {
            location.detach()
        }
        super.changed(propName)
    }

    boolean isAnOrganization() {
        return true
    }

    boolean hasResource(Ref resource) {
        if (this.resources.contains(resource)) return true
        return findAllSubOrganizations().any {org -> org.hasResource(resource)}
    }

    boolean isPartOf(Ref org) {
        return parent == org
    }

    List<Ref> getResources() {
        List<Ref> resources = []
        resources.addAll(positions)
        resources.addAll(systems)
        resources.addAll(jobs)
        return resources
    }

    List<Ref> getAncestors() {   // meaning ancestors
        List<Ref> ancestry = []
        if (parent as boolean) {
            ancestry.add(parent)
            ancestry.addAll(parent.ancestors)
        }
        return ancestry
    }

    boolean hasJurisdiction() {
        return jurisdiction.isDefined()
    }

    List<Ref> getRoles() {
        return positions.roles.flatten()
    }

    boolean hasRole(Ref role) {
        return positions.any {position -> position as boolean && position.hasRole(role) }
    }

    boolean employs(Ref individual) {
        return jobs.any {job -> job.individual == individual}
    }

    // Queries

    List<Ref> findAllSubOrganizations() {
        Set<Ref> subs = new HashSet()
        project.organizations {org ->
            Ref orgParent = org.parent
            if (orgParent as boolean && orgParent == this.reference) {
                subs.add(org)
                subs.addAll(org.findSubOrganizations())
            }
        }
        return subs as List<Ref>
    }

    // end queries

   // TODO
    public boolean hasAccessTo(Ref resource) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean hasJobWith(Ref resource) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<Responsibility> getResponsibilities() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean hasLocation() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isAnIndividual() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }
}