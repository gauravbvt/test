package com.mindalliance.channels.ifm.vocabulary

import com.mindalliance.channels.ifm.responsibility.Responsibility
import com.mindalliance.channels.ifm.domain.InformationDefinition

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 12:49:07 PM
*/
class Role extends Category {

    List<Responsibility> responsibilities = []
    List<InformationDefinition> expertise = []

    Set keyProperties() {
        return (super.keyProperties() + ['name', 'description']) as Set
    }

    boolean isDefined() {
        return super.isDefined() && name && (responsibilities.any{it.isDefined()} || expertise.any {it.isDefined})
    }


}