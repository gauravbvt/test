package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ifm.location.GeoLocation
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.matching.TagAnalyst
import com.mindalliance.channels.ifm.location.RelativeLocation
import com.mindalliance.channels.ifm.location.RelativeLocation

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 8:46:42 PM
 */
class LocationDefinition extends Definition {  // A location is defined in terms of its attributes and of another absolute or relative location

    public static List<String> RelationChoices = ['within', 'nearby']

    boolean negated = false // if affirmed, all tests must succeed. if negated, all tests must fail (negated = anywhere but there)
    // whether the location is a place and if so what kind of place it is
    List<TagSet> placeTagSets = []  // classification -- OR-ed - if set, the location must be a place of any of these types (tagset = a type)
    // the location is either specified by its relative geolocation
    String relation = 'within' // else 'nearby'
    Location absoluteLocation = new Location()  // A given location...
    RelativeLocation relativeLocation = new RelativeLocation()   // xor the locatin or jurisdiction of an agent or event

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['relationChoices', 'within', 'nearby', 'aRelativeLocation'])
    }

    Class<? extends Defineable> getMatchingDomainClass() {
        return Location.class
    }

    boolean isDefined() {
        return negated || placeTagSets || absoluteLocation.isDefined() || relativeLocation.isDefined() 
    }

    void reset() {
        negated = false;
        placeTagSets = []
        relation = "within"
        absoluteLocation = new Location()
        relativeLocation = new RelativeLocation()
    }

    boolean isWithin() {
        return relation == 'within'
    }

    boolean isNearby() {
        return relation == 'nearby'
    }

    boolean isARelativeLocation() { // matching against a relative location, else an absolute location
        return relativeLocation.isDefined()
    }

    public boolean matchesAll() {
        return !TagAnalyst.tagSetsDefined(placeTagSets) && !absoluteLocation.isDefined() && !relativeLocation.isDefined();
    }

    protected MatchResult doMatch(Defineable bean) {
        MatchResult result = doAffirmedMatch(bean)
        if (negated) {
            result.level = result.level.opposite()
            result.summary = '(Negated) ' + result.summary
        }
        return result
    }

    private MatchResult doAffirmedMatch(Defineable bean) {
        Location location = (Location) bean
        Level minLevel = Level.HIGHEST
        Map<String, Object> matches = [:]
        StringBuilder summary = new StringBuilder()
        // match as place if placeTagSets defined
        if (TagAnalyst.tagSetsDefined(placeTagSets)) {
            Level level
            if (location.isAPlace()) {
                level = TagAnalyst.bestTagSetMatch(placeTagSets, location.placeTags)
                summary.append("${level.confidence()} place tags ok. ")
                matches['place tags'] = level
            }
            else {
                level = Level.NONE
                summary.append("$location is not a place. ")
                matches['place tags'] = level
            }
            minLevel = level // first test: can't be higher than HIGHEST
        }
        Level level
        if (isRelativeLocation()) {
            // compare to relative location
            Location otherLocation = relativeLocation.location
            if (otherLocation.isDefined()) {
                level = matchWithLocation(location, otherLocation, minLevel, summary, matches)
            }
            else { // relative location not found
                level = Level.NONE
                summary.append("The relative location is not found. ")
                matches['relative'] = minLevel
            }
        }
        else {
            // compare to absolute location
            level = matchWithLocation(location, absoluteLocation, minLevel, summary, matches)
        }
        if (level < minLevel) minLevel = level
        return new MatchResult(level: minLevel, summary: summary.toString(), matches: matches)
    }

    private Level matchWithLocation(Location location, Location otherLocation, Level minLevel, StringBuilder summary, Map<String, Object> matches) {
        Level level
        if (otherLocation.isAPlace()) {
            if (location.isAPlace()) {
                level = comparePlaces(location.place, otherLocation.place, within, minLevel, summary, matches)
            }
            else {
                level = Level.NONE
                summary.append("${level.confidence()} $location is not a place")
                matches['place'] = level
            }
        }
        else {
            level = compareGeoLocations(location.effectiveGeoLocation, otherLocation.effectiveGeoLocation, within, minLevel, summary, matches)
        }
        return (level < minLevel) ? level : minLevel
    }

    private Level comparePlaces(Ref place, Ref otherPlace, boolean within, Level minLevel, StringBuilder summary, Map<String, Object> matches) {
        Level level
        if (isWithin()) {
            if (place.isWithin(otherPlace)) {
                level = Level.HIGHEST
                summary.append("${level.confidence()} ${place.about()} is within ${otherPlace.about()}")
                matches['place'] = level
            }
            else {
                level = Level.NONE
                summary.append("${level.confidence()} ${place.about()} is not within ${otherPlace.about()}")
                matches['place'] = level
            }
        }
        else { // nearby
            level = place.isNearby(otherPlace)
            summary.append("${level.confidence()} ${place.about()} is nearby ${otherPlace.about()}. ")
            matches["${level.confidence()} ${relation} ${absoluteOrRelative()} location"] = level
        }
        return (level < minLevel) ? level : minLevel
    }

    private Level compareGeoLocations(GeoLocation geo, GeoLocation otherGeo, boolean within, Level minLevel, StringBuilder summary, Map<String, Object> matches) {
        Level level = null
        if (isWithin()) {
            if (geo.isWithin(otherGeo)) {
                level = Level.HIGHEST
                summary.append("${level.confidence()} $geo is within $otherGeo . ")
                matches['geolocation'] = level
            }
            else {
                level = Level.NONE
                summary.append("${level.confidence()} $geo is not within $otherGeo . ")
                matches['geolocation'] = level
            }
        }
        else {
            level = geo.isNearby(otherGeo)
            summary.append("${level.confidence()} $geo is nearby $otherGeo . ")
            matches['geolocation'] = level

        }
        return (level < minLevel) ? level : minLevel
    }

    private String absoluteOrRelative() {
        return isRelativeLocation() ? 'relative' : 'absolute'
    }

    private Location otherLocation() {
        return isRelativeLocation() ? relativeLocation.location : absoluteLocation
    }

    boolean implies(MatchingDomain matchingDomain) {
        LocationDefinition other = (LocationDefinition) matchingDomain
        // Must compare apples with apples
        if (negated != other.negated) return false
        if (within != other.within) return false
        if (negated) { // then reverse test
            return other.doesImply(this)
        }
        else {
            return this.doesImply(other)
        }
    }

    private boolean doesImply(LocationDefinition other) {
        if (other.matchesAll()) return true
        if (matchesAll()) return false // fails because other does not match all
        if (!TagAnalyst.implyTagSets(placeTagSets, other.placeTagSets)) return false
        if (isRelativeLocation()) {
            if (!other.isRelativeLocation()) {
                return false
            }
            else {
               if (!relativeLocation.implies(other.relativeLocation)) return false
            }
        }
        else {
            if (!absoluteLocation.isWithin(other.absoluteLocation)) return false
        }
        return true
    }

}