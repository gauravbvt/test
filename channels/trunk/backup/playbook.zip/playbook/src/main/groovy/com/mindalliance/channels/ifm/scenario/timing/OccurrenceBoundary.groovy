package com.mindalliance.channels.ifm.scenario.timing

import com.mindalliance.channels.ifm.scenario.timing.Boundary

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 4:57:15 PM
 */
class OccurrenceBoundary extends Boundary {

    boolean start = true

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['end', 'outcomeBoundary'])
    }

    boolean isEnd() {
        return !start
    }

    boolean isOutcomeBoundary() {
        return false
    }

    String toString() {
        return "${start ? 'start' : 'end'}"
    }

    String about() {
        return "${start ? 'start' : 'end'} of ${occurrence.about()}"
    }
    
}