package com.mindalliance.channels.graph

import org.joda.time.Duration
import com.mindalliance.channels.ifm.scenario.*
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.support.models.Container
import com.mindalliance.channels.ref.Referenceable
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.analysis.scenario.Timeline
import com.mindalliance.channels.analysis.scenario.Timeline
import com.mindalliance.channels.ifm.scenario.action.Action
import com.mindalliance.channels.analysis.scenario.Timeline
import com.mindalliance.channels.ifm.scenario.event.Event

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 4, 2008
 * Time: 9:20:15 AM
 */
class TimelineGraph extends ChannelsGraph {

    TreeMap<Duration, Set<Event>> timed = new TreeMap<Duration, Set<Event>>()
    Set<Ref> allEvents = new HashSet<Ref>()

    TimelineGraph(Container container) {
        super(container)
    }

    Map getStyleTemplate() {
        return super.getStyleTemplate() + [
                time: [shape: 'plaintext', fontsize: '9'],
                time_edge: [dir: 'none']
        ]
    }

    void buildContent(GraphVizBuilder builder) {
        processData()
        buildTimePoints(builder)
        buildOccurrences(builder)
        buildTimings(builder)
        buildCausality(builder)
        super.buildContent(builder)
    }

    List<Ref> allElements() {
        return allEvents as List<Ref>
    }

    void processData() {
        container.iterator().each {ref ->
            Referenceable el = ref.deref()
            switch (el) {
                case Event.class: processEvent((Event) el); break
                case Timeline.class: processScenario((Timeline) el); break
            //default: Logger.getLogger(this.class).warn("Can't display $el")
            }
        }
    }

    void processEvent(Event event) {
        Duration start = event.startTime
        if (timed[start] == null) timed[start] = new HashSet<Event>()
        timed[start].add(event)
        allEvents.add(event.reference)
    }

    void processScenario(Timeline pb) {   // TODO - not needed
        pb.events.each {ref ->
            if (ref as boolean) processEvent((Event) ref.deref())
        }
        pb.actions.each {ref ->
            if (ref as boolean) processEvent((Event) ref.deref())
        }
    }

    void buildTimePoints(GraphVizBuilder builder) {
        String priorName = null
        timed.keySet().each {dur ->
            String durText = durationToText(dur)
            builder.node(name: durText, label: durText, template: 'time')
            if (priorName) builder.edge(source: priorName, target: durText, template: 'time_edge')
            priorName = durText
        }
    }

    void buildOccurrences(GraphVizBuilder builder) {
        timed.each {dur, occSet ->
            occSet.each {occ ->
                if (occ instanceof Action && occ.actor as boolean) {
                    Agentable agent = (Agentable) occ.actor.deref()
                    builder.cluster(name: nameFor(occ) + nameFor(agent), label: labelFor(agent), URL: urlFor(agent), template: 'agent') {
                        builder.node(name: nameFor(occ), label: labelFor(occ), URL: urlFor(occ), template: templateFor(occ))
                    }
                }
                else {
                    builder.node(name: nameFor(occ), label: labelFor(occ), URL: urlFor(occ), template: templateFor(occ))
                }

            }
        }
    }

    void buildTimings(GraphVizBuilder builder) {
        timed.each {dur, occSet ->
            builder.subgraph(rank: 'same') {
                builder.node(name: durationToText(dur))
                occSet.each {occ ->
                    builder.node(name: nameFor(occ))
                }
            }
        }
    }

    void buildCausality(GraphVizBuilder builder) {
        timed.each {dur, occSet ->
            occSet.each {occ ->
                Ref eventRef = occ.timing.prior
                if (eventRef as boolean && allEvents.contains(eventRef)) {
                    Event prior = (Event) eventRef.deref()
                    builder.edge(source: nameFor(prior), target: nameFor(occ))
                }
            }
        }
    }

}