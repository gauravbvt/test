package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ifm.Timespan
import com.mindalliance.channels.ifm.domain.AgentSpecification
import com.mindalliance.channels.ifm.domain.FactDefinition
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.domain.InformationDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 17, 2008
 * Time: 8:00:35 PM
 */
class SharingCommitment extends Information {

    Ref resource   // who commits
    InformationDefinition informationSpec = new FactDefinition()  // to share what kind of information
    AgentSpecification recipient = new AgentSpecification()   // with whom
    boolean willNotify = false // by notification or by answering
    Timespan maxDelay = new Timespan()  // how soon after knowing or being asked

    boolean isDefined() {
        return super.defined && resource as boolean && !informationSpec.matchesAll()
    }

    public String makeLabel(int maxWidth) {
        // todo
    }
}