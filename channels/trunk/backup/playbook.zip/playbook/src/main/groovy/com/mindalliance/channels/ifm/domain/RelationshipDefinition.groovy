package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.support.Level
import com.mindalliance.channels.matching.TagAnalyst
import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.analysis.scenario.agent.AgentRelationship

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 8:45:07 PM
 */
class RelationshipDefinition extends Definition {

    TagSet tagSet = new TagSet() // ORed Tags -- classification
    AgentSpecification withAgentSpec = new AgentSpecification()

    Class<? extends Defineable> getMatchingDomainClass() {
        return AgentRelationship.class
    }

    boolean matchesAll() {
        return !tagSet.isDefined() && withAgentSpec.matchesAll()
    }

    protected MatchResult doMatch(Defineable bean) {
        AgentRelationship agentRelationship = (AgentRelationship) bean
        Level minLevel = Level.HIGHEST
        Map<String, Object> matches = [:]
        StringBuilder summary = new StringBuilder()
        // Tags
        Level level = TagAnalyst.bestTagSetMatch(tagSet, agentRelationship.tag)
        matches['tag'] = level
        summary.append("${level.confidence()} tag ok")
        if (level < minLevel) minLevel = level
        minLevel = findMatchLevel(agentRelationship.withAgent, withAgentSpec, minLevel, summary, matches)
        return new MatchResult(level: minLevel, summary: summary.toString(), matches: matches)
    }


    boolean implies(MatchingDomain matchingDomain) {
        RelationshipDefinition other = (RelationshipDefinition) matchingDomain
        if (other.matchesAll()) return true
        if (!TagAnalyst.implyTagSets(tagSets, other.tagSets)) return false
        if (!withAgentSpec.implies(other.withAgentSpec)) return false
        return true;
    }


}