package com.mindalliance.channels.ifm.vocabulary

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 9:38:25 PM
 */
class Risk extends Category {

    List<Ref> assignedRoles = [] // what roles are assigned to managing this kind of risk
}