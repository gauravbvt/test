package com.mindalliance.channels.ifm.scenario.action.performance

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.Timespan
import com.mindalliance.channels.ifm.Cost
import com.mindalliance.channels.ifm.Probability

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 26, 2008
 * Time: 3:18:16 PM
 */
abstract class Performance extends BeanImpl {

    Comparable defaultValue   // value if no capability-related performances defined or none apply
    List<PerformanceLevel> performanceLevels  = [] // capability-related performances
    boolean minimized = false  // whether the lowest value is sought given capabilities
    boolean allCapable = true // capability requirements apply to any or all actors  (meaningful for Group only: if true all members must meet these capability levels, else any member 

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['maximized'])
    }

    boolean isDefined() {
        defaultValue != null
    }

    Comparable getValue(Ref resource) {
        return defaultValue // TODO -- get maximized/minimized value based on resource capabilities
    }

    Comparable copyDefaultValue() {
        switch (comparableClass()) {
            case Timespan.class: return new Timespan(amount:defaultValue.amount, unit:defaultValue.unit)
            case Cost.class: return new Cost(value: defaultValue.value)
            case Probability.class: return new Probability(value: defaultValue.value)
            default: throw new RuntimeException("Unexpected performance value class ${comparableClass()}")
        }
    }

    boolean isMaximized() {
        return !minimized
    }

    Class comparableClass() {
        return defaultValue.class
    }

}