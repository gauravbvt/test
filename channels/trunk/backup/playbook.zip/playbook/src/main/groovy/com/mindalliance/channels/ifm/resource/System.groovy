package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.query.Query
import com.mindalliance.channels.ifm.resource.organization.InOrganization

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 11:28:47 AM
*/
class System extends AbstractResource implements InOrganization, Individual {

    List<Ref> adminPositions = []
    String instructions = '' // access instructions

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['jobs'])
    }

    Set hiddenProperties() {
        return (super.hiddenProperties() + ['instructions']) as Set
    }

    List<Ref> getJobs() {
        return (List<Ref>)Query.execute(project, "findAllJobsOf", this.reference)
    }
}