package com.mindalliance.channels.ifm.scenario.action.performance

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.Probability

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 26, 2008
 * Time: 3:31:12 PM
 */
class ProbabilityPerformance extends Performance {

    ProbabilityPerformance() {
        defaultValue = new Probability()
    }

    static ProbabilityPerformance minimized() {
        return new ProbabilityPerformance(defaultValue: new Probability(value: 0.0), minimized: true )
    }

    static ProbabilityPerformance maximized() {
        return new ProbabilityPerformance(defaultValue: new Probability(value: 100.0), minimized: false )
    }

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['probability'])
    }

    Probability getProbability() {
        return (Probability)defaultValue
    }

    Probability getProbability(Ref resource) {
        return (Probability)getValue(resource)
    }

}