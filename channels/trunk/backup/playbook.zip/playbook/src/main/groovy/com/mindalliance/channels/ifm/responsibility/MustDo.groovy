package com.mindalliance.channels.ifm.responsibility

import com.mindalliance.channels.ifm.domain.TaskDefinition
import com.mindalliance.channels.ifm.domain.ActionDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 4, 2008
 * Time: 4:04:05 PM
 */
class MustDo extends MustKnow {   // what must be done (task or communication) if something is known

    ActionDefinition actionSpec = new TaskDefinition()  // do a matching task

    boolean isDefined() {
        return super.isDefined() && !actionSpec.matchesAll()
    }

}