package com.mindalliance.channels.ifm

import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ref.Bean

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 11:09:00 AM
*/
interface Locatable {

    Location getLocation()

}