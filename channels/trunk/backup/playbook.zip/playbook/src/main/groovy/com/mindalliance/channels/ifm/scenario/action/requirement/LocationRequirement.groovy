package com.mindalliance.channels.ifm.scenario.action.requirement

import com.mindalliance.channels.ifm.domain.LocationDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 1:21:05 PM
 */
class LocationRequirement extends Requirement {  // agent must have matching location

    LocationDefinition locationSpec = new LocationDefinition()

    boolean isDefined() {
        return !locationSpec.matchesAll()
    }

}