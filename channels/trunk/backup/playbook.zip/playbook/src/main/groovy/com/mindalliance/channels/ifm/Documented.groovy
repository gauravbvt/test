package com.mindalliance.channels.ifm

import com.mindalliance.channels.ifm.Documentation

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 4, 2008
 * Time: 12:57:09 PM
 */
interface Documented {

    Documentation getDocumentation()

}