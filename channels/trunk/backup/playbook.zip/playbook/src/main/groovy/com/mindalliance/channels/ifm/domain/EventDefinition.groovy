package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.scenario.event.Event
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.matching.TagAnalyst
import com.mindalliance.channels.ifm.scenario.event.Event

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 5:34:24 PM
 */
class EventDefinition extends Definition {

    TagSet tagSet = new TagSet() // OR-ed self-evident classifications of the event --> what
    LocationDefinition locationSpec = new LocationDefinition() // --> where
    EventSpecification priorEventSpec = new EventSpecification() // --> when/why

    Class<? extends Defineable> getMatchingDomainClass() {
        return Event.class
    }

    boolean matchesAll() {
        return !tagSet.isDefined() && locationSpec.matchesAll() && priorEventSpec.matchesAll()
    }

    protected MatchResult doMatch(Defineable bean) {
        Event event = (Event)bean
        Level minLevel = Level.HIGHEST
        Map<String, Object> matches = [:]
        StringBuilder summary = new StringBuilder()
        // classification
        Level level = TagAnalyst.bestTagSetMatch(tagSet, event.tag)
        matches["classification"] = level
        summary.append("${level.confidence()} event classification is ok")
        if (level < minLevel) minLevel = level
        // location
        minLevel = findMatchLevel((List<Defineable>)event.location, locationSpec, minLevel, summary, matches)
        // antecedents
        minLevel = findMatchLevel((List<Defineable>)event.antecedents, priorEventSpec, minLevel, summary, matches)
        return new MatchResult(level: minLevel, summary: summary.toString(), matches: matches)
    }

    protected boolean doesImply(MatchingDomain matchingDomain) {
        EventDefinition other = (EventDefinition)matchingDomain
        if (!TagAnalyst.implyTagSets(tagSet, other.tagSet))
        if (!locationSpec.implies(other.locationSpec)) return false
        if (!priorEventSpec.implies(other.priorEventSpec)) return false
        return true
    }


}