package com.mindalliance.channels.ifm.resource.organization

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.LimitationsOnUse
import com.mindalliance.channels.ifm.Described
import com.mindalliance.channels.ifm.Timespan
import com.mindalliance.channels.ifm.Named
import com.mindalliance.channels.ifm.resource.organization.InOrganization
import com.mindalliance.channels.ifm.Channels
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.Documentation
import com.mindalliance.channels.ifm.Documented
import com.mindalliance.channels.ifm.ContainedElement
import com.mindalliance.channels.ifm.domain.FactDefinition
import com.mindalliance.channels.ifm.domain.AgentSpecification
import com.mindalliance.channels.ifm.domain.ActionDefinition
import com.mindalliance.channels.ifm.domain.TaskDefinition

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 10:43:29 AM
*/
class SharingAgreement extends ContainedElement implements Named, Described, Documented, InOrganization {

    String name = ''
    String description = ''
    Ref beneficiary   //  -- organization
    InformationDefinition informationSpec = new FactDefinition()
    List<Ref> senderRoles = []     // who would communicate -- adds awareness responsibility
    List<Ref> recipientRoles = []  // to whom
    boolean willNotify = false    // else will respond to requests
    Timespan maxDelay = new Timespan(amount:0)
    AgentSpecification privacy = new AgentSpecification()
    ActionDefinition restrictedUse = new ActionDefinition()
    Documentation documentation = new Documentation()


    Set keyProperties() {
        return (super.keyProperties() + ['name', 'description']) as Set
    }

    boolean isDefined() {
        return super.isDefined() && informationSpec.isDefined() && beneficiary as boolean
    }

    String about() {
        String beneficiaryName = (beneficiary as boolean) ? beneficiary.name : "undefined beneficiary"
        String delivery = willNotify ? "notify" : "answer"
        return "${organization.name} shall $delivery $beneficiaryName"
    }

    boolean isProjectElement() {
        return true
    }

    String toString() {
        return name ?: Channels.UNNAMED
    }

    // queries

    List<String> findAllTopics() {
        return informationSpec.eois.collect {eoi -> eoi.topic}
    }
    // end queries

}