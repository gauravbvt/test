package com.mindalliance.channels.ifm.location

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ifm.location.GeoLocation
import com.mindalliance.channels.matching.TagAnalyst

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 22, 2008
 * Time: 7:43:03 PM
 */
class RelativeLocation extends BeanImpl {

    // Relative to...
    Ref locatable                 // something's or someone's location
    Ref jurisdictionable   // XOR - // something's or someone's jurisdiction
    // expanded to encompassing place or area
    TagSet placeTags = new TagSet() // if defined, a kind of place  (e.g. the building in which the given agent is located)
    Ref areaType // XOR -- if set, a kind of area (e.g. the state in which the given agent has a jurisdiction)

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['location'])
    }

    boolean isDefined() {
        return locatable as boolean || jurisdictionable as boolean
    }

    boolean implies(RelativeLocation other) {
        // fail if not relative to the same thing
        if (other.locatable != locatable) return false
        if (other.jurisdictionable != jurisdictionable) return false
        // fail if not broadening in the same ways
        if (placeTags.isDefined() && other.areaType as boolean) return false
        if (areaType as boolean && other.placeTags.isDefined()) return false
        // fail if broadening not implied
        if (placeTags.isDefined()) {
            if (!TagAnalyst.implyTagSets([placeTags], [other.placeTags])) return false
        }
        if (areaType as boolean) {
            if (!areaType.implies(other.areaType)) return false
        }
        return true
    }

    void setLocatable(Ref loc) {
        this.locatable = loc
        this.jurisdictionable = null
    }

    void setJurisdictionable(Ref jur) {
        this.jurisdictionable = jur
        this.locatable = null
    }

    void setPlaceTags(TagSet tagSet) {
        this.placeTags = tagSet
        this.areaType = null
    }

    void setAreaType(Ref type) {
        this.areaType = type
        this.placeTags = new TagSet()
    }

    Location getLocation() { // find the agent's or event's location/jurisdiction and then broaden as required
        Location location = new Location()
        if (locatable as boolean) {
            location = locatable.location
        }
        if (jurisdictionable as boolean) {
            location = jurisdictionable.jurisdiction
        }
        if (location.isDefined()) {
            location = broaden(location)
        }
        return location
    }

    Location broaden(Location location) {
        if (placeTags.isDefined()) {
            if (location.isAPlace()) {
                Ref place = location.place
                Ref enclosing = place.broadenedTo(placeTags) // find the first matching enclosing place, null if none
                return new Location(place:enclosing)
            }
            else {
                GeoLocation geo = location.effectiveGeoLocation.broadenedTo(areaType)
                return new Location(geoLocation:geo)
            }
        }
    }

}