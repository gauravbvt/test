package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.support.Level

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 9:36:55 AM
 */
class MatchResult {

    Level level = Level.NONE
    String summary = ''
    Map<String, Object> matches = [:]      // String => Level or MatchResult

    String toString() {
        String s = "${level.confidence()}: summary\n"
        matches.each {k,v ->
            Level lev = (Level)v
            s += "\t$k (${lev.confidence()})\n"
        }
        return s
    }

}