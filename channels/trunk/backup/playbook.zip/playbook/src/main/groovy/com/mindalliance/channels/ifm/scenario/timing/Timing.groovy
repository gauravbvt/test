package com.mindalliance.channels.ifm.scenario.timing

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.scenario.timing.Boundary

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 16, 2008
 * Time: 11:53:53 AM
 */
abstract class Timing extends BeanImpl {  // establishes a sequencing of occurrences

    List<Boundary> boundaries = [] // occurrence time boundaries (start, end, success, failure)
    boolean afterFirst = true // after any boundary reached, else at all boundaries reached

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['afterLast'])
    }

    public boolean isDefined() {
        return boundaries.every {it.defined}
    }

    String toString() {
        return "${afterFirst ? 'after any of' : 'after all of'} (${boundaries.join(',')})"
    }

    String about() {
        if (!boundaries) return ''
        if (boundaries.size == 1) {
           return "after ${boundaries[0].about}"
        }
        else {
            return "${afterFirst ? 'after any of' : 'after all of'} ${boundaries.collect{it.about()}.join(',')}"
        }
    }

    boolean isAfterLast() {
        return !afterFirst
    }

}