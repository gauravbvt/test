package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.mem.ApplicationMemory
import com.mindalliance.channels.ifm.resource.AccessRight
import com.mindalliance.channels.ifm.ContainedElement
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.Documentation
import com.mindalliance.channels.analysis.scenario.agent.Agent

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 17, 2008
 * Time: 11:16:29 AM
 */
abstract class AbstractResource extends ContainedElement implements Resource {

    String name = ''
    String description = ''
    List<ContactInfo> contactInfos = []
    Location location = new Location()
    List<AccessRight> accessRights = []
    List<Relationship> relationships = []
    List<Capability> capabilities = []
    List<InformationDefinition> knowledge = []
    boolean activated = true
    Documentation documentation = new Documentation()

    Set keyProperties() {
        return (super.keyProperties() + ['name', 'description']) as Set
    }

    boolean isDefined() {
        return name as boolean
    }

    boolean hasJurisdiction() {
        return false
    }

    boolean hasLocation() {
        return location.isDefined()
    }

    String toString() { name ?: "Unnamed" }

    /**
     * Return child elements that a project user may want to create.
     */
    static List<Class<?>> contentClasses() {
        return (List<Class<?>>) [
                AccessRight.class
        ]
    }

    void addContents(List<Ref> result) {
         result.addAll(accessRights)
     }

    @Override
    void beforeStore(ApplicationMemory memory) {
        super.beforeStore(memory)
        if (location) location.detach()
    }

    @Override
    void changed(String propName) {
        if (propName == 'location') {
            location.detach()
        }
        super.changed(propName)
    }

    /*   public List<Ref> getResourcesAt(Ref event) {
            return [this.reference]
        }
    */

    Location getLocation() {
        return location
    }


    boolean isLocatedWithin(Location loc) {
        return this.location.isWithin(loc)
    }

    boolean hasAccessTo(Ref agentable) {
        boolean result = agentable.accessRights.any {access ->
            access.granteeSpec.matches(Agent.from(agentable)) 
        }
        return result
    }

    boolean hasJobWith(Ref org) {
        return org.employs(this.reference)
    }

    // Queries


    // end queries


}