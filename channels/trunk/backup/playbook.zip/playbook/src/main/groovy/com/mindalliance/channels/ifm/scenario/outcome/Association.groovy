package com.mindalliance.channels.ifm.scenario.outcome

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.resource.Relationship

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 1:56:17 PM
 */
class Association extends ContextChange {

    Ref resource
    boolean added = true // else removed
    Relationship relationship = new Relationship()

    boolean isDefined() {
        return resource as boolean && relationship.defined
    }
}