package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.matching.TagAnalyst

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 4, 2008
 * Time: 10:30:46 AM
 */
class Categorization extends BeanImpl {

    TagSet includedTags = new TagSet()
    TagSet excludedTags = new TagSet()

    boolean isDefined() {
        return includedTags.defined
    }

    boolean implies(Categorization other) {
        if (!TagAnalyst.implyTagSets(includedTags, other.includedTags)) return false
        return TagAnalyst.implyTagSets(excludedTags, other.excludedTags)
    }

}