package com.mindalliance.channels.ifm.scenario.event

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.Probability
import com.mindalliance.channels.ifm.Cost
import com.mindalliance.channels.ifm.Timespan
import com.mindalliance.channels.ref.impl.BeanImpl

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 4, 2008
 * Time: 5:50:35 PM
 */
class Consequence extends BeanImpl {

    // x(0) = initial
    // linear: x(t+tick) = x(t) + k
    // geometric: x(t+tick) = x(t) * k
    // exponential: x(t) = x(0) * k ** (t/tick)
    static List<String> GrowthModels = ['linear', 'geometric', 'exponential']

    Ref risk // a risk category
    Ref organization   // who pays/benefits
    Probability probability = new Probability()  // probability of consequence being realized
    boolean isLoss = true // else is gain
    Cost initial = new Cost()
    Cost max // none if null -- limit on upper value
    Timespan tick = new Timespan()
    String growth = "linear"
    float k = 0.0

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['growthModels'])
    }

    boolean isDefined() {
        return organization as boolean && tick.isDefined()
    }
}