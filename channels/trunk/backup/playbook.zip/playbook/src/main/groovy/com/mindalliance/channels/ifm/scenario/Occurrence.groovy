package com.mindalliance.channels.ifm.scenario

import com.mindalliance.channels.ifm.*
import com.mindalliance.channels.ifm.scenario.timing.Timing
import com.mindalliance.channels.ifm.scenario.outcome.Outcome
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 25, 2008
 * Time: 7:51:05 PM
 */
abstract class Occurrence extends ContainedElement implements InScenario, Named, Described {

    String name = ''
    String description = ''
    List<Outcome> outcomes = [] // changes to the scenario's context caused by the occurrence

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['planPath', 'planName', 'antecedentPlanName', 'antecedent', 'antecedents', 'incident'])
    }

    Set keyProperties() {
        return (super.keyProperties() + ['description']) as Set
    }

    Set hiddenProperties() {
        return (super.hiddenProperties() + ['timing', 'subPlanName']) as Set
    }

    String toString() {
        return name ?: Channels.UNNAMED
    }

    abstract Timespan getDefaultDuration();

    abstract Timing getTiming();

    boolean hasPrior(Ref occurrence) {
        return timing.boundaries.occurrence.flatten().contains(occurrence)
    }

    boolean isIncident() {
        return timing.boundaries.isEmpty()
    }

    List<Ref> getAntecedents() {
        return timing.boundaries.occurrence.flatten()
    }

    // Query

    List<Ref> findAllNecessaryAntecedents() {
        Set<Ref> set = new HashSet<Ref>()
        if (timing.isAfterLast() || timing.boundaries.size() == 1) {
            List<Ref> priors = timing.boundaries.occurrence
            set.addAll(priors)
            (priors - set).each {occ -> set.addAll(occ.findAllNecessaryAntecedents())}
        }
        return set as List<Ref>
    }

    List<Ref> findCandidateAntecedents() {  // any occurrence other than those already guaranteed to be antecedents
        return scenario.occurrences - antecedents
    }
    

    // End query


}