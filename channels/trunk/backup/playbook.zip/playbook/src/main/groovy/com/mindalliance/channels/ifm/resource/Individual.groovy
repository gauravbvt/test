package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 18, 2008
 * Time: 2:04:19 PM
 */
interface Individual {

    List<Ref> getJobs()

}