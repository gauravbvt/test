package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.Overridable

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 11:18:04 AM
*/
class ContactInfo extends BeanImpl implements Overridable {

    Ref medium // one of Medium
    String endPoint = ''

    boolean isDefined() {
        return medium as boolean
    }

    boolean overrides(Overridable other) {     // override on effectiveness
        ContactInfo contactInfo = (ContactInfo)other
        return medium == contactInfo.medium && endPoint == contactInfo.endPoint
    }
}