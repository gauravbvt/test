package com.mindalliance.channels.ifm.scenario.outcome

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 1:58:27 PM
 */
class Activation extends ContextChange { // Change in an activation status

    Ref activatable
    boolean activated = true

    boolean isDefined() {
        return activatable as boolean
    }
    
}