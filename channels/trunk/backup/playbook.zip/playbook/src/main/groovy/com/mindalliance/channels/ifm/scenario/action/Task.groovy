package com.mindalliance.channels.ifm.scenario.action

import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.scenario.outcome.Termination

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 1:44:43 PM
*/
class Task extends Action {

    TagSet tags = new TagSet()
    String purpose = '' // the purpose of the task as opposed to its nature

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['outcomeEventsOrViolations'])
    }

    boolean isDefined() {
        return super.isDefined() &&  tags.isDefined()
    }

    List<Ref> getOutcomeEventsOrViolations() {
        return (List<Ref>)scenario.eventsOrViolations.findAll {event -> event.antecedent == this.reference}
    }

}