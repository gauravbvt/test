package com.mindalliance.channels.ifm.resource.organization

import com.mindalliance.channels.ifm.*
import com.mindalliance.channels.ifm.domain.AgentSpecification
import com.mindalliance.channels.ifm.domain.FactDefinition
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.resource.organization.InOrganization
import com.mindalliance.channels.ifm.scenario.action.Communication

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 12:38:52 PM
*/
class Policy extends ContainedElement implements Named, Described, Activatable, Documented, InOrganization {

    // Policy if any of listed situation is current and not if any of excepted situation is current
    // restricted: specified parties *may* share specified info (source -> recipient),
    //             but subject to limitations on use
    // required: specified parties *must* share specified info, but subject to ....
    // forbidden: specified parties are forbidden to share specified info (limitations on use are N/A)

    static final public List<String> edictKinds = ['forbidden', 'required', 'restricted']

    String name = ''
    String description = ''
    boolean activated = true // activated by default
    String edict = 'restricted'
    AgentSpecification senderSpec = new AgentSpecification()    // applies to what kinds of senders
    AgentSpecification recipientSpec = new AgentSpecification()  // applies to what kinds of recipients
    List<String> relationshipNames = [] // required relationships from sender to recipient (ORed) for policy to apply
    InformationDefinition informationSpec = new FactDefinition() // specification of information (not) to be shared -- required
    LimitationsOnUse limitationsOnUse = new LimitationsOnUse() // constrained (interdicted|obligation-causing) usages of the information
    Documentation documentation = new Documentation()

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['edictKinds','restricted', 'required', 'forbidden'])
    }

    Set keyProperties() {
        return (super.keyProperties() + ['name', 'description']) as Set
    }

    boolean isDefined() {
        return super.isDefined() && !senderSpec.matchesAll() && !informationSpec.matchesAll() && (!isRestricted() || limitationsOnUse.isDefined()) // at least send and information specs are defined
    }

    static List<String> getEdictKinds() {
        return  edictKinds
    }

    boolean isRestricted() {
         return edict == 'restricted'
     }

    boolean isRequired() {
         return edict == 'required'
     }

    boolean isForbidden() {
         return edict == 'forbidden'
     }

    boolean appliesTo(Communication communication) {
        return false // TODO
    }

    boolean allRestrictionsObeyed(Communication communication) {
        return false // TODO
    }

    String toString() {
        return name ?: Channels.UNNAMED
    }


}