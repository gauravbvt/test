package com.mindalliance.channels.ifm.domain


import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ifm.Timespan

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 20, 2008
 * Time: 3:18:36 PM
 */
abstract class InformationDefinition extends Definition {

    AgentSpecification sourceSpec                 // it comes from such sources
    Timespan minimumTimeToLive                    // is valid at least this long from communication

    abstract MatchResult doSpecificMatch(Information information, Level level, StringBuilder summary, Map<String, Object> matches);

    boolean matchesAll() {
        return sourceSpec.matchesAll() && minimumTimeToLive.amount == 0
    }

    protected MatchResult doMatch(Defineable bean) {
        Information info = (Information)bean
        Level minLevel = Level.HIGHEST
        Map<String, Object> matches = [:]
        StringBuilder summary = new StringBuilder()
        if (minimumTimeToLive.isShorterOrEqualTo(info.timeToLive)) {  // pass or fail
            summary.append("Information time-to-live is too short (less than $minimumTimeToLive)")
            summary.append("")
            minLevel = Level.NONE
        }
        else {
            matches['minimum time-to-live'] = Level.HIGHEST
            summary.append("Information time-to-live is long enough")
        }
        minLevel = findMatchLevel((List<Defineable>)info.sources, sourceSpec, minLevel, summary, matches)
        return doSpecificMatch(info, minLevel, summary, matches)
    }

    boolean doesImply(MatchingDomain matchingDomain) {
        InformationDefinition other = (InformationDefinition)matchingDomain
        if (!sourceSpec.implies(other.sourceSpec)) return false
        if (!minimumTimeToLive.isShorterOrEqualTo(other.minimumTimeToLive)) return false
        return true
    }

}