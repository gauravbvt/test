package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.Defineable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 9:13:59 PM
 */
class ActionDefinition extends Definition {

    protected MatchResult doMatch(Defineable bean) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected boolean doesImply(MatchingDomain matchingDomain) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Class<? extends Defineable> getMatchingDomainClass() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean matchesAll() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

}