package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ifm.Described
import com.mindalliance.channels.ifm.domain.AgentSpecification
import com.mindalliance.channels.ifm.domain.TaskDefinition
import com.mindalliance.channels.ref.impl.BeanImpl

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Mar 29, 2008
 * Time: 9:04:20 AM
 */
abstract class Information extends BeanImpl implements Described {  // information held by a resource, with attached privacy and usage constraints, and valid for some time period

    String description = ''
    AgentSpecification privacy = new AgentSpecification()   // allowed to be disseminated to whom
    TaskDefinition usageRestriction = new TaskDefinition()  // allowed to satisfy the information requirement of what kind of task
    Belief belief = new Belief() // who believes this (or not), and when 

/*    // Whether the information does not add to nor contradicts another information (i.e. the other is the same or more specific)
    boolean isComprisedIn(Information information) {
        // assumes both this and other information are defined
        assert defined && information.defined
        return this.class == information.class
    }*/

// Label in graph -- undefined information must never be shown
    abstract String makeLabel(int maxWidth)

    // Queries

    // End queries

}