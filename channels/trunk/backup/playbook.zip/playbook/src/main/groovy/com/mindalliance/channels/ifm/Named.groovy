package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.Referenceable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 4, 2008
 * Time: 1:13:46 PM
 */
interface Named {

    String getName()
}