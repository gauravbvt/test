package com.mindalliance.channels.ifm.resource.organization

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.project.InProject

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 27, 2008
 * Time: 3:20:50 PM
 */
interface InOrganization extends InProject {

    Ref getOrganization()

}