package com.mindalliance.channels.ifm

import com.mindalliance.channels.Identified
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 24, 2008
 * Time: 10:02:20 PM
 */
interface Referenced extends Identified {

    Ref getReference()

}