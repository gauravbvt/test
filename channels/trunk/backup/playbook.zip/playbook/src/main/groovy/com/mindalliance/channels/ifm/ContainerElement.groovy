package com.mindalliance.channels.ifm

import com.mindalliance.channels.util.RefUtils
import com.mindalliance.channels.ref.Referenceable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 24, 2008
 * Time: 2:55:51 PM
 */
class ContainerElement extends ContainedElement {

    boolean isDefined() {
        return true       // by default even an empty container is defined
    }

    boolean isContainerElement() {
        return true
    }

    void addElement(ModelElement element) {
        String field = RefUtils.pluralize(RefUtils.decapitalize(element.type))
        doAddToField(field, element)
    }

    Referenceable doAddToField(String field, def val) {
        Referenceable referenceable = val.deref()
        if (referenceable instanceof ContainedElement) ((ContainedElement) referenceable).setContainer(this.reference)
        return super.doAddToField(field, val)
    }

    Referenceable doRemoveFromField(String name, def val) {
        Referenceable referenceable = val.deref()
        if (referenceable instanceof ContainedElement) ((ContainedElement) referenceable).setContainer(null)
        return super.doRemoveFromField(name, val)
    }

}