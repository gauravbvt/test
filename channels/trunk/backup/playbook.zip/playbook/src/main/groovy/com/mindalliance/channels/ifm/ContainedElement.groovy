package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.project.Project
import com.mindalliance.channels.ifm.resource.organization.Organization
import com.mindalliance.channels.ifm.resource.Resource
import com.mindalliance.channels.ifm.scenario.Scenario

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 24, 2008
 * Time: 2:36:38 PM
 */
class ContainedElement extends ModelElement {

    Ref container   // can take only one container

    @Override
    protected List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['childElement', 'projectElement', 'scenarioElement',
                 'organizationElement', 'resourceElement', 'project', 'scenario', 'organization', 'resource',
                'channels'])
    }

    boolean isDefined() {
        return container as boolean
    }

    boolean isChildElement() {
        return true
    }

    void setContainer(Ref cont) {
        if (container && cont && container != cont) throw new IllegalArgumentException("Can't change from a container to another")
        this.container = cont
    }

    Ref findContainer(Class c) {
        if (!container as boolean) return null
        ContainerElement ce = (ContainerElement)container.deref()
        if (c.isAssignableFrom(ce.getClass())) {
            return container
        }
        else {
            return ce.findContainer(c)
        }
    }

    Ref getProject() {
       return findContainer(Project.class)
    }

    Ref getScenario() {   // containing Scenario or Plan
        return findContainer(Scenario.class)
    }

    Ref getResource() {
        return findContainer(Resource.class)
    }

    Ref getOrganization() {
        return findContainer(Organization.class)
    }

    Ref getChannels() {
        return findContainer(Channels.class)
    }

    boolean isProjectElement() {
        return project != null
    }

    boolean isOrganizationElement() {
        return organization != null
    }

    boolean isScenarioElement() {
        return scenario != null
    }

    boolean isResourceElement() {
        return resource != null
    }

}