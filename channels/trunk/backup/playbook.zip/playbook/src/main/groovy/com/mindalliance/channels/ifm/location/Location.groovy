package com.mindalliance.channels.ifm.location

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.Locatable
import com.mindalliance.channels.ifm.TagSet
import com.mindalliance.channels.ifm.location.GeoLocation
import com.mindalliance.channels.support.Level

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 17, 2008
 * Time: 9:50:16 AM
 */
class Location extends BeanImpl implements Locatable {

    Ref place       // a place is either a named location (possibly with a geoLocation)
    GeoLocation geoLocation = new GeoLocation()  // or else a geoLocation

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['location', 'longitude', 'latitude', 'effectiveGeoLocation', 'defined',
                                               'placeTags', 'areaType', 'APlace', 'AGeoLocation'])
    }

    boolean isDefined() {
        return place as boolean || geoLocation.isDefined()
    }

    boolean isAPlace() {
        return place as boolean
    }

    boolean isAGeoLocation() {
        return !isAPlace()
    }

    Location getLocation() {
        return this
    }

    TagSet getPlaceTags() {
        if (place as boolean) {
            return place.tags
        }
        else {
            return null
        }
    }

    Ref getAreaType() {
        if (place as boolean) {
            return null    // a place is not an area
        }
        else {
            return geoLocation.areaType
        }
    }

    String toString() {
        String s
        if (place as boolean) {
            s = "${place.name}"
        }
        else {
            s = "${geoLocation.toString()}"
        }
        return s
    }

    void setPlace(Ref place) {
        this.place = place
    }
    

    double getLongitude() {
        double longitude = -1.0
        if (place) {
            longitude = geoLocation.getLongitude()
        }
        else if (geoLocation) {
            longitude = geoLocation.getLongitude()
        }
        return longitude
    }

    double getLatitude() {
        double latitude = -1.0
        if (place) {
            latitude = geoLocation.getLatitude()
        }
        else if (geoLocation) {
            latitude = geoLocation.getLatitude()
        }
        return latitude
    }

    boolean hasLatLong() {
        boolean known = false
        if (place as boolean) {
            GeoLocation geoLocation = place.findGeoLocation()
            known = geoLocation && geoLocation.hasLatLong()
        }
        else if (geoLocation) {
            known = geoLocation.hasLatLong()
        }
        return known
    }

    boolean isWithin(Location other) {
        if (isAGeoLocation()) {
            return geoLocation.isWithin(other.effectiveGeoLocation)
        }
        else { // this is a place
            if (other.isAPlace()) {
                return this.place.isWithin(other.place)
            }
            else {
               this.effectiveGeoLocation.isWithin(other.geoLocation)
            }
        }
    }

    Level isNearby(Location other) {
        if (isAGeoLocation()) {
            return geoLocation.isNearby(other.effectiveGeoLocation)
        }
        else { // this is a place
            if (other.isAPlace()) {
                return this.place.isNearby(other.place)
            }
            else {
               this.effectiveGeoLocation.isNearby(other.geoLocation)
            }
        }
    }

    boolean isSameAs(Location other) {
        if (isAGeoLocation()) {
            return geoLocation.isSameAs(other.effectiveGeoLocation)
        }
        else { // this is a place
            if (other.isAPlace()) {
                return this.place == other.place
            }
            else {
               this.effectiveGeoLocation.isSameAs(other.geoLocation)
            }
        }
    }

    GeoLocation getEffectiveGeoLocation() {
        if (place as boolean) return place.findGeoLocation()
        else return geoLocation
    }
}