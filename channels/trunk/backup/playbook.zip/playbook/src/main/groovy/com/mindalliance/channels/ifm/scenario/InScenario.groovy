package com.mindalliance.channels.ifm.scenario

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.project.InProject

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 12, 2008
 * Time: 9:59:45 AM
 */
interface InScenario extends InProject {

    Ref getScenario()

}