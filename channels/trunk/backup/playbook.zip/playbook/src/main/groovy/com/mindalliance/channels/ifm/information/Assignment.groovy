package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ifm.information.Information

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 3, 2008
 * Time: 7:27:40 PM
 */
class Assignment extends Information {      // information about dynamic role (de)assignation

    Ref fromResource    // who assigns -- an agenteable
    Ref toResource    // who is assigned -- an agenteable
    Ref role // target assigned a role
    Location jurisdiction = new Location()  // for a jurisdiction, everywhere if not defined

    String about() {
        String what = (role as boolean) ? 'new role' : 'nothing'
        return "Assignment of $what"
    }

    boolean isDefined() {
        return super.defined && fromResource as boolean && toResource as boolean && role as boolean
    }

/*    // Whether the information does not add to nor contradicts another information (i.e. the other is the same or more specific)
    boolean isComprisedIn(Information information) {
        if (!super.isComprisedIn(information)) return false
        Assignment other = (Assignment) information
        if (fromResource != other.fromResource) return false
        if (toResource != other.toResource) return false
        if (!other.role.implies(role)) return false // the other's role must imply this role (this role represents less information)
        // the other's jurisdiction must be within this one (this jurisdiction is more vague)
        if (jurisdiction.defined) { // this information says something about jurisdiction
            if (!other.jurisdiction.isWithin(jurisdiction)) return false  // the other must too and be within this jurisdiction (be more precise)
        }
        return true
    }*/

    public String makeLabel(int maxWidth) {
        // TODO
    }
}