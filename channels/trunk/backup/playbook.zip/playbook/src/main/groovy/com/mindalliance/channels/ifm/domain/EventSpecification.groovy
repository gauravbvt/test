package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.scenario.event.Event
import com.mindalliance.channels.ifm.Defineable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 5:22:35 PM
 */
class EventSpecification extends Specification {

    Class<? extends Defineable> getMatchingDomainClass() {
        return Event.class
    }

}