package com.mindalliance.channels.ifm
/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 29, 2008
 * Time: 8:40:03 AM
 */
interface Described {

    String getDescription()

}