package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.query.Query
import com.mindalliance.channels.ifm.resource.Agentable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 17, 2008
 * Time: 11:19:24 AM
 */
class Person extends AbstractResource implements Individual {

    String firstName = ''
    String middleName = ''
    String lastName = ''

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['name', 'jobs'])
    }

    Set hiddenProperties() {
        return (super.hiddenProperties() + ['firstName', 'middleName', 'lastName']) as Set
    }

    Set keyProperties() {
        return (super.keyProperties() + ['firstName', 'middleName', 'lastName']) as Set
    }

    boolean isDefined() {
        return super.isDefined() && firstName && lastName
    }

    String getName() {
        return toString()
    }

    List<Ref> getJobs() {
        return (List<Ref>) Query.execute(project, "findAllJobsOf", this.reference)
    }


    @Override
    String toString() {
        String s = ''
        if (firstName.trim()) s += firstName
        if (middleName.trim()) {
            if (s) s += ' '
            s += middleName
        }
        if (lastName.trim()) {
            if (s) s += ' '
            s += lastName
        }
        return s
    }

    // Queries

    // end queries


}