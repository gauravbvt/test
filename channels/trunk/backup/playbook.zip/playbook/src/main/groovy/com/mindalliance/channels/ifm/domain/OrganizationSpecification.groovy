package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.resource.organization.Organization
import com.mindalliance.channels.ref.Bean

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 19, 2008
 * Time: 5:32:32 PM
 */
class OrganizationSpecification  extends Specification {

    public Class<? extends Bean> getMatchingDomainClass() {
        return Organization.class
    }

}