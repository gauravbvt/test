package com.mindalliance.channels.ifm
/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 1, 2008
 * Time: 10:35:54 AM
 */
interface Overridable {

    boolean overrides(Overridable other)
    
}