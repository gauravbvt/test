package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.TimeWindow

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 10:45:55 AM
 */
class Belief extends BeanImpl {

    Ref believer // who believes -- an agentable
    TimeWindow timeWindow = new TimeWindow()  // when does belief hold
    boolean certainty = true // if true, 100% believed, else 0% believed   -- later consider using Probability

    public boolean isDefined() {
        return believer as boolean
    }

}