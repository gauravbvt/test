package com.mindalliance.channels.ref.impl
/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 23, 2008
 * Time: 10:56:14 AM
 */
class NotModifiableException extends Exception {

    NotModifiableException() {
        super()
    }

    NotModifiableException(String message) {
        super(message)
    }

}