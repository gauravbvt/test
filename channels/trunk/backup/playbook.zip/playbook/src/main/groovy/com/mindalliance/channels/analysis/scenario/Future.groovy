package com.mindalliance.channels.analysis.scenario

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 24, 2008
 * Time: 11:12:32 AM
 */
class Future { // all occurrence that can happen after a given occurrence in a scenario

    Ref occurrence

    static Future from(Ref occurrence) {
        return new Future(occurrence: occurrence)
    }
}