package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.impl.BeanImpl
import org.joda.time.Duration

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 28, 2008
 * Time: 7:33:29 PM
 */
class Timespan extends BeanImpl implements Comparable {

    static final List<String> units = ['seconds', 'minutes', 'hours', 'days', 'weeks']

    Integer amount = 0
    String unit = 'seconds'
    Duration cachedDuration

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['cachedDuration', 'duration', 'units', 'defined'])
    }

    boolean isDefined() {
        return amount != 0
    }

    void setAmount(int val) {
        amount = val
        detach()
    }

    void setUnit(String unit) {
        this.unit = unit
        detach()
    }

    void detach() {
        cachedDuration = null
    }

    Duration getDuration() {
        if (!cachedDuration) cachedDuration = new Duration(amount * unitValue() * 1000)
        return cachedDuration
    }

    long unitValue() {
        switch(unit) {
            case 'seconds': return 1
            case 'minutes': return 60
            case 'hours': return 60 * 60
            case 'days': return 24 * 60 * 60
            case 'weeks': return 7 * 24 * 60 * 60
            default: throw new IllegalArgumentException("Unknown time unit $s")
        }
    }

    String toString() {
        return Timespan.asString(getDuration())
    }

    static String asString(Duration duration) {
        long seconds = duration.millis / 1000 as long
        long minutes = seconds / 60 as long
        long hours = minutes / 60 as long
        long days = hours / 24 as long
        long weeks = days / 7 as long
        String text = ""
        if (weeks) text += "${weeks}w"
        if (days % 7) {
            if (text) text += " "
            text += "${days % 7}d"
        }
        if (hours % 24) {
            if (text) text += " "
            text += "${hours % 24}h"
        }
        if (minutes % 60) {
            if (text) text += " "
            text += "${minutes % 60}m"
        }
        if (seconds % 60) {
            if (text) text += " "
            text += "${seconds % 60}s"
        }
        if (!text) {
            text = "At once"        // was Start
        }
        else {
            text = "+$text"
        }
        return text
    }

    boolean isShorterOrEqualTo(Timespan other) {
        return !other.duration.isLongerThan(this.duration)
    }

    int compareTo(Object other) {
        if (!other instanceof Timespan) throw new IllegalArgumentException("Must compare to a Timespan, not a ${other.class.name}")
        Duration thisDuration = this.duration
        Duration otherDuration = ((Timespan)other).duration
        if (thisDuration == otherDuration) return 0
        if (thisDuration.isLongerThan(otherDuration)) return 1
        return -1
    }
}