package com.mindalliance.channels.ifm.responsibility

import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.domain.FactDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 4, 2008
 * Time: 4:03:44 PM
 */
class MustKnow extends Responsibility {  // must cover facts about events, violations, acts , and all other forms of info

    InformationDefinition informationSpec = new FactDefinition() // what must be known (in known situation) if knowable

    boolean isDefined() {
        return super.isDefined() && !informationSpec.matchesAll()     // can be responsible for knowing it all...
    }

}