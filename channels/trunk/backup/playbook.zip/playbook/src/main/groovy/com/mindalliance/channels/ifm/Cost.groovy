package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.impl.BeanImpl

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 26, 2008
 * Time: 4:00:18 PM
 */
class Cost extends BeanImpl implements Comparable {

    float value = 0    // assuming US dollars for now

    static Cost fromValue(float val) {
        return new Cost(value:val)
    }

    String toString() {
        return "\$$value"
    }

    boolean isDefined() {
        return true
    }

    public int compareTo(Object other) {
        if (!other instanceof Cost) throw new IllegalArgumentException("Must compare to a Cost, not a ${other.class.name}")
        Cost prob = (Cost)other
        if (value == prob.value) return 0
        if (value < prob.value) return -1
        return 1
    }

}