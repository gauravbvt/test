package com.mindalliance.channels.ifm.scenario.action.performance

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.resource.Capability

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 26, 2008
 * Time: 2:48:04 PM
 */
class PerformanceLevel extends BeanImpl {

    Comparable value     // value achieved if ...
    List<Capability> capabilities = []   // resource has all these capabilities

    static PerformanceLevel from(Performance performance) {
        return new PerformanceLevel(value: performance.copyDefaultValue());
    }

    String toString() {
        return "$value"
    }

    boolean isDefined() {
        return value != null && capabilities
    }
}