package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ref.Bean
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.scenario.Group
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.analysis.scenario.agent.GroupAgent
import com.mindalliance.channels.analysis.scenario.agent.Agent

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 18, 2008
 * Time: 4:12:58 PM
 */
class AgentSpecification extends Specification {

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['roles'])
    }

    String getLabel() {
        return "agent specification"
    }

    Class<? extends Defineable> getMatchingDomainClass() {
        return Agent.class;
    }

    MatchResult match(Bean bean) {
        if (bean instanceof GroupAgent) {
            Group group = ((GroupAgent)bean).group
            if (group.agentSpec.implies(this)) {
                return new MatchResult(level: Level.HIGHEST, summary: "The group '$group' has a compatible specification of its members")
            }
            else {
                return new MatchResult(level: Level.NONE, summary: "The group '$group' has an incompatible specification of its members")
            }
        }
        else {
            return super.match(bean)
        }
    }


    List<Ref> getRoles() {
        List<Ref> roles = []
        definitions.each {definition ->
            roles.addAll(((AgentDefinition)definition).roles)
        }
        return roles
    }

}