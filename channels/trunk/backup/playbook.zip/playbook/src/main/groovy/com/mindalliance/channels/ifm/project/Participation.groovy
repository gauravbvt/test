package com.mindalliance.channels.ifm.project

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.ContainedElement

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Mar 21, 2008
* Time: 11:42:26 AM
*/
class Participation extends ContainedElement implements InProject {

    Ref user         // set once
    boolean manager
    Ref person


    Set keyProperties() {
        return (super.keyProperties() + ['user', 'project']) as Set
    }

    boolean isDefined() {
        return user as boolean
    }

    String toString() {
        return "${user.name}"
    }

}