package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 4, 2008
 * Time: 10:27:30 AM
 */
class Attribute {

    String name
    Object value

    boolean isReference() {
        return value instanceof Ref
    }

}