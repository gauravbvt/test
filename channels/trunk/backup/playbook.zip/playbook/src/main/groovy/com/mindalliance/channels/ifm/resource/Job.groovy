package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.responsibility.Responsibility
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ifm.resource.organization.InOrganization

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 18, 2008
 * Time: 12:25:52 PM
 */
class Job extends AbstractResource implements InOrganization, Agentable {

    Ref individual
    Ref position
    List<Ref> adminJobs = []


    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['roles', 'name', 'responsibilities'])
    }

    boolean isDefined() {
        return super.isDefined() && individual as boolean && individual.isDefined() && position as boolean && position.isDefined()
    }

    boolean hasJurisdiction() {
        return true
    }

    List<Ref> getRoles() {
        return position as boolean ? position.roles : []
    }

    boolean hasRole(Ref role) {
        return position as boolean ? position.hasRole(role) : false
    }

    Location getJurisdiction() {
        return position as boolean ? position.jurisdiction : null
    }

    String getName() {
        return "${individual as boolean ? (individual.name ?: '?') : '?'} as ${position as boolean ? (position.name ?: '?') : '?'}"
    }

    String toString() {
        return getName()
    }

   List<Responsibility> getResponsibilities() {
        return position as boolean ? position.responsibilities : []
    }
}