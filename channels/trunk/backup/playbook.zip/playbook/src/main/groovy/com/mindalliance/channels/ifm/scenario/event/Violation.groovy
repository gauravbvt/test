package com.mindalliance.channels.ifm.scenario.event

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 2:07:13 PM
 */
class Violation extends Event {

    Ref policy          // policy violated
    List<Ref> violators // resource in violation

    boolean isDefined() {
        return super.defined && policy as boolean && violators
    }

}