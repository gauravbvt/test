package com.mindalliance.channels.analysis.scenario.agent

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.resource.Relationship

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 19, 2008
 * Time: 10:02:38 PM
 */
class AgentRelationship extends BeanImpl {

    Relationship relationship
    Agent agent

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['tag', 'reverseTag', 'withAgent'])
    }

    String getTag() {
        return relationship.tag
    }

    String getReverseTag() {
        return relationship.reverseTag
    }

    boolean isDefined() {
        return relationship.isDefined() && agent.isDefined()
    }

    Agent getWithAgent() {
        return Agent.from(relationship.withResource, agent.action)
    }

}