package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ifm.Named
import com.mindalliance.channels.ifm.Described
import com.mindalliance.channels.ifm.Locatable
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.Documented
import com.mindalliance.channels.ifm.project.InProject
import com.mindalliance.channels.ifm.Relatable
import com.mindalliance.channels.ifm.Activatable

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 24, 2008
 * Time: 9:36:39 PM
 */
interface Resource extends Named, Described, Locatable, Relatable, Documented, InProject, Activatable {

    List<ContactInfo> getContactInfos()
    List<AccessRight> getAccessRights()
    List<Relationship> getRelationships()
    List<Capability> getCapabilities()
    List<InformationDefinition> getKnowledge()
    boolean hasAccessTo(Ref org)
    boolean hasJobWith(Ref org)

}