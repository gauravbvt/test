package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ifm.Probability
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.domain.FactDefinition
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.util.RefUtils
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.domain.FactDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 27, 2008
 * Time: 9:56:23 PM
 */
// A more or less critical and pressing need for specified information
// Can be the need for knowledge, for a command, a sharing commitment, sharing authorization, information source
// assignment or a need for an information need (about knowledge, command etc.)
class InformationNeed extends Information {

    Ref resource  // who needs to know
    InformationDefinition informationSpec = new FactDefinition()  // what kind of information
    Probability criticality = new Probability() // how important it is


    String toString() {
        return "$criticality critical need about ${informationSpec.description}"
    }

    boolean isDefined() {
        return super.defined && !informationSpec.matchesAll()
    }


    String makeLabel(int maxWidth) {
        String label = "Need info\n"
        label += "${RefUtils.summarize(informationSpec.description, maxWidth)}"
        return label
    }

}