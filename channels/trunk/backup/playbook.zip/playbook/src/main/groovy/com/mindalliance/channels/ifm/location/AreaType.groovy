package com.mindalliance.channels.ifm.location

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ref.impl.ComputedRef
import com.mindalliance.channels.ifm.ModelElement
import com.mindalliance.channels.ifm.Conceptual

/**
* Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
* Proprietary and Confidential.
* User: jf
* Date: Apr 17, 2008
* Time: 3:39:39 PM
*/
class AreaType extends ModelElement implements Conceptual {

    public static final String GLOBE = 'Globe'
    public static final String CONTINENT = 'Continent'
    public static final String COUNTRY = 'Country'
    public static final String STATE = 'State'
    public static final String COUNTY = 'County'
    public static final String CITY = 'City'

    String name = ''
    String description = ''
    List<Ref> narrowedTypes = []

    boolean isDefined() {
        return true
    }

    static Ref fromName(String name) {
        switch(name) {
            case GLOBE: return globe();
            case CONTINENT: return continent();
            case COUNTRY: return country();
            case STATE: return state();
            case COUNTY: return county();
            case CITY: return city();
            default: throw new IllegalArgumentException("Unknown area type $name")
        }
    }

    static Ref globe() {
        return ComputedRef.from(AreaType.class, "makeGlobe")
    }

    static Ref continent() {
        return ComputedRef.from(AreaType.class, "makeContinent")
    }

    static Ref country() {
        return ComputedRef.from(AreaType.class, "makeCountry")
    }

    static Ref state() {
        return ComputedRef.from(AreaType.class, "makeState")
    }

    static Ref county() {
        return ComputedRef.from(AreaType.class, "makeCounty")
    }

    static Ref city() {
        return ComputedRef.from(AreaType.class, "makeCity")
    }

    static AreaType makeGlobe() {
        return new AreaType(name: GLOBE)
    }

    static AreaType makeContinent() {
        AreaType continent = new AreaType(name: CONTINENT)
        continent.narrow(AreaType.global())
        return continent
    }

    static AreaType makeCountry() {
        AreaType country = new AreaType(name: COUNTRY)
        country.narrow(AreaType.continent())
        return country
    }

    static AreaType makeState() {
        AreaType state = new AreaType(name: STATE)
        state.narrow(AreaType.country())
        return state
    }

    static AreaType makeCounty() {
        AreaType county = new AreaType(name: COUNTY)
        county.narrow(AreaType.state())
        return county
    }

    static AreaType makeCity() {
        AreaType city = new AreaType(name: CITY)
        city.narrow(AreaType.county())
        return city
    }

    static List<String> allAreaTypeNames() {
        return [country().name, state().name, county().name, city().name]
    }

    static Ref areaTypeNamed(String name) {
        switch(name) {
            case GLOBE: return globe()
            case CONTINENT: return continent()
            case COUNTRY: return country()
            case STATE: return state()
            case COUNTY: return county()
            case CITY: return city()
            default: null
        }
    }

    void narrow (Ref type) {
        this.addNarrowedType(type)
    }

    boolean narrows(Ref type) {
        return this.narrowedTypes.contains(type)
    }

    boolean broadens(Ref type) {
        return type.narrowedTypes.contains(this.reference)
    }

    List<Ref> ancestors() {
        List<Ref> ancestors = []
        ancestors.addAll(narrowedTypes)
        narrowedTypes.each {ancestors.addAll(it.ancestors())}
        return ancestors
    }

    boolean implies(Ref type) {
        return type as boolean && (this == type || ancestors().contains(type))
    }
    
 }