package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 24, 2008
 * Time: 3:52:56 PM
 */
interface Relatable {

    List<Ref> getRelationships()

}