package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ifm.domain.TaskDefinition
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 3, 2008
 * Time: 7:12:21 PM
 */
class Command extends Information {

    Ref fromResource    // who commands -- an agenteable
    Ref toResource    // who is commanded -- an agenteable
    TaskDefinition taskSpec = new TaskDefinition()   //  to do what

    String toString() {
        return "Command to do ${taskSpec.description}"
    }

    boolean isDefined() {
        return super.defined && fromResource as boolean && toResource as boolean && taskSpec.defined
    }


    String makeLabel(int maxWidth) {
        // todo
    }
}