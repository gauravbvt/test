package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 25, 2008
 * Time: 4:19:48 PM
 */
interface Conceptual extends Named, Described {

    boolean implies(Ref other)
    void narrow(Ref other)
    List<Ref> ancestors()
    boolean narrows(Ref other)
    boolean broadens(Ref type)
}