package com.mindalliance.channels.ifm.scenario.action.requirement

import com.mindalliance.channels.ifm.domain.RelationshipDefinition

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 1:28:35 PM
 */
class RelationshipRequirement extends Requirement { // agent must have matching relationship

    RelationshipDefinition relationshipSpec = new RelationshipDefinition()

    boolean isDefined() {
        return !relationshipSpec.matchesAll()
    }

}