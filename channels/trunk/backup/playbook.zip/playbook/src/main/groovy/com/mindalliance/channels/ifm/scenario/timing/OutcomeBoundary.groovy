package com.mindalliance.channels.ifm.scenario.timing

import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.scenario.timing.Boundary

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 7, 2008
 * Time: 5:01:31 PM
 */
class OutcomeBoundary extends Boundary {

    boolean success = true

    @Override
    List<String> transientProperties() {
        return (List<String>) (super.transientProperties() + ['start', 'end', 'action'])
    }

    Ref getAction() {
        return occurrence
    }

    boolean isStart() {
        return false // always at end
    }

    boolean isEnd() {
        return true
    }

    boolean isOutcomeBoundary() {
        return true
    }

    String toString() {
        return "${success ? 'success' : 'failure'}"
    }

    String about() {
        return "${success ? 'success' : 'failure'} of ${occurrence.about()}"
    }
}