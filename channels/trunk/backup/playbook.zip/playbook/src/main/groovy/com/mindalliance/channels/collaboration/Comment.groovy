package com.mindalliance.channels.collaboration

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 29, 2008
 * Time: 11:17:40 AM
 */
class Comment extends BeanImpl {  // on a ModelElement

    Date createdOn = new Date()
    Ref user
    String content = ''

    public boolean isDefined() {
        return user as boolean && content as boolean
    }
}