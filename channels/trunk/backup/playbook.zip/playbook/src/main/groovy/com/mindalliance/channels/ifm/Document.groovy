package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.Described
import com.mindalliance.channels.ifm.Named

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 4, 2008
 * Time: 12:50:23 PM
 */
class Document extends BeanImpl implements Named, Described {

    String name = ''
    String description = ''
    String url = ''

    boolean isDefined() {
        return url && urlWellFormed(url) 
    }

    private boolean urlWellFormed(String url) {
        try {
            new URL(url)
            return true
        }
        catch (MalformedURLException e) {
           return false
        }
    }
}