package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.Document

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 4, 2008
 * Time: 12:55:55 PM
 */
class Documentation extends BeanImpl {

    List<Document> documents = []

    boolean isDefined() {
        return true
    }
}