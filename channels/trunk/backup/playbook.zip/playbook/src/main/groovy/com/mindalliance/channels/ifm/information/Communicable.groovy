package com.mindalliance.channels.ifm.information
/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 4, 2008
 * Time: 10:26:45 AM
 */
interface Communicable { 

    List<Attribute> allAttributes() // what can inherently be known about it
                                    // (communicable properties, possibly renamed, of knowable)
    Attribute attributeNamed(String attributeName)

}