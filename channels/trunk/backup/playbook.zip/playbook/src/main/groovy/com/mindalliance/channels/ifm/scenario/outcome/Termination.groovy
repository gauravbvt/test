package com.mindalliance.channels.ifm.scenario.outcome

import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 1, 2008
 * Time: 7:26:51 PM
 */
class Termination extends Outcome {  // premature termination of event or information act

    Ref occurrence  // event or information act terminated
    boolean success // if information act is terminated, is it ended in success or failure?

    boolean isDefined() {
        return occurrence as boolean
    }
}