package com.mindalliance.channels.ifm.vocabulary

import com.mindalliance.channels.ifm.*
import com.mindalliance.channels.ifm.location.GeoLocation
import com.mindalliance.channels.matching.TagAnalyst
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.support.Level
import org.slf4j.LoggerFactory

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 21, 2008
 * Time: 3:30:47 PM
 */
class Place extends ContainedElement implements Named, Described, Activatable {

    String name = ''
    String description = ''
    boolean activated = true   // activated by default
    TagSet tags = new TagSet()
    Ref enclosingPlace          // if any -- make sure there is no circularity
    GeoLocation geoLocation = new GeoLocation()   // set if the place has a fixed geolocation (may be more or less vague)

    Set keyProperties() {
        return (super.keyProperties() + ['name', 'description', 'tags']) as Set
    }

    boolean isDefined() {
        return super.isDefined() && (tags || enclosingPlace as boolean || geoLocation.isDefined())
    }

    String toString() {
        return name ?: 'Unnamed'
    }

    void setEnclosingPlace(Ref place) {
        if (enclosingPlace != place) {
            if (!isWithin(place) && !place.isWithin(this.reference)) {
                enclosingPlace = place
                changed('enclosingPlace')
            }
            else {
                LoggerFactory.getLogger(this.class).warn("Failed attempt to introduce circularity in containment of $name")
            }
        }
    }

    List<Ref> containment() {
        if (enclosingPlace as boolean) {
            return [enclosingPlace] + enclosingPlace.containment()
        }
        else {
            return []
        }
    }

    GeoLocation findGeoLocation() { // defaults to undefined geolocation
        if (geoLocation.isDefined()) {
            return geoLocation
        }
        else {
            if (enclosingPlace as boolean) {
                GeoLocation geoLoc = enclosingPlace.findGeoLocation()
                if (geoLoc.isDefined()) {
                    return geoLoc
                }
                else {
                    return new GeoLocation() // return undefined geolocation
                }
            }
            else {
                return new GeoLocation()
            }
        }
    }

    boolean isWithin(Ref place) {
        if (!enclosingPlace as boolean) return false
        if (place == enclosingPlace) return true
        return enclosingPlace.isWithin(place)
    }

    Level isNearby(Ref place) { // best guess whether two places are close to one another
        if (this.reference == place) return Level.HIGHEST    // same place -- can't be closer
        if (place.enclosingPlace == enclosingPlace) return Level.HIGH // same direct containment
        if (containment().intersect(place.containment())) return Level.MEDIUM  // share a common containing place
        return findGeoLocation().isNearby(place.findGeoLocation()) // Try geolocations
    }

    Ref broadenedTo(TagSet otherTags) {   // search from this place up for a good match
        Level level = TagAnalyst.matchTagSets(tags, otherTags)
        if (level > Level.MEDIUM) return this.reference
        if (enclosingPlace as boolean) {
            return enclosingPlace.broadenedTo(otherTags)
        }
        else {
            return null
        }
    }

    // QUERIES

    List<Ref> findAllCandidateEnclosingPlaces() {
        if (tags.isDefined()) {
            return project.places.findAll {place ->
                place as boolean && place != this.reference && !this.isWithin(place) // && TagAnalyst.hasRelation(TagAnalyst.MERONYM, place.tags, tags)   -- TODO
            }
        }
        else {
            return []     // return empty list if this place is not classified
        }
    }

    // END QUERIES
}