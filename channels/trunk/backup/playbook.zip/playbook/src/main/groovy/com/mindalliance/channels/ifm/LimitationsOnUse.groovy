package com.mindalliance.channels.ifm

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.domain.TaskDefinition
import com.mindalliance.channels.ifm.domain.AgentSpecification
import com.mindalliance.channels.ifm.Described

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 13, 2008
 * Time: 9:18:56 AM
 */
class LimitationsOnUse extends BeanImpl implements Described {

    String description = ''
    // usage limitations
    TaskDefinition allowedTaskSpec = new TaskDefinition()    // any if undefined
    // dissemination limitations
    AgentSpecification allowedRecipientSpec = new AgentSpecification()   // any if not defined

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['allPurposes'])
    }


    String toString() {
        return description ?: 'NO DESCRIPTION'
    }

    List<String> getAllPurposes() { // get all allowed *and* forbidden purposes
        List<String> purposes = []
        purposes.addAll(allowedTaskSpec.purposes)
        return purposes
    }

    boolean isDefined() {
        return true
    }

}