package com.mindalliance.channels.ifm.information

import com.mindalliance.channels.ifm.domain.AgentSpecification
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ifm.information.Fact
import com.mindalliance.channels.ref.Ref

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 3, 2008
 * Time: 7:46:25 PM
 */
class ConfirmationNeed extends Information {   // Need for confirmation of some knowledge

    Ref resource                      // who needs confirmation
    Information information = new Fact()  // what needs confirmation
    AgentSpecification sourceSpec     // acceptable sources of confirmation

    boolean isDefined() {
        return super.defined && resource as boolean && information.defined
    }

    String toString() {
        return "Confirmation needed for $information from ${sourceSpec.description}"
    }

    public String makeLabel(int maxWidth) {
        // todo
    }
}