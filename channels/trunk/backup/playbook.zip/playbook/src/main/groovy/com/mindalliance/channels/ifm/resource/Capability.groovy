package com.mindalliance.channels.ifm.resource

import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.support.Level
import com.mindalliance.channels.ifm.Overridable
import com.mindalliance.channels.matching.TagAnalyst

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 26, 2008
 * Time: 2:41:43 PM
 */
class Capability extends BeanImpl implements Overridable {

    String tag = ''             // kind
    Level level = Level.HIGH

    boolean isDefined() {
        return tag as boolean
    }

    String toString() {
        return "$tag ($level)"
    }

    boolean overrides(Overridable other) {     // requires high level match on tag
        Capability capability = (Capability)other
        return TagAnalyst.match(tag, capability.tag) >= Level.HIGH
    }
}