package com.mindalliance.channels.ifm.scenario

import com.mindalliance.channels.ifm.resource.Agentable
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ifm.domain.AgentSpecification
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ifm.responsibility.Responsibility
import com.mindalliance.channels.ifm.ContainedElement
import com.mindalliance.channels.ifm.resource.AccessRight

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 14, 2008
 * Time: 9:46:51 PM
 */
class Group extends ContainedElement implements Agentable, InScenario {   // TODO should this be project level?

    String name = ''
    String description = ''
    AgentSpecification agentSpec = new AgentSpecification()  // all matching agents at time of resolution

    String toString() {
        return name
    }

    boolean hasJurisdiction() {
        return false;
    }

    boolean hasLocation() {
        return false;
    }

    Location getLocation() {
        return new Location();   // undefined
    }

    // queries

     // end queries

    List<Ref> getRoles() {
        return agentSpec.roles;
    }

    List<Responsibility> getResponsibilities() {
        return roles.responsibilities.flatten();
    }

    boolean hasRole(Ref role) {
        return roles.any {r -> r.implies(role)};
    }

    List<AccessRight> getAccessRights() {
        return []            // todo -- the accessrights of all members
    }

    public List<Ref> getRelationships() {
        return [] // -- no relationships to a group per se
    }
}