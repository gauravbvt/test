package com.mindalliance.channels.ifm.domain

import com.mindalliance.channels.ifm.Defineable
import com.mindalliance.channels.ifm.information.ElementOfInformation
import com.mindalliance.channels.ifm.information.Information
import com.mindalliance.channels.ifm.information.Fact
import com.mindalliance.channels.support.Level

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Nov 2, 2008
 * Time: 8:53:26 AM
 */
class FactDefinition extends InformationDefinition { // Knowledge such that...

    Categorization categorization = new Categorization()   // it is categorized as... and not as...
    List<ElementOfInformation> eois = [] // and is described by EOIs implying these

    Class<? extends Defineable> getMatchingDomainClass() {
        return Fact.class
    }

    boolean matchesAll() {
        return super.matchesAll() && !categorization.defined && eois.empty
    }

    protected MatchResult doSpecificMatch(Information information, Level level, StringBuilder summary, Map<String, Object> matches) {
        Fact knowledge = (Fact) information
        Level minLevel = level
        // eois -- for each of the definition's eoi find best match with an info's eoi, of them keeps the weakest
        if (!eois) {
            matches['elements of information'] = Level.HIGHEST
            summary.append("Any element of information is ok")
        }
        else {
            Level min = Level.HIGHEST
            eois.each {seoi ->
                Level max = Level.NONE
                knowledge.eois.each {keoi ->
                    Level matchLevel = keoi.matchSpecified(seoi)
                    if (matchLevel > max) max = matchLevel
                }
                if (max < min) min = max
            }
            matches['elements of information'] = min
            summary.append("${min.confidence()} elements of information are ok")
            if (min < minLevel) minLevel = min
        }
        return new MatchResult(level: minLevel, summary: summary.toString(), matches: matches)
    }

    boolean doesImply(MatchingDomain matchingDomain) {
        if (super.doesImply(matchingDomain)) {
            FactDefinition other = (FactDefinition) matchingDomain
            if (!categorization.implies(other.categorization)) return false
            if (other.eois && !other.eois.every {oeoi ->
                    eois.any {eoi -> eoi.match(oeoi) > Level.MEDIUM}}) return false
            return true
        }
        else {
            return false
        }
    }


}