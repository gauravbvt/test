package com.mindalliance.channels.ifm.scenario

import com.mindalliance.channels.ifm.Overridable
import com.mindalliance.channels.ifm.domain.InformationDefinition
import com.mindalliance.channels.ifm.location.Location
import com.mindalliance.channels.ref.Ref
import com.mindalliance.channels.ref.impl.BeanImpl
import com.mindalliance.channels.ifm.resource.ContactInfo
import com.mindalliance.channels.ifm.resource.Capability
import com.mindalliance.channels.ifm.resource.AccessRight
import com.mindalliance.channels.ifm.Described

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Sep 25, 2008
 * Time: 6:26:46 PM
 */
class ProfileExtension extends BeanImpl implements Described {    // scenario-specific extension to a resource profile

    String description = ''
    Ref agentable                                                // an agentable resource (excludes Groups)
    boolean activationToggled = true                            // turn on or off profile extension
    List<ContactInfo> extendedContactInfos = []                 // additional or overrides
    Location extendedLocation = new Location()                  // overrides if defined
    List<Capability> extendedCapabilities = []                  // additional or overrides (of tag match level is >= HIGH)
    List<InformationDefinition> extendedKnowledge = []          // additional only
    List<AccessRight> extendedAccessRights = []                 // additional or overrides

    @Override
    List<String> transientProperties() {
        return (List<String>)(super.transientProperties() + ['name', 'description', 'contactInfos', 'location', 'accessRights',
                'capabilities', 'expertise', 'roles', 'responsibilities'])
    }

    boolean isDefined() {
        return super.isDefined() && agentable as boolean
    }

    boolean isExtended() {
        return extendedContactInfos || extendedLocation.isDefined() || extendedCapabilities || extendedKnowledge || extendedAccessRights || activationToggled
    }

    private List<Overridable> combine(List<Overridable> initials, List<Overridable> overrides) {
        List<Overridable> notOverriden = (List<Overridable>)initials.findAll {initial ->
            overrides.every {override -> !override.overrides(initial) }
        }
        return (List<Overridable>)(overrides + notOverriden)
    }

    List<ContactInfo> getContactInfos() {
        return (List<ContactInfo>)combine((List<Overridable>)agentable.contactInfos, (List<Overridable>)extendedContactInfos)
    }

    List<AccessRight> getAccessRights() {
        return (List<AccessRight>)combine((List<Overridable>)agentable.accessRights, (List<Overridable>)extendedAccessRights)
    }



    List<Capability> getCapabilities() {
        return (List<Capability>)combine((List<Overridable>)agentable.capabilities, (List<Overridable>)extendedCapabilities)
    }

    List<InformationDefinition> getExpertise() {
        return agentable.expertise + extendedExpertise
    }

    Location getLocation() {
        return extendedLocation.isDefined() ? extendedLocation : agentable.location
    }

    boolean isActivated() {
        return activationToggled ? !agent.activated : agent.activated
    }

    // Queries


    // End queries

}