package com.mindalliance.channels.pages.forms.tabs.project;

import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.RefListPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 8, 2008
 * Time: 9:36:45 PM
 */
public class ProjectContentTab extends AbstractFormTab {

    public ProjectContentTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        RefListPanel participationsPanel = new RefListPanel("participations", this, new RefPropertyModel(getElement(), "participations"));
        addReplaceable(participationsPanel);
        RefListPanel scriptsPanel = new RefListPanel("scenarios", this, new RefPropertyModel(getElement(), "scenarios"));
        addReplaceable(scriptsPanel);
        RefListPanel personsPanel = new RefListPanel("persons", this, new RefPropertyModel(getElement(), "persons"));
        addReplaceable(personsPanel);
        RefListPanel organizationsPanel = new RefListPanel("organizations", this, new RefPropertyModel(getElement(), "organizations"));
        addReplaceable(organizationsPanel);
        RefListPanel placesPanel = new RefListPanel("places", this, new RefPropertyModel(getElement(), "places"));
        addReplaceable(placesPanel);
        RefListPanel mediumsPanel = new RefListPanel("mediums", this, new RefPropertyModel(getElement(), "mediums"));
        addReplaceable(mediumsPanel);
        RefListPanel situationsPanel = new RefListPanel("situations", this, new RefPropertyModel(getElement(), "situations"));
        addReplaceable(situationsPanel);
    }
}
