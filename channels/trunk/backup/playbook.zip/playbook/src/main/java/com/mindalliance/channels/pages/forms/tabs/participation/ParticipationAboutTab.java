package com.mindalliance.channels.pages.forms.tabs.participation;

import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.ReferencePanel;
import com.mindalliance.channels.ifm.project.Participation;
import com.mindalliance.channels.ifm.Channels;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.support.models.RefQueryModel;
import com.mindalliance.channels.query.Query;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.ajax.AjaxRequestTarget;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 7, 2008
 * Time: 10:04:16 AM
 */
public class ParticipationAboutTab extends AbstractFormTab {

    private AjaxCheckBox isManagerCheckBox;

    public ParticipationAboutTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        Participation participation = (Participation)getElement().deref();
        ReferencePanel usersPanel = new ReferencePanel("user", this, "user", new RefQueryModel(getProject(), new Query("findNonParticipatingUsers")), null, ReferencePanel.REQUIRED, ReferencePanel.SET_ONCE);
        addReplaceable(usersPanel);
        ReferencePanel projectPanel = new ReferencePanel("project", this, "project", new RefPropertyModel(Channels.instance(), "projects"), "participates in project", ReferencePanel.REQUIRED, ReferencePanel.SET_ONCE);
        addReplaceable(projectPanel);
        ReferencePanel personPanel = new ReferencePanel("person", this, "person", new RefPropertyModel(getProject(), "persons"), "as person");
        addReplaceable(personPanel);
        isManagerCheckBox = new AjaxCheckBox("isManager", new RefPropertyModel<Boolean>(participation, "manager")) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean value = isManagerCheckBox.getModelObject();
                setProperty("manager", value);
            }
        };
        addReplaceable(isManagerCheckBox);
    }
}
