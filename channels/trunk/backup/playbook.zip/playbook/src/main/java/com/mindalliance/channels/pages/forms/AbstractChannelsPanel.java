package com.mindalliance.channels.pages.forms;

import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.ifm.project.Project;
import com.mindalliance.channels.ifm.project.InProject;
import com.mindalliance.channels.ifm.resource.organization.Organization;
import com.mindalliance.channels.ifm.resource.organization.InOrganization;
import com.mindalliance.channels.ifm.scenario.Scenario;
import com.mindalliance.channels.ifm.scenario.InScenario;
import com.mindalliance.channels.ifm.ContainedElement;
import com.mindalliance.channels.util.RefUtils;
import org.apache.log4j.Logger;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.Component;
import org.apache.wicket.MarkupContainer;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.markup.html.form.CheckBox;
import org.apache.wicket.markup.html.form.FormComponent;
import org.apache.wicket.markup.html.panel.FeedbackPanel;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;

import java.util.*;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 9, 2008
 * Time: 6:03:21 PM
 */
public abstract class AbstractChannelsPanel extends Panel implements ElementPanel {   // abstract superclass for AbstractFormTab and AbstractComponentPanel

    protected Map<FormComponent, String> inputFields = new HashMap<FormComponent, String>();
    protected Map<Component, List<Component>> dependencies = new HashMap<Component, List<Component>>();

    public AbstractChannelsPanel(String id) {
        super(id);
    }

    public AbstractChannelsPanel(String id, IModel model) {
        super(id, model);
    }

    abstract public FeedbackPanel getFeedback();

    // Get property path from element
    abstract public String getFullPropertyPath();

    public Project getProject() {
        InProject ip = (InProject)getElement().deref();
        return (Project)ip.getProject().deref();
    }

    public Scenario getScenario() {
        return (Scenario)((InScenario)getElement().deref()).getScenario().deref();
    }

    public Ref getScenarioOrElseProject() {
        ContainedElement containedElement = (ContainedElement)getElement().deref();
        if (containedElement.isScenarioElement()) {
            return containedElement.getScenario();
        }
        else {
            return containedElement.getProject();
        }
    }

    public Organization getOrganization() {
        return (Organization)((InOrganization)getElement().deref()).getOrganization().deref();
    }

    protected void addReplaceable(Component component) {
        addReplaceableTo(component, this);
    }

    protected void addReplaceableTo(Component component, MarkupContainer container) {
        component.setOutputMarkupId(true);
        if (isReadOnly()) {
            disable(component);
        }
        container.addOrReplace(component);
    }

    protected void init() {
        this.setOutputMarkupId(true);
        for (final Map.Entry<FormComponent,String> entry : inputFields.entrySet()) {
            final FormComponent inputField = entry.getKey();
            final String propPath = entry.getValue();
            inputField.add(new AjaxFormComponentUpdatingBehavior("onchange") {@Override
                protected void onUpdate(AjaxRequestTarget target) {
                    if (!propPath.isEmpty()) elementChanged(propPath, target);
                    List<Component> dependents = dependencies.get(inputField);
                    if (dependents != null) {
                        for (Component dependent : dependents) {
                            target.addComponent(dependent);
                        }
                    }
                    target.addComponent(getFeedback());
                }

                protected void onError(AjaxRequestTarget target, RuntimeException e) {
                    Logger.getLogger(this.getClass()).error("Error updating " + inputField + ": " + e);
                    inputField.clearInput();
                    target.addComponent(inputField);
                    target.addComponent(getFeedback());
                }
            });
        }
    }

    // no propagation of change
    protected void addInputField(FormComponent inputField,  Component dependentField) {
        addInputField(inputField, "", dependentField);
    }

    protected void addInputField(FormComponent inputField, String propPath, Component dependentField) {
        addInputField(inputField, propPath);
        List<Component> dependents = getDependentsOf(inputField);
        dependents.add(dependentField);
    }

    protected void addInputField(FormComponent inputField) {
        addInputField(inputField, "");
    }

    protected void addInputField(FormComponent inputField, String propPath) {
        doAddInputField(inputField, propPath);
        addReplaceable(inputField);
    }

    // No change propagation
    protected void addInputFieldTo(FormComponent inputField, WebMarkupContainer container) {
        addInputFieldTo(inputField, "", container);
    }

    protected void addInputFieldTo(FormComponent inputField, String propPath, WebMarkupContainer container) {
        doAddInputField(inputField, propPath);
        addReplaceableTo(inputField, container);
    }

    private List<Component> getDependentsOf(Component component) {
        List<Component> dependents = dependencies.get(component);
        if (dependents == null) {
            dependents = new ArrayList<Component>();
            dependencies.put(component, dependents);
        }
        return dependents;
    }

    private void doAddInputField(FormComponent inputField, String propPath) {
        inputFields.put(inputField, propPath);
        if (inputField.isRequired() && inputField.getModelObject() == null) {
            inputField.error(RefUtils.capitalize(inputField.getId()) + " is required");
        }
     }


    protected void setVisibility(Component component, boolean visible) {
        if (visible) {
            display(component);
        }
        else {
            hide(component);
        }
    }

    protected void setVisibility(Component component, boolean visible, AjaxRequestTarget target) {
        setVisibility(component, visible);
        target.addComponent(component);
    }

    protected void hide(Component component) {
        component.add(new AttributeModifier("style", true, new Model<String>("display:none")));
    }

    protected void display(Component component) {
        component.add(new AttributeModifier("style", true, new Model<String>("display:block")));
    }

    protected void display(Component component, String style) {
        component.add(new AttributeModifier("style", true, new Model<String>("display:" + style)));
    }

    protected void toggle(CheckBox setCheckBox, CheckBox toggledCheckBox, AjaxRequestTarget target) {
        toggledCheckBox.setModelObject(!setCheckBox.getModelObject());
        target.addComponent(toggledCheckBox);
    }

    protected void enable(Component component, boolean enabled, AjaxRequestTarget target) {
        component.setEnabled(enabled);
        target.addComponent(component);
    }

    protected void disable(Component component) {
        component.setEnabled(false);
    }

    protected boolean isFresh(Ref ref) {
        return ref != null && ref.isFresh();
    }

}
