package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.ifm.Timespan;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.log4j.Logger;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.model.Model;
import org.apache.wicket.validation.validator.NumberValidator;
import org.apache.wicket.Component;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 29, 2008
 * Time: 4:07:06 PM
 */
public class TimespanPanel extends AbstractComponentPanel {

    private Timespan timespan;

    public TimespanPanel(
            String id, AbstractChannelsPanel parentPanel, String propPath ) {
        super( id, parentPanel, propPath );
    }

    @Override
    protected void load() {
        super.load();
        timespan = (Timespan) getComponent();
        // amount
        final TextField<Integer> amountField = new TextField<Integer>(
                "amount", new RefPropertyModel<Integer>(getComponent(), "amount" ) );

        amountField.setType( Integer.class );
        amountField.add( NumberValidator.minimum( 0L ) );
        addInputField( amountField, "amount" );  // by giving path, will raise change "event"
        // units
        final Component unitChoice = new DropDownChoice<String>(
                "units", new RefPropertyModel<String>(getComponent(), "unit"), Timespan.getUnits() );
        unitChoice.add(
                new AjaxFormComponentUpdatingBehavior( "onchange" ) {
                    @Override
                    protected void onUpdate( AjaxRequestTarget target ) {
                        String newUnit =
                                unitChoice.getDefaultModelObjectAsString();
                        timespan.setUnit( newUnit );
                        elementChanged( propPath, target );
                    }
                } );
        addReplaceable( unitChoice );
    }
}
