package com.mindalliance.channels.pages.forms;

import com.mindalliance.channels.ref.Ref;
import org.apache.wicket.ajax.AjaxRequestTarget;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 1, 2008
 * Time: 9:43:43 PM
 */
public interface ElementPanel {

    Ref getElement();
    Object getObject();
    void elementChanged(String fullPath, AjaxRequestTarget target);
    AbstractElementForm getTopElementPanel();
    void edit(Ref ref, AjaxRequestTarget target);
    boolean isReadOnly();
}
