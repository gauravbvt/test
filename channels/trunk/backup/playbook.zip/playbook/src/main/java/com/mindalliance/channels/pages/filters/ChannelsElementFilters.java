package com.mindalliance.channels.pages.filters;

import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.ref.Referenceable;
import com.mindalliance.channels.support.models.Container;
import com.mindalliance.channels.ifm.scenario.Scenario;
import com.mindalliance.channels.ifm.scenario.InScenario;

import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * ...
 */
public class ChannelsElementFilters extends AbstractFilters {

    public void addFilters( Container container, List<Filter> results ) {
        Set<Ref> channelsRefs = new TreeSet<Ref>( new Comparator<Ref>(){
            public int compare( Ref o1, Ref o2 ) {
                Scenario p1 = (Scenario) o1.deref();
                Scenario p2 = (Scenario) o2.deref();
                return p1.getName().compareTo( p2.getName() );
            }
        } );
        for ( Ref ref: container ) {
            Referenceable object = ref.deref();
            if ( object instanceof InScenario){
                InScenario pe = (InScenario) object;
                channelsRefs.add( pe.getScenario() );
            }
        }

        if ( channelsRefs.size() > 1 )
            for ( Ref ref: channelsRefs ) {
                results.add( new ChannelsFilter( ref  ) );
            }
    }
}
