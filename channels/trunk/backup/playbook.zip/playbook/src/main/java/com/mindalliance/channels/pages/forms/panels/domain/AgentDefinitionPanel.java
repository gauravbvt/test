package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.ifm.domain.AgentDefinition;
import com.mindalliance.channels.ifm.domain.LocationDefinition;
import com.mindalliance.channels.ifm.domain.OrganizationSpecification;
import com.mindalliance.channels.ifm.domain.RelationshipDefinition;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.ReferencesPanel;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.Model;

import java.util.ArrayList;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 19, 2008
 * Time: 2:38:10 PM
 */
public class AgentDefinitionPanel  extends AbstractDefinitionPanel {

    protected AgentDefinition agentDefinition;
    protected AjaxCheckBox anyRoleCheckBox;
    protected WebMarkupContainer rolesDiv;
    protected ReferencesPanel rolesPanel;
    protected AjaxCheckBox anyOrganizationCheckBox;
    protected WebMarkupContainer organizationSpecificationDiv;
    protected OrganizationSpecificationPanel organizationSpecificationPanel;
    protected AjaxCheckBox anyLocationCheckBox;
    protected WebMarkupContainer LocationDefinitionDiv;
    protected LocationDefinitionPanel LocationDefinitionPanel;
    protected AjaxCheckBox anyJurisdictionCheckBox;
    protected WebMarkupContainer jurisdictionDefinitionDiv;
    protected LocationDefinitionPanel jurisdictionDefinitionPanel;
    protected AjaxCheckBox anyRelationshipCheckBox;
    protected WebMarkupContainer relationshipDefinitionDiv;
    protected RelationshipDefinitionPanel relationshipDefinitionPanel;

    public AgentDefinitionPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        agentDefinition = (AgentDefinition)getComponent();
        anyRoleCheckBox = new AjaxCheckBox("anyRole", new Model<Boolean>(agentDefinition.getRoles().isEmpty())){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyRole = anyRoleCheckBox.getModelObject();
                if (anyRole) {
                    setProperty("roles", new ArrayList<Ref>(), target);
                }
                setVisibility(rolesDiv, !anyRole, target);
            }
        };
        addReplaceable(anyRoleCheckBox);
        rolesDiv = new WebMarkupContainer("rolesDiv");
        setVisibility(rolesDiv, !agentDefinition.getRoles().isEmpty());
        addReplaceable(rolesDiv);
        rolesPanel = new ReferencesPanel("roles", this, "roles", new RefPropertyModel(getProject(), "roles"));
        addReplaceableTo(rolesPanel, rolesDiv);

        anyOrganizationCheckBox = new AjaxCheckBox("anyOrganization", new Model<Boolean>(agentDefinition.getOrganizationSpec().matchesAll())){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyOrganization = anyOrganizationCheckBox.getModelObject();
                if (anyOrganization) {
                    setProperty("organizationSpec", new OrganizationSpecification(), target);
                    organizationSpecificationPanel = new OrganizationSpecificationPanel("organizationSpecification", AgentDefinitionPanel.this, "organizationSpec");
                    addReplaceableTo(organizationSpecificationPanel, organizationSpecificationDiv);
                }
                setVisibility(organizationSpecificationDiv, !anyOrganization, target);
            }
        };
        addReplaceable(anyOrganizationCheckBox);
        organizationSpecificationDiv = new WebMarkupContainer("organizationSpecificationDiv");
        setVisibility(organizationSpecificationDiv, !agentDefinition.getOrganizationSpec().matchesAll());
        addReplaceable(organizationSpecificationDiv);
        organizationSpecificationPanel = new OrganizationSpecificationPanel("organizationSpecification", this, "organizationSpec");
        addReplaceableTo(organizationSpecificationPanel, organizationSpecificationDiv);

        anyJurisdictionCheckBox = new AjaxCheckBox("anyJurisdiction", new Model<Boolean>(agentDefinition.getJurisdictionSpec().matchesAll())){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyLocation = anyJurisdictionCheckBox.getModelObject();
                if (anyLocation) {
                    setProperty("jurisdictionDefinition", new LocationDefinition(), target);
                    jurisdictionDefinitionPanel = new LocationDefinitionPanel("jurisdictionDefinition", AgentDefinitionPanel.this, "jurisdictionDefinition");
                    addReplaceableTo(jurisdictionDefinitionPanel, jurisdictionDefinitionDiv);
                }
                setVisibility(jurisdictionDefinitionDiv, !anyLocation, target);
            }
        };
        addReplaceable(anyJurisdictionCheckBox);
        jurisdictionDefinitionDiv = new WebMarkupContainer("jurisdictionDefinitionDiv");
        setVisibility(jurisdictionDefinitionDiv, !agentDefinition.getJurisdictionSpec().matchesAll());
        addReplaceable(jurisdictionDefinitionDiv);
        jurisdictionDefinitionPanel = new LocationDefinitionPanel("jurisdictionDefinition", this, "jurisdictionDefinition");
        addReplaceableTo(jurisdictionDefinitionPanel, jurisdictionDefinitionDiv);

        anyRelationshipCheckBox = new AjaxCheckBox("anyRelationship", new Model<Boolean>(agentDefinition.getRelationshipSpec().matchesAll())){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyRelationship = anyRelationshipCheckBox.getModelObject();
                if (anyRelationship) {
                    setProperty("relationshipDefinition", new RelationshipDefinition(), target);
                    relationshipDefinitionPanel = new RelationshipDefinitionPanel("relationshipDefinition", AgentDefinitionPanel.this, "relationshipSpec");
                    addReplaceableTo(relationshipDefinitionPanel, relationshipDefinitionDiv);
                }
                setVisibility(relationshipDefinitionDiv, !anyRelationship, target);
            }
        };
        addReplaceable(anyRelationshipCheckBox);
        relationshipDefinitionDiv = new WebMarkupContainer("relationshipDefinitionDiv");
        setVisibility(relationshipDefinitionDiv, !agentDefinition.getRelationshipSpec().matchesAll());
        addReplaceable(relationshipDefinitionDiv);
        relationshipDefinitionPanel = new RelationshipDefinitionPanel("relationshipDefinition", this, "relationshipDefinition");
        addReplaceableTo(relationshipDefinitionPanel, relationshipDefinitionDiv);
     }

}
