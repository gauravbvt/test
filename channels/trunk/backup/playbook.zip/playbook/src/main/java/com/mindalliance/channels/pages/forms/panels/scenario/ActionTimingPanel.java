package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.ifm.scenario.Group;
import com.mindalliance.channels.ifm.scenario.action.Action;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 9:28:44 PM
 */
public class ActionTimingPanel extends AbstractTimingPanel {


    public ActionTimingPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected AbstractComponentPanel makeDelayPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        Action action = (Action)((AbstractComponentPanel)parentPanel).getElement().deref(); // this panel always within a panel on an information act
        return new PerformancePanel(id, parentPanel, propPath, action.getActor() instanceof Group);
    }

}
