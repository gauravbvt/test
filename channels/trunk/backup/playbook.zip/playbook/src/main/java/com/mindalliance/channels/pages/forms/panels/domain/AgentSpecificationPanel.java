package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.domain.AbstractDefinitionPanel;
import com.mindalliance.channels.pages.forms.panels.domain.AbstractSpecificationPanel;
import com.mindalliance.channels.pages.forms.panels.domain.AgentDefinitionPanel;
import com.mindalliance.channels.support.models.RefQueryModel;
import com.mindalliance.channels.query.Query;
import com.mindalliance.channels.ifm.domain.Definition;
import com.mindalliance.channels.ifm.domain.AgentDefinition;
import org.apache.wicket.model.IModel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 19, 2008
 * Time: 2:41:52 PM
 */
public class AgentSpecificationPanel extends AbstractSpecificationPanel {

    public AgentSpecificationPanel(String id, AbstractChannelsPanel parentPanel, String propPath ) {
        super( id, parentPanel, propPath );
    }

    @Override
    protected String getMatchingDomainName() {
        return "agent";
    }

    @Override
    protected IModel<?> getEnumerationChoicesModel() {
        return new RefQueryModel( getProject(), "findAllAgentables");
    }

    @Override
    protected AbstractDefinitionPanel makeDefinitionEditor(String id, String propPath ) {
        return new AgentDefinitionPanel( id, this, propPath );
    }

    @Override
    protected Definition makeNewDefinition() {
        return new AgentDefinition();
    }

    @Override
    protected boolean isEnumerable() {
        return true;
    }
}
