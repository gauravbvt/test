package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.ifm.information.InformationNeed;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.domain.InformationDefinitionPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.pages.forms.panels.TimespanPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.markup.html.form.CheckBox;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 28, 2008
 * Time: 8:34:37 AM
 */
public class InformationNeedPanel extends AbstractComponentPanel {

    protected InformationNeed informationNeed;
    protected InformationDefinitionPanel informationSpecPanel;
    protected TimespanPanel deadlinePanel;
    protected CheckBox criticalField;

    public InformationNeedPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        informationNeed = (InformationNeed)getComponent();
        informationSpecPanel = new InformationDefinitionPanel("informationSpec", this, "informationSpec");
        this.addReplaceable(informationSpecPanel);
        deadlinePanel = new TimespanPanel("deadline", this, "deadline");
        addReplaceable(deadlinePanel);
        criticalField = new CheckBox("critical", new RefPropertyModel(getElement(), getPropertyPath("critical")));
        addInputField(criticalField);
    }

}
