package com.mindalliance.channels.pages.forms.tabs.scenario;

import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.RefListPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 10, 2008
 * Time: 10:36:38 AM
 */
public class ScenarioContentTab extends AbstractFormTab {

    public ScenarioContentTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        RefListPanel scriptGroupsPanel = new RefListPanel("scriptGroups", this, new RefPropertyModel(getElement(), "groups"));
        addReplaceable(scriptGroupsPanel);
        RefListPanel eventsPanel = new RefListPanel("events", this, new RefPropertyModel(getElement(), "events"));
        addReplaceable(eventsPanel);
        RefListPanel actionsPanel = new RefListPanel("actions", this, new RefPropertyModel(getElement(), "actions"));
        addReplaceable(actionsPanel);
    }
}
