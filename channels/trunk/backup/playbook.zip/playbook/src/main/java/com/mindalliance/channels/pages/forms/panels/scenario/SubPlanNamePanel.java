package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.pages.forms.panels.StringWithChoicesPanel;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.ifm.scenario.Occurrence;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.support.models.RefQueryModel;
import org.apache.wicket.markup.html.basic.Label;

import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 24, 2008
 * Time: 8:37:35 PM
 */
public class SubPlanNamePanel extends AbstractComponentPanel {


    public SubPlanNamePanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        Occurrence occ = (Occurrence)getElement().deref();
        Label planNameLabel = new Label("planName", new RefPropertyModel(occ, "antecedentPlanName"));
        addReplaceable(planNameLabel);
        StringWithChoicesPanel subPlanNameField = new StringWithChoicesPanel("subPlanName", this, "subPlanName",
                                                                new RefQueryModel(getElement(), "findAllAlternateSubPlans"));
        addReplaceable(subPlanNameField);
    }
}
