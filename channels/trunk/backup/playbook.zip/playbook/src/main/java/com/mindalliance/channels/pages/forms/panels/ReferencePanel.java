package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.filters.DynamicFilterTree;
import com.mindalliance.channels.pages.filters.Filter;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.ajax.markup.html.AjaxLink;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 20, 2008
 * Time: 11:04:08 AM
 */
public class ReferencePanel extends AbstractComponentPanel  {

    public static final boolean SET_ONCE = true;
    public static final boolean REQUIRED = true;

    private boolean required = false;
    private boolean setOnce = false;
    private IModel choices;
    private String legendLabel;
    private DynamicFilterTree referencesTree;
    private TextField<String> hiddenRefField;
    private Button editButton;
    private WebMarkupContainer resetableDiv;
    private WebMarkupContainer setOnceDiv;

    public ReferencePanel(String id, AbstractChannelsPanel parentPanel, String propPath, IModel choices, String legendLabel, boolean required, boolean setOnce) {
        super(id, parentPanel, propPath);
        this.choices = choices;
        this.required = required;
        this.setOnce = setOnce;
        this.legendLabel = legendLabel;
        doLoad();
    }
    
    public ReferencePanel(String id, AbstractChannelsPanel parentPanel, String propPath, IModel choices, String legendLabel, boolean required) {
        this(id, parentPanel, propPath, choices, legendLabel, required, false);
    }

    public ReferencePanel(String id, AbstractChannelsPanel parentPanel, String propPath, IModel choices, String legendLabel) {
        this(id, parentPanel, propPath, choices, legendLabel, false, false);
    }

    public ReferencePanel(String id, AbstractChannelsPanel parentPanel, String propPath, IModel choices) {
        this(id, parentPanel, propPath, choices, null, false, false);
    }


    private void doLoad() {
        resetableDiv = new WebMarkupContainer("resetable");
        addReplaceable(resetableDiv);
        referencesTree = new DynamicFilterTree("choices", new RefPropertyModel(getElement(), propPath),
                choices, SINGLE_SELECTION) {
            public void onFilterSelect(AjaxRequestTarget target, Filter filter) {
                Ref selection = referencesTree.getNewSelection();
                setProperty(selection, target);
                updateForSelection(target);
            }
        };
        addReplaceableTo(referencesTree, resetableDiv);
        hiddenRefField = new TextField<String>("hiddenRef", new Model<String>());
        if (required) hiddenRefField.isRequired();
        addReplaceableTo(hiddenRefField, resetableDiv);
        setVisibility(hiddenRefField, false);
        setOnceDiv = new WebMarkupContainer("setOnce");
        addReplaceable(setOnceDiv);
        AjaxLink editLink = new AjaxLink("editLink") {
            public void onClick(AjaxRequestTarget target) {
                edit(getElement(), target);
            }
        };
        addReplaceableTo(editLink, setOnceDiv);
        Label editLabel = new Label("element", new Model<String>(refToString()));
        editLink.add(editLabel);
        Label legendLabel = new Label("legend", new Model<String>(legendString()));
        addReplaceable(legendLabel);
        editButton = new Button("edit");
        editButton.add(
                new AjaxEventBehavior("onclick") {
                    @Override
                    protected void onEvent(AjaxRequestTarget target) {
                        Ref selection = (Ref)getProperty();
                        if (selection != null) {
                            edit(selection, target);
                        }
                    }
                });
        updateForSelection();
        addReplaceable(editButton);
        setVisibilityOnSetOnce();
    }

    private void setVisibilityOnSetOnce() {
        setVisibility(setOnceDiv, setOnceAndSet());
        setVisibility(resetableDiv, !setOnceAndSet());
    }

    private void updateForSelection(AjaxRequestTarget target) {
        updateForSelection();
        target.addComponent(editButton);
        target.addComponent(hiddenRefField);
        target.addComponent(getFeedback());
    }

    private void updateForSelection() {
        Ref selection = (Ref)getProperty();
        if (selection == null) {
            hiddenRefField.setModelObject(null);
            if (required) {
                hiddenRefField.error(legendString() + " must be set");
            }
        }
        else {
            hiddenRefField.setModelObject(selection.getId());
        }
        setVisibility(editButton, resetableDiv.isVisible() && getProperty() != null);
    }

    private boolean setOnceAndSet() {
        return setOnce && getProperty() != null;
    }

    private String legendString() {
        if (legendLabel != null) {
            return legendLabel;
        }
        else {
            return RefUtils.capitalize(RefUtils.deCamelCase(propPath));
        }
    }

    private String refToString() {
        Ref ref = (Ref)getProperty();
        if (ref != null) {
            return ref.deref().toString();
        }
        else {
            return "?";
        }
    }

}
