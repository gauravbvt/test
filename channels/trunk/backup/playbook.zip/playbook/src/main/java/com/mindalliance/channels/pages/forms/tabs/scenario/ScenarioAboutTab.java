package com.mindalliance.channels.pages.forms.tabs.scenario;

import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.StringListPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.util.validators.UniqueValidator;
import com.mindalliance.channels.ifm.Channels;
import com.mindalliance.channels.query.Query;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.form.TextArea;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 10, 2008
 * Time: 5:08:12 PM
 */
public class ScenarioAboutTab extends AbstractFormTab {

    public ScenarioAboutTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        // name
        TextField nameField = new TextField<String>("name", new RefPropertyModel<String>(getElement(), "name"));
        nameField.add(UniqueValidator.inQuery(Channels.instance(), new Query("findAllProjectNamesExceptFor", getElement())));
        nameField.setRequired(true);
        addInputField(nameField);
        // description
        TextArea descriptionField = new TextArea<String>("description", new RefPropertyModel<String>(getElement(), "description"));
        addInputField(descriptionField);
        StringListPanel goalsPanel = new StringListPanel("goals", this, "goals", 25, 4);
        addReplaceable(goalsPanel);
    }
}
