package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.markup.html.form.ListChoice;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.Component;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.model.Model;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 28, 2008
 * Time: 3:47:50 PM
 */
abstract public class AbstractListPanel<T> extends AbstractComponentPanel {

    private ListChoice<Integer> itemsChoice;
    private Component itemPanel;
    private WebMarkupContainer itemDiv;
    private Label itemLegendLabel;
    private Button addItemButton;
    private Button deleteItemButton;
    private Integer selectedItemIndex;
    private int maxRows = 3;
    private int summarySize = 30;

    public AbstractListPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
        // subclass must call doLoad();
    }


    public AbstractListPanel(String id, AbstractChannelsPanel parentPanel, String propPath, int maxRows, int summarySize) {
        this(id, parentPanel, propPath);
        this.maxRows = maxRows;
        this.summarySize = summarySize;
        // subclass must call doLoad();
    }

    abstract protected T makeNewItem();

    abstract protected Component makeItemPanel(String id, AbstractListPanel<T> parentPanel, String propPath);

    abstract protected String getItemLegend();

    protected void doLoad() {
        selectedItemIndex = getDefaultItemIndex();
        itemsChoice = new ListChoice<Integer>("items",
                new Model<Integer>(selectedItemIndex),
                new Model((Serializable)getIndices()),
                new ChoiceRenderer<Integer>() {
                    @Override
                    public String getDisplayValue(Integer index) {
                        Object item = getItems().get(index);
                        return RefUtils.summarize(item.toString(), summarySize);
                    }
                });
        itemsChoice.setMaxRows(maxRows);
        itemsChoice.add(
                new AjaxFormComponentUpdatingBehavior("onchange") {
                    @Override
                    protected void onUpdate(AjaxRequestTarget target) {
                        selectedItemIndex = itemsChoice.getModelObject();
                        updateOnSelection(target);
                    }
                });
        addReplaceable(itemsChoice);
        addItemButton = new Button("addItem");
        addItemButton.add(new AjaxEventBehavior("onclick") {
            @Override
            protected void onEvent(AjaxRequestTarget target) {
                List<T> items = getItems();
                items.add(makeNewItem());
                setProperty(items, target);
                selectedItemIndex = items.size() - 1;
                itemsChoice.setModelObject(selectedItemIndex);
                itemsChoice.setChoices(getIndices());
                updateOnSelection(target);
                target.addComponent(itemsChoice);
            }
        });
        addReplaceable(addItemButton);
        deleteItemButton = new Button("deleteItem");
        deleteItemButton.add(new AjaxEventBehavior("onclick") {
            @Override
            protected void onEvent(AjaxRequestTarget target) {
                List<T> items = getItems();
                items.remove((int) selectedItemIndex);
                setProperty(items, target);
                selectedItemIndex = null;
                itemsChoice.setModelObject(selectedItemIndex);
                itemsChoice.setChoices(getIndices());
                updateOnSelection(target);
                target.addComponent(itemsChoice);
            }
        });
        addReplaceable(deleteItemButton);
        itemDiv = new WebMarkupContainer("itemDiv");
        addReplaceable(itemDiv);
        itemLegendLabel = new Label("itemLegend", new Model<String>(getItemLegend()));
        addReplaceableTo(itemLegendLabel, itemDiv);
        itemPanel = new Label("item", new Model<String>(""));
        addReplaceableTo(itemPanel, itemDiv);
        updateVisibleAndEnabled();
    }

    private void updateOnSelection(AjaxRequestTarget target) {
        updateVisibleAndEnabled();
        target.addComponent(itemDiv);
        target.addComponent(deleteItemButton);
    }

    private void updateVisibleAndEnabled() {
        if (selectedItemIndex != null) {
            itemPanel = makeItemPanel("item", this, "[" + selectedItemIndex + "]");
        }
        else {
            itemPanel = new Label("item", new Model<String>(""));
        }
        addReplaceableTo(itemPanel, itemDiv);
        this.setVisibility(itemDiv, selectedItemIndex != null);
        this.setVisibility(deleteItemButton, selectedItemIndex != null);
    }


    private List<Integer> getIndices() {
        List<Integer> indices = new ArrayList<Integer>();
        List<T> items = getItems();
        for (int i = 0; i < items.size(); i++) {
            indices.add(i);
        }
        return indices;
    }

    private Integer getDefaultItemIndex() {
        if (getItems().size() > 0) return 0;
        else return null;
    }

    private List<T> getItems() {
        return (List<T>)getProperty();
    }

        @Override
    public void elementChanged( String propPath, AjaxRequestTarget target ) {
        super.elementChanged( propPath, target );
        if ( propPath.matches(
                ".*\\[\\d+\\].*" ) ) {
            target.addComponent( itemsChoice );
        }
    }
}
