package com.mindalliance.channels.pages.forms;

import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.pages.forms.tabs.scenario.ScenarioAboutTab;
import com.mindalliance.channels.pages.forms.tabs.scenario.ScenarioContentTab;
import org.apache.wicket.extensions.markup.html.tabs.AbstractTab;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.panel.Panel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 10, 2008
 * Time: 5:06:11 PM
 */
public class ScenarioForm extends AbstractElementForm {

    public ScenarioForm(String id, Ref element) {
        super(id, element);
    }

    void loadTabs() {
        tabs.add(new AbstractTab(new Model<String>("About scenario")) {
             public Panel getPanel(String panelId) {
                 return new ScenarioAboutTab(panelId, ScenarioForm.this);
             }
         });
        // TODO - add tab for profile extensions
        tabs.add(new AbstractTab(new Model<String>("Contents")) {
            public Panel getPanel(String panelId) {
                return new ScenarioContentTab(panelId, ScenarioForm.this);
            }
        });
    }
}
