package com.mindalliance.channels.pages.reports;

import org.apache.wicket.markup.html.WebPage;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jul 17, 2008
 * Time: 8:43:44 AM
 */
public class TBDReportPage extends WebPage {
}
