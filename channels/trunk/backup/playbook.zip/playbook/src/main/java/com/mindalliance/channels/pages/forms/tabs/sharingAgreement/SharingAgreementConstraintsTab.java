package com.mindalliance.channels.pages.forms.tabs.sharingAgreement;

import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.LimitationsOnUsePanel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 14, 2008
 * Time: 2:02:02 PM
 */
public class SharingAgreementConstraintsTab extends AbstractFormTab {

    protected LimitationsOnUsePanel constraintsPanel;

    public SharingAgreementConstraintsTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        constraintsPanel = new LimitationsOnUsePanel("constraints", this, "constraints");
        addReplaceable(constraintsPanel);
    }

}
