package com.mindalliance.channels.pages.forms;

import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.pages.forms.tabs.action.ActionAboutTab;
import com.mindalliance.channels.pages.forms.tabs.action.ActionPerformanceTab;
import com.mindalliance.channels.pages.forms.tabs.action.ActionLocationRequirementTab;
import com.mindalliance.channels.ifm.scenario.action.Action;
import org.apache.wicket.extensions.markup.html.tabs.AbstractTab;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.panel.Panel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 9, 2008
 * Time: 1:20:21 PM
 */
public abstract class AbstractActionForm extends AbstractElementForm {

    public AbstractActionForm(String id, Ref element) {
        super(id, element);
    }

    @Override
    void loadTabs() {
        Action act = (Action) element.deref();
        tabs.add(new AbstractTab(new Model<String>("About " + act.getType())) {
            @Override
            public Panel getPanel(String panelId) {
                return new ActionAboutTab(panelId, AbstractActionForm.this);
            }
        });
        tabs.add(new AbstractTab(new Model<String>("Performance")) {
            @Override
            public Panel getPanel(String panelId) {
                return new ActionPerformanceTab(panelId, AbstractActionForm.this);
            }
        });
        tabs.add(new AbstractTab(new Model<String>("Required location")) {
            @Override
            public Panel getPanel(String panelId) {
                return new ActionLocationRequirementTab(panelId, AbstractActionForm.this);
            }
        });
    }
}
