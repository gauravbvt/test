package com.mindalliance.channels.pages.forms.tabs.policy;

import com.mindalliance.channels.ifm.resource.organization.Policy;
import com.mindalliance.channels.pages.filters.DynamicFilterTree;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.MultipleStringChooser;
import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;

import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 26, 2008
 * Time: 3:31:51 PM
 */
public class PolicyRestrictionsTab extends AbstractFormTab {

    protected Policy policy;
    protected WebMarkupContainer mediumTypesDiv;
    protected AjaxCheckBox anyMediumField;
    protected Label mediumLegendLabel;
    protected Label anyMediumLabel;
    protected Label purposesLegendLabel;
    protected Label anyPurposeLabel;
    protected DynamicFilterTree mediumTypesTree;
    protected WebMarkupContainer purposesDiv;
    protected AjaxCheckBox anyPurposeField;
    protected MultipleStringChooser purposesChooser;

    public PolicyRestrictionsTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
/*        policy = (Policy) getElement().deref();
        setLabels(policy);
        addReplaceable(mediumLegendLabel);
        anyMediumField = new AjaxCheckBox("anyMedium", new Model<Boolean>(policy.getMediumTypes().isEmpty())) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean any = anyMediumField.getModelObject();
                if (any) {
                    RefUtils.set(policy, "mediumTypes", new ArrayList<Ref>());
                    mediumTypesDiv.add(new AttributeModifier("style", true, new Model<String>("display:none")));
                } else {
                    mediumTypesDiv.add(new AttributeModifier("style", true, new Model<String>("display:block")));
                }
                target.addComponent(mediumTypesDiv);
            }
        };
        addReplaceable(anyMediumField);
        addReplaceable(anyMediumLabel);
        mediumTypesDiv = new WebMarkupContainer("mediumTypesDiv");
        addReplaceable(mediumTypesDiv);
        setVisibility(mediumTypesDiv, !policy.getMediumTypes().isEmpty());
        mediumTypesTree = new DynamicFilterTree("mediumTypes", new RefPropertyModel(getElement(), "mediumTypes"),
                new RefQueryModel(getScope(), new Query("findAllTypes", "MediumType"))) {
            public void onFilterSelect(AjaxRequestTarget target, Filter filter) {
                List<Ref> selectedTypes = mediumTypesTree.getNewSelections();
                setProperty("mediumTypes", selectedTypes);
            }
        };
        addReplaceableTo(mediumTypesTree, mediumTypesDiv);
        addReplaceable(purposesLegendLabel);
        anyPurposeField = new AjaxCheckBox("anyPurpose", new Model<Boolean>( getPurposes().isEmpty())) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean any = anyPurposeField.getModelObject();
                if (any) {
                    RefUtils.set(policy, "purposes", new ArrayList<String>());
                }
                setVisibility(purposesDiv, !any, target);
            }
        };
        addReplaceable(anyPurposeLabel);
        purposesDiv = new WebMarkupContainer("purposesDiv");
        addReplaceable(purposesDiv);
        setVisibility(purposesDiv, !policy.getPurposes().isEmpty());
        addReplaceable(anyPurposeField);
        purposesChooser = new MultipleStringChooser("purposes", this, "purposes",
                new RefQueryModel(getProject(), new Query("findAllPurposes")));
        addReplaceableTo(purposesChooser, purposesDiv);*/
    }

    @SuppressWarnings( { "unchecked" } )
    private List<Ref> getPurposes() {
        return (List<Ref>) RefUtils.get(policy, "purposes");
    }

    private void setLabels(Policy policy) {
 /*       if (policy.isAllowing()) {
            mediumLegendLabel = new Label("mediumLegend","Sharing is allowed only when using one of these media");
            anyMediumLabel = new Label("anyMediumLabel","no restriction");
            purposesLegendLabel = new Label("purposesLegend","and only for one of these purposes");
            anyPurposeLabel = new Label("anyPurposeLabel","no restriction");
        } else {
            mediumLegendLabel = new Label("mediumLegend","Sharing is forbidden except when using any of these media");
            anyMediumLabel = new Label("anyMediumLabel","no exception");
            purposesLegendLabel = new Label("purposesLegend","and except for any of these purposes");
            anyPurposeLabel = new Label("anyPurposeLabel","no exception");
        }   */
    }

}
