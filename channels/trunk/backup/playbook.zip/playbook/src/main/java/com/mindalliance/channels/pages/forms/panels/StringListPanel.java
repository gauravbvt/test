package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.form.ListChoice;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.model.Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 7, 2008
 * Time: 4:59:05 PM
 */
public class StringListPanel extends AbstractComponentPanel {

    private ListChoice<Integer> stringsChoice;
    private TextArea stringTextArea;
    private Button addStringButton;
    private Button deleteStringButton;
    private int summarySize;
    private int maxRows;
    private Integer selectedStringIndex;

    public StringListPanel(String id, AbstractChannelsPanel parentPanel, String propPath, int summarySize, int maxRows) {
        super(id, parentPanel, propPath);
        this.summarySize = summarySize;
        this.maxRows = maxRows;
        doLoad();
    }

    protected void doLoad() {
        selectedStringIndex = getDefaultStringIndex();
        stringsChoice = new ListChoice<Integer>("strings",
                new Model<Integer>(selectedStringIndex),
                new Model((Serializable) getIndices()),
                new ChoiceRenderer<Integer>() {
                    @Override
                    public String getDisplayValue(Integer index) {
                        String string = getStrings().get(index);
                        return RefUtils.summarize(string, summarySize);
                    }
                });
        stringsChoice.setMaxRows(maxRows);
        stringsChoice.add(
                new AjaxFormComponentUpdatingBehavior("onchange") {
                    @Override
                    protected void onUpdate(AjaxRequestTarget target) {
                        selectedStringIndex = stringsChoice.getModelObject();
                        updateOnSelection(target);
                    }
                });
        addReplaceable(stringsChoice);
        addStringButton = new Button("addString");
        addStringButton.add(new AjaxEventBehavior("onclick") {
            @Override
            protected void onEvent(AjaxRequestTarget target) {
                List<String> list = getStrings();
                list.add("...");
                setProperty(list, target);
                selectedStringIndex = list.size() - 1;
                stringsChoice.setModelObject(selectedStringIndex);
                stringsChoice.setChoices(getIndices());
                updateOnSelection(target);
                target.addComponent(stringsChoice);
            }
        });
        addReplaceable(addStringButton);
        deleteStringButton = new Button("deleteString");
        deleteStringButton.add(new AjaxEventBehavior("onclick") {
            @Override
            protected void onEvent(AjaxRequestTarget target) {
                List<String> list = getStrings();
                list.remove((int) selectedStringIndex);
                setProperty(list, target);
                selectedStringIndex = getDefaultStringIndex();
                stringsChoice.setModelObject(selectedStringIndex);
                stringsChoice.setChoices(getIndices());
                updateOnSelection(target);
                target.addComponent(stringsChoice);
            }
        });
        addReplaceable(deleteStringButton);
        stringTextArea = new TextArea("string", new Model<String>());
        stringTextArea.add(
                new AjaxFormComponentUpdatingBehavior("onchange") {
                    @Override
                    protected void onUpdate(AjaxRequestTarget target) {
                        selectedStringIndex = stringsChoice.getModelObject();
                        String updatedString = stringTextArea.getDefaultModelObjectAsString();
                        List<String> list = getStrings();
                        list.set(selectedStringIndex, updatedString);
                        setProperty(list, target);
                        target.addComponent(stringsChoice);
                    }
                });
        addReplaceable(stringTextArea);
        updateVisibleAndEnabled();
    }

    private Integer getDefaultStringIndex() {
        if (getStrings().size() > 0) return 0;
        else return null;
    }

    private List<String> getStrings() {
        return (List<String>) getProperty();
    }

    private String getString() {
        if (selectedStringIndex != null) {
            return getStrings().get(selectedStringIndex);
        } else {
            return null;
        }
    }

    private List<Integer> getIndices() {
        List<Integer> indices = new ArrayList<Integer>();
        List<String> strings = getStrings();
        for (int i = 0; i < strings.size(); i++) {
            indices.add(i);
        }
        return indices;
    }

    private void updateVisibleAndEnabled() {
        stringTextArea.setModelObject(getString());
        this.setVisibility(deleteStringButton, selectedStringIndex != null);
        stringTextArea.setEnabled(selectedStringIndex != null);
    }

    private void updateOnSelection(AjaxRequestTarget target) {
        updateVisibleAndEnabled();
        target.addComponent(stringTextArea);
        target.addComponent(deleteStringButton);
    }

}
