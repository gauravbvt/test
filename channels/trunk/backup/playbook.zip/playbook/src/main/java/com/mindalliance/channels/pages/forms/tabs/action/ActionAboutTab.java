package com.mindalliance.channels.pages.forms.tabs.action;

import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.ReferencePanel;
import com.mindalliance.channels.pages.forms.panels.scenario.ActionTimingPanel;
import com.mindalliance.channels.pages.forms.panels.scenario.SubPlanNamePanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.support.models.RefQueryModel;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.ajax.AjaxRequestTarget;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 9, 2008
 * Time: 1:24:16 PM
 */
public class ActionAboutTab extends AbstractFormTab {

    private SubPlanNamePanel subPlanNamePanel;

    public ActionAboutTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        TextField nameField = new TextField<String>("name", new RefPropertyModel<String>(getElement(), "name"));
        addInputField(nameField);
        TextArea<String> descriptionField = new TextArea<String>("description", new RefPropertyModel<String>(getElement(), "description"));
        addInputField(descriptionField);
        ReferencePanel actorPanel = new ReferencePanel("actor", this, "actor", new RefQueryModel(getScenario(), "findAllAgentables"));
        addReplaceable(actorPanel);
        ActionTimingPanel timingPanel = new ActionTimingPanel("timing", this, "timing");
        addReplaceable(timingPanel);
        subPlanNamePanel = new SubPlanNamePanel("subPlanName", this, "");
        addReplaceable(subPlanNamePanel);
    }

    @Override
    public void elementChanged(String fullPath, AjaxRequestTarget target) {
        super.elementChanged(fullPath, target);
        if (fullPath.endsWith(".antecedent")) {
            subPlanNamePanel = new SubPlanNamePanel("subPlanName", this, "");
            addReplaceable(subPlanNamePanel);
            target.addComponent(subPlanNamePanel);
        }
    }

}
