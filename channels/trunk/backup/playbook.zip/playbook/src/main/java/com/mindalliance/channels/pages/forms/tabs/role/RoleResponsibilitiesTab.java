package com.mindalliance.channels.pages.forms.tabs.role;

import com.mindalliance.channels.ifm.responsibility.Responsibility;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.responsibility.ResponsibilityPanel;
import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.util.RefUtils;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.ListChoice;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.model.Model;

import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 5, 2008
 * Time: 7:09:26 PM
 */
public class RoleResponsibilitiesTab extends AbstractFormTab {

    protected ListChoice responsibilitiesChoice;
    protected AjaxButton deleteResponsibilityButton;
    protected AjaxButton addResponsibilityButton;

    protected WebMarkupContainer responsibilityDiv;
    protected Responsibility selectedResponsibility;

    public RoleResponsibilitiesTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        responsibilitiesChoice = new ListChoice("responsibilities", new Model(selectedResponsibility),
                                              new RefPropertyModel(getElement(), "responsibilities"),
                                              new ChoiceRenderer("summary"));
        responsibilitiesChoice.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                selectedResponsibility = (Responsibility)responsibilitiesChoice.getModelObject();
                loadResponsibilityPanel();
                setResponsibilityPanelVisibility(target);
                enable(deleteResponsibilityButton, selectedResponsibility != null, target);
            }
        });
        addReplaceable(responsibilitiesChoice);
        addResponsibilityButton = new AjaxButton("addResponsibility") {
            protected void onSubmit(AjaxRequestTarget target, Form form) {
              /*  selectedResponsibility = new Responsibility();
                RefUtils.add(getElement(), "responsibilities", selectedResponsibility);
                responsibilitiesChoice.setModelObject(selectedResponsibility);
                enable(deleteResponsibilityButton, true, target);
                loadResponsibilityPanel();
                setResponsibilityPanelVisibility(target);
                target.addComponent(responsibilitiesChoice);*/
            }
        };
        addReplaceable(addResponsibilityButton);
        deleteResponsibilityButton = new AjaxButton("deleteResponsibility") {
            protected void onSubmit(AjaxRequestTarget target, Form form) {
                RefUtils.remove(getElement(), "responsibilities", selectedResponsibility);
                selectedResponsibility = null;
                deleteResponsibilityButton.setEnabled(false);
                loadResponsibilityPanel();
                setResponsibilityPanelVisibility(target);
                target.addComponent(deleteResponsibilityButton);
                target.addComponent(responsibilitiesChoice);
            }
        };
        deleteResponsibilityButton.setEnabled(false);
        addReplaceable(deleteResponsibilityButton);

        responsibilityDiv = new WebMarkupContainer("responsibilityDiv");
        loadResponsibilityPanel();
        addReplaceable(responsibilityDiv);
        responsibilityDiv.add(new AttributeModifier("style", true, new Model<String>("display:none")));
    }

    private void setResponsibilityPanelVisibility(AjaxRequestTarget target) {
        if (selectedResponsibility != null) {
            responsibilityDiv.add(new AttributeModifier("style", true, new Model<String>("display:block")));
        } else {
            responsibilityDiv.add(new AttributeModifier("style", true, new Model<String>("display:none")));
        }
        target.addComponent(responsibilityDiv);
    }

    private void loadResponsibilityPanel() {
        if (selectedResponsibility == null) {
            Label dummyResponsibilityPanel = new Label("responsibility", "dummy");
            responsibilityDiv.addOrReplace(dummyResponsibilityPanel);
        } else {
            int index = ((List<Responsibility>) getProperty("responsibilities")).indexOf(selectedResponsibility);
            ResponsibilityPanel responsibilityPanel = new ResponsibilityPanel("responsibility", this,
                    "responsibilities[" + index + "]");
            responsibilityDiv.addOrReplace(responsibilityPanel);
        }
    }

    public void elementChanged(String fullPath, AjaxRequestTarget target) {
        super.elementChanged(fullPath, target);
        if (fullPath.matches(".*responsibilities.*")) {
            target.addComponent(responsibilitiesChoice);
        }
    }

}
