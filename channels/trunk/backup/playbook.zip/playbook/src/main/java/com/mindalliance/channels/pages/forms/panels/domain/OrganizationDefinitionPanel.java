package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.ifm.TagSet;
import com.mindalliance.channels.ifm.domain.LocationDefinition;
import com.mindalliance.channels.ifm.domain.OrganizationDefinition;
import com.mindalliance.channels.ifm.domain.OrganizationSpecification;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.TagSetsPanel;
import com.mindalliance.channels.support.models.RefQueryModel;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.Model;

import java.util.ArrayList;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jul 1, 2008
 * Time: 2:37:25 PM
 */
public class OrganizationDefinitionPanel extends AbstractDefinitionPanel {

    private OrganizationDefinition organizationDefinition;
    private AjaxCheckBox anyOrganizationTypeCheckBox;
    private WebMarkupContainer organizationTypesDiv;
    private TagSetsPanel tagSetsPanel;
    private AjaxCheckBox anyParentCheckBox;
    private WebMarkupContainer parentSpecDiv;
    private OrganizationSpecificationPanel parentSpecPanel;
    private AjaxCheckBox anyLocationCheckBox;
    private WebMarkupContainer locationSpecDiv;
    private LocationDefinitionPanel locationDefinitionPanel;
    private AjaxCheckBox anyJurisdictionCheckBox;
    private WebMarkupContainer jurisdictionDefinitionDiv;
    private LocationDefinitionPanel jurisdictionDefinitionPanel;


    public OrganizationDefinitionPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        organizationDefinition = (OrganizationDefinition)getComponent();
        anyOrganizationTypeCheckBox = new AjaxCheckBox("anyOrganizationType", new Model<Boolean>(organizationDefinition.getTagSets().isEmpty())){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyOrganizationType = anyOrganizationTypeCheckBox.getModelObject();
                if (anyOrganizationType) {
                    setProperty("tagSets", new ArrayList<TagSet>(), target);
                }
                setVisibility(organizationTypesDiv, !anyOrganizationType, target);
            }
        };
        addReplaceable(anyOrganizationTypeCheckBox);
        organizationTypesDiv = new WebMarkupContainer("organizationTypesDiv");
        setVisibility(organizationTypesDiv, !organizationDefinition.getTagSets().isEmpty());
        addReplaceable(organizationTypesDiv);
        tagSetsPanel = new TagSetsPanel("tagSets",this, "organizationTypes",
                                          new RefQueryModel(getProject(),"findAllOrganizationTags"));
        addReplaceableTo(tagSetsPanel, organizationTypesDiv);

        addReplaceableTo(tagSetsPanel, organizationTypesDiv);

        anyParentCheckBox = new AjaxCheckBox("anyParent", new Model<Boolean>(organizationDefinition.getParentOrganizationSpec().matchesAll())){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyParent = anyParentCheckBox.getModelObject();
                if (anyParent) {
                    setProperty("parentSpec", new OrganizationSpecification(), target);
                    parentSpecPanel = new OrganizationSpecificationPanel("parentOrganizationSpec", OrganizationDefinitionPanel.this, "parentOrganizationSpec");
                    addReplaceableTo(parentSpecPanel, parentSpecDiv);
                }
                setVisibility(parentSpecDiv, !anyParent, target);
            }
        };
        addReplaceable(anyParentCheckBox);
        parentSpecDiv = new WebMarkupContainer("parentOrganizationSpecDiv");
        setVisibility(parentSpecDiv, !organizationDefinition.getParentOrganizationSpec().matchesAll());
        addReplaceable(parentSpecDiv);
        parentSpecPanel = new OrganizationSpecificationPanel("parentOrganizationSpec", this, "parentOrganizationSpec");
        addReplaceableTo(parentSpecPanel, parentSpecDiv);

        anyLocationCheckBox = new AjaxCheckBox("anyLocation", new Model<Boolean>(organizationDefinition.getLocationSpec().matchesAll())){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyLocation = anyLocationCheckBox.getModelObject();
                if (anyLocation) {
                    setProperty("locationSpec", new LocationDefinition(), target);
                    locationDefinitionPanel = new LocationDefinitionPanel("locationSpec", OrganizationDefinitionPanel.this, "locationSpec");
                    addReplaceableTo(locationDefinitionPanel, locationSpecDiv);
                }
                setVisibility(locationSpecDiv, !anyLocation, target);
            }
        };
        addReplaceable(anyLocationCheckBox);
        locationSpecDiv = new WebMarkupContainer("locationSpecDiv");
        setVisibility(locationSpecDiv, !organizationDefinition.getLocationSpec().matchesAll());
        addReplaceable(locationSpecDiv);
        locationDefinitionPanel = new LocationDefinitionPanel("locationSpec", this,"locationSpec");
        addReplaceableTo(locationDefinitionPanel, locationSpecDiv);

        anyJurisdictionCheckBox = new AjaxCheckBox("anyJurisdiction", new Model<Boolean>(organizationDefinition.getJurisdictionSpec().matchesAll())){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyLocation = anyJurisdictionCheckBox.getModelObject();
                if (anyLocation) {
                    setProperty("jurisdictionDefinition", new LocationDefinition(), target);
                    jurisdictionDefinitionPanel = new LocationDefinitionPanel("jurisdictionSpec", OrganizationDefinitionPanel.this, "jurisdictionSpec");
                    addReplaceableTo(jurisdictionDefinitionPanel, jurisdictionDefinitionDiv);
                }
                setVisibility(jurisdictionDefinitionDiv, !anyLocation, target);
            }
        };
        addReplaceable(anyJurisdictionCheckBox);
        jurisdictionDefinitionDiv = new WebMarkupContainer("jurisdictionSpecDiv");
        setVisibility(jurisdictionDefinitionDiv, !organizationDefinition.getJurisdictionSpec().matchesAll());
        addReplaceable(jurisdictionDefinitionDiv);
        jurisdictionDefinitionPanel = new LocationDefinitionPanel("jurisdictionSpec", this, "jurisdictionSpec");
        addReplaceableTo(jurisdictionDefinitionPanel, jurisdictionDefinitionDiv);
    }
}
