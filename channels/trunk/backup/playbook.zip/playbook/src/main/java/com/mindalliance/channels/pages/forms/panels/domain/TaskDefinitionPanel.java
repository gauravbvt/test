package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.ifm.TagSet;
import com.mindalliance.channels.ifm.Timespan;
import com.mindalliance.channels.ifm.domain.TaskDefinition;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.MultipleStringChooser;
import com.mindalliance.channels.pages.forms.panels.TimespanPanel;
import com.mindalliance.channels.pages.forms.panels.TagSetPanel;
import com.mindalliance.channels.pages.forms.panels.TagSetsPanel;
import com.mindalliance.channels.support.models.RefQueryModel;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.Model;

import java.util.ArrayList;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jul 1, 2008
 * Time: 4:05:10 PM
 */
public class TaskDefinitionPanel extends AbstractDefinitionPanel {

    private TaskDefinition taskDefinition;
    private AjaxCheckBox anyTaskTypeCheckBox;
    private WebMarkupContainer taskTypesDiv;
    private TagSetsPanel tagSetsPanel;
    private AjaxCheckBox anyPurposeCheckBox;
    private WebMarkupContainer purposesDiv;
    private MultipleStringChooser purposesChooser;
    private AjaxCheckBox anyEventOutcomeCheckBox;
    private WebMarkupContainer eventOutcomesDiv;
    private TagSetPanel eventOutcomesTagSetPanel;
    private AjaxCheckBox anyResponseDelayCheckBox;
    private WebMarkupContainer responseDelayDiv;
    private TimespanPanel responseDelayPanel;


    public TaskDefinitionPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        taskDefinition = (TaskDefinition)getComponent();

        anyTaskTypeCheckBox = new AjaxCheckBox("anyTaskType", new Model<Boolean>(taskDefinition.getTagSets().isEmpty())){
             protected void onUpdate(AjaxRequestTarget target) {
                 boolean anyTaskType = anyTaskTypeCheckBox.getModelObject();
                 if (anyTaskType) {
                     setProperty("tagSets", new ArrayList<TagSet>());
                 }
                 setVisibility(taskTypesDiv, !anyTaskType, target);
             }
         };
         addReplaceable(anyTaskTypeCheckBox);
         taskTypesDiv = new WebMarkupContainer("taskTypesDiv");
         setVisibility(taskTypesDiv, !taskDefinition.getTagSets().isEmpty());
         addReplaceable(taskTypesDiv);
         tagSetsPanel = new TagSetsPanel("tagSets", this, "tagSets",
                                           new RefQueryModel(getProject(), "findAllTaskTags"));
         addReplaceableTo(tagSetsPanel, taskTypesDiv);

        anyPurposeCheckBox = new AjaxCheckBox("anyPurpose", new Model<Boolean>( taskDefinition.getPurposes().isEmpty() )){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyPurpose = anyPurposeCheckBox.getModelObject();
                if (anyPurpose) {
                    setProperty("specificPurposes", new ArrayList<String>());
                    purposesChooser = new MultipleStringChooser("purposes", TaskDefinitionPanel.this, "specificPurposes",
                            new RefQueryModel(getProject(), "findAllPurposes"));
                    addReplaceableTo(purposesChooser, purposesDiv);
                }
                setVisibility(purposesDiv, !anyPurpose, target);
            }
        };
        addReplaceable(anyPurposeCheckBox);
        purposesDiv = new WebMarkupContainer("purposesDiv");
        setVisibility(purposesDiv, !taskDefinition.getPurposes().isEmpty());
        addReplaceable(purposesDiv);
        purposesChooser = new MultipleStringChooser("purposes", this, "purposes",
                new RefQueryModel(getProject(), "findAllPurposes"));
        addReplaceableTo(purposesChooser, purposesDiv);


        anyEventOutcomeCheckBox = new AjaxCheckBox("anyEventOutcome", new Model<Boolean>(!taskDefinition.getEventOutcomeTagSet().isDefined())){
             protected void onUpdate(AjaxRequestTarget target) {
                 boolean anyEventOutcome = anyEventOutcomeCheckBox.getModelObject();
                 if (anyEventOutcome) {
                     setProperty("eventOutcomeTagSet", new TagSet());
                 }
                 setVisibility(eventOutcomesDiv, !anyEventOutcome, target);
             }
         };
         addReplaceable(anyEventOutcomeCheckBox);
         eventOutcomesDiv = new WebMarkupContainer("eventOutcomesDiv");
         setVisibility(eventOutcomesDiv, taskDefinition.getEventOutcomeTagSet().isDefined());
         addReplaceable(eventOutcomesDiv);
         eventOutcomesTagSetPanel = new TagSetPanel("eventOutcomeTagSet", this, "eventOutcomeTagSet",
                                                     new RefQueryModel(getProject(), "findAllEventTags"));
         addReplaceableTo(eventOutcomesTagSetPanel, eventOutcomesDiv);

        anyResponseDelayCheckBox = new AjaxCheckBox("anyResponseDelay", new Model<Boolean>(!taskDefinition.getResponseDelay().isDefined() )){
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyResponseDelay = anyResponseDelayCheckBox.getModelObject();
                if (anyResponseDelay) {
                    setProperty("reponseDelay", new Timespan());
                    responseDelayPanel = new TimespanPanel("responseDelay", TaskDefinitionPanel.this, "responseDelay");
                    addReplaceableTo(responseDelayPanel, responseDelayDiv);
                }
                setVisibility(responseDelayDiv, !anyResponseDelay, target);
            }
        };
        addReplaceable(anyResponseDelayCheckBox);
        responseDelayDiv = new WebMarkupContainer("responseDelayDiv");
        setVisibility(responseDelayDiv, taskDefinition.getResponseDelay().isDefined());
        addReplaceable(responseDelayDiv);
        responseDelayPanel = new TimespanPanel("responseDelay", this, "responseDelay");
        addReplaceableTo(responseDelayPanel, responseDelayDiv);
    }
}
