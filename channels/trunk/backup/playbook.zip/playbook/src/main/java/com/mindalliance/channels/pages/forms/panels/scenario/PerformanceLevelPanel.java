package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.resource.CapabilitiesPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.pages.forms.panels.TimespanPanel;
import com.mindalliance.channels.pages.forms.panels.ProbabilityPanel;
import com.mindalliance.channels.pages.forms.panels.CostPanel;
import com.mindalliance.channels.ifm.Timespan;
import com.mindalliance.channels.ifm.Probability;
import com.mindalliance.channels.ifm.Cost;
import com.mindalliance.channels.ifm.scenario.action.performance.Performance;
import com.mindalliance.channels.ifm.scenario.action.performance.PerformanceLevel;
import org.apache.wicket.ajax.AjaxRequestTarget;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 3:49:14 PM
 */
public class PerformanceLevelPanel extends AbstractComponentPanel {

    private Performance performance;
    private AbstractComponentPanel comparablePanel;
    private CapabilitiesPanel capabilitiesPanel;

    public PerformanceLevelPanel(String id, AbstractChannelsPanel parentPanel, String propPath, Performance performance) {     // parentPanel is an IComparablePanel
        super(id, parentPanel, propPath);
        this.performance = performance;
        doLoad();
    }

    private void doLoad() {
        comparablePanel = makeComparablePanel();
        addReplaceable(comparablePanel);
        capabilitiesPanel = new CapabilitiesPanel("capabilities", this,"capabilities");
        addReplaceable(capabilitiesPanel);
    }

    private AbstractComponentPanel makeComparablePanel() {
        Class comparableClass = performance.comparableClass();
        if (Timespan.class.isAssignableFrom(comparableClass)) {
            return new TimespanPanel("comparable", this, "value");
        } else if (Probability.class.isAssignableFrom(comparableClass)) {
            return new ProbabilityPanel("comparable", this, "value");
        } else if (Cost.class.isAssignableFrom(comparableClass)) {
            return new CostPanel("comparable", this, "value");
        } else {
            throw new RuntimeException("Not a comparable");
        }
    }

    // Catch changes to comparable value. Reset it if it breaks limit set by Performance.
    @Override
    public void elementChanged(String fullPath, AjaxRequestTarget target) {
        super.elementChanged(fullPath, target);
        if (fullPath.matches(".*\\.value.*")) { // value changed
            PerformanceLevel performanceLevel = (PerformanceLevel) getComponent();
            int comparison = performanceLevel.getValue().compareTo(performance.getDefaultValue());
            if ((performance.isMinimized() && comparison > 0) || (performance.isMaximized() && comparison < 0)) {
                setProperty("value", performance.copyDefaultValue(), target);
                comparablePanel = makeComparablePanel();
                addReplaceable(comparablePanel);
                target.addComponent(comparablePanel);
            }
        }
    }


}
