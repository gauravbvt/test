package com.mindalliance.channels.pages.forms.tests;

import org.apache.wicket.markup.html.WebPage;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 8, 2008
 * Time: 1:58:50 PM
 */
public class FormTest extends WebPage {

/*    ChannelsSession session;
    Label elementLabel;
    Ref selected;
    WebMarkupContainer debugDiv;

    public FormTest(PageParameters parms) {
        super(parms);
        try {
            load();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    *//**
     * @see org.apache.wicket.Page#configureResponse()
     *//*
    protected void configureResponse() {
        super.configureResponse();
        WebResponse response = getWebRequestCycle().getWebResponse();
        response.setContentType("application/xhtml+xml");
    }


    public Ref getSelected() {
        return selected;
    }

    public void setSelected(Ref selected) {
        this.selected = selected;
    }

    private void load() throws Exception {
        session = (ChannelsSession) Session.get();
        if (!session.authenticate("admin", "admin")) {
            throw new Exception("User not authenticated");
        }
        final FormPanel formPanel = new FormPanel("content-form", new PropertyModel(this, "selected"));
        add(formPanel);
        final DropDownChoice typesDropDown = new DropDownChoice("types", new Model(), new ArrayList());
        typesDropDown.setChoices(getTypeChoices());
        typesDropDown.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            protected void onUpdate(AjaxRequestTarget target) {
                Class type = (Class) typesDropDown.getModel().getObject();
                if (type != null) {
                    try {
                        setSelected(getElementOfType(type));
                        formPanel.modelChanged();
                        target.addComponent(formPanel);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (selected != null) {
                        elementLabel = new Label("elementString", new RefPropertyModel(selected, "name"));
                        elementLabel.setOutputMarkupId(true);
                        debugDiv.addOrReplace(elementLabel);
                        debugDiv.setOutputMarkupId(true);
                        target.addComponent(debugDiv);
                    }
                }
            }
        });
        add(typesDropDown);
        debugDiv = new WebMarkupContainer("debug");
        elementLabel = new Label("elementString", "");
        elementLabel.setOutputMarkupId(true);
        debugDiv.add(elementLabel);
        add(debugDiv);
        AjaxLink saveLink = new AjaxLink("save") {
            public void onClick(AjaxRequestTarget target) {
                ChannelsSession session = (ChannelsSession) Session.get();
                session.commit();
                formPanel.resetForm();
                target.addComponent(formPanel);
                Logger.getLogger(this.getClass()).info("COMMIT: " + (String) RefUtils.get(selected, "name"));
                target.addComponent(elementLabel);
            }
        };
        AjaxLink resetLink = new AjaxLink("reset") {
            public void onClick(AjaxRequestTarget target) {
                ChannelsSession session = (ChannelsSession) Session.get();
                session.abort();
                formPanel.resetForm();
                target.addComponent(formPanel);
                Logger.getLogger(this.getClass()).info("ABORT: " + RefUtils.get(selected, "name") + "\n");
            }
        };
        add(saveLink);
        add(resetLink);
    }

    private List getTypeChoices() {
        List choices = new ArrayList();
        // Environment
        choices.add(SharingAgreement.class);
        choices.add(Place.class);
        choices.add(Policy.class);
        // Resources
        choices.add(Organization.class);
        choices.add(Person.class);
        choices.add(Position.class);
        choices.add(System.class);
        // Scenario
        choices.add(Assignation.class);
        choices.add(Association.class);
        choices.add(ConfirmationRequest.class);
        choices.add(Detection.class);
        choices.add(Event.class);
        choices.add(Group.class);
        choices.add(InformationRequest.class);
        choices.add(InformationTransfer.class);
        choices.add(Relocation.class);
        choices.add(NotificationCommitment.class);
        choices.add(NotificationRequest.class);
        choices.add(Task.class);
        // Project elements
        choices.add(Scenario.class);
        // application
        choices.add(Project.class);
        choices.add(Tab.class);
        choices.add(User.class);
        return choices;
    }

    private Ref getElementOfType(Class type) throws Exception {
        ChannelsApplication app = (ChannelsApplication) Application.get();
        Ref channels = app.getChannels();
        Project project = (Project) Project.current().deref();
        List<Ref> results = new ArrayList<Ref>();
        if (type.equals(User.class)) {
            results.add(((Channels) channels.deref()).findUser("admin"));
        } else if (type.equals(Project.class)) {
            results.add(project.getReference());
        } else if (type.equals(SharingAgreement.class)) {
            results.add((Ref) project.getSharingAgreements().get(0));
        } else if (type.equals(Scenario.class)) {
            results.add((Ref) project.findScenarioNamed("default"));
        }
        if (results.size() > 0) {
            return results.get(0);
        } else {   // Project, model and scenario elements (assumes at least one pre-defined project, model and scenario
            ModelElement element = (ModelElement) type.newInstance();
            element.persist();
            Ref ref = element.getReference();
            if (element.isScenarioElement()) {
                Scenario scenario = (Scenario) ((Ref) project.getScenarios().get(0)).deref();
                scenario.getReference().begin();
                scenario.addElement(element);
            }
            else if (element.isProjectElement()) {
                InProject projectElement = (InProject) element;
                project.getReference().begin();
                if (projectElement instanceof Resource) {
                    Resource resource = (Resource) projectElement;
                    if (resource.isOrganizationResource()) {
                        Ref org = (Ref) project.getOrganizations().get(0); // assumes at least one organization pre-defined
                        org.begin();
                        ((Organization) org.deref()).addElement(element);
                    } else {
                        project.addElement(element);
                    }
                } else {
                    project.addElement(element);
                }
            }
            return ref;
        }
    }*/

}