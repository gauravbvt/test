package com.mindalliance.channels.pages.forms.panels.location;

import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.pages.forms.panels.ReferencePanel;
import com.mindalliance.channels.pages.forms.panels.TagSetPanel;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.ifm.location.AreaType;
import com.mindalliance.channels.ifm.location.RelativeLocation;
import com.mindalliance.channels.ifm.TagSet;
import com.mindalliance.channels.util.RefUtils;
import com.mindalliance.channels.support.models.RefQueryModel;
import com.mindalliance.channels.ref.Ref;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.model.Model;

import java.util.List;
import java.util.ArrayList;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 30, 2008
 * Time: 11:30:42 AM
 */
public class RelativeLocationPanel extends AbstractComponentPanel {

    static private final String PLACE = "Place";

    private RelativeLocation relativeLocation;
    private DropDownChoice<String> placeOrAreaTypeChoice;
    private WebMarkupContainer placeTagsDiv;
    private TagSetPanel placeTagsPanel;
    private AjaxCheckBox locationCheckBox;
    private AjaxCheckBox jurisdictionCheckBox;
    private ReferencePanel relatedPanel;

    public RelativeLocationPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        relativeLocation = (RelativeLocation)getComponent();
        placeOrAreaTypeChoice = new DropDownChoice<String>("placeOrAreaType", new Model<String>(getEncompassement()), getEncompassementChoices());
        placeOrAreaTypeChoice.add(
                new AjaxFormComponentUpdatingBehavior( "onchange" ) {
                    @Override
                    protected void onUpdate( AjaxRequestTarget target ) {
                        String encompassement = placeOrAreaTypeChoice.getModelObject();
                        if (encompassement.equals(PLACE)) {
                           setProperty("areaType", null, target);
                           setVisibility(placeTagsDiv, true, target);
                        }
                        else {
                            setProperty("areaType", AreaType.fromName(encompassement));
                            setProperty("placeTags", new TagSet());
                            setVisibility(placeTagsDiv, false, target);
                        }
                    }
                });
        addReplaceable(placeOrAreaTypeChoice);
        placeTagsDiv = new WebMarkupContainer("placeTagsDiv");
        setVisibility(placeTagsDiv, relativeLocation.getPlaceTags().isDefined());
        addReplaceable(placeTagsDiv);
        placeTagsPanel = new TagSetPanel("placeTags", this, "placeTags", new RefQueryModel(getProject(), "findAllPlaceTags"));
        addReplaceableTo(placeTagsPanel, placeTagsDiv);
        locationCheckBox = new AjaxCheckBox("isLocatable", new Model<Boolean>(isRelativeToLocatable())) {
            protected void onUpdate(AjaxRequestTarget target) {
                updateRelatedPanel(locationCheckBox.getModelObject(), target);
                toggle(locationCheckBox, jurisdictionCheckBox, target);
            }
        };
        addReplaceable(locationCheckBox);
        jurisdictionCheckBox = new AjaxCheckBox("isJurisdictionable", new Model<Boolean>(!isRelativeToLocatable())) {
            protected void onUpdate(AjaxRequestTarget target) {
                updateRelatedPanel(!jurisdictionCheckBox.getModelObject(), target);
                toggle(jurisdictionCheckBox, locationCheckBox, target);
            }
        };
        addReplaceable(jurisdictionCheckBox);
        addRelatedPanel(locationCheckBox.getModelObject());
    }

    private void updateRelatedPanel(boolean isLocatable, AjaxRequestTarget target) {
        if (isLocatable) {
            setProperty("jurisdictionable", null, target);
        }
        else {
            setProperty("locatable", null, target);
        }
        addRelatedPanel(isLocatable);
        target.addComponent(relatedPanel);
    }

    private void addRelatedPanel(boolean isLocatable) {
        if (isLocatable) {
            relatedPanel = new ReferencePanel("related", this, "locatable",
                                              new RefQueryModel<Ref>(getScenarioOrElseProject(), "findAllLocatables"));
        }
        else {
            relatedPanel = new ReferencePanel("related", this, "jurisdictionable",
                                              new RefQueryModel<Ref>(getProject(), "findAllJurisdictionables"));

        }
        addReplaceable(relatedPanel);
    }

    private Boolean isRelativeToLocatable() {
        return relativeLocation.getJurisdictionable() == null;
    }

    private String getEncompassement() {
        if (relativeLocation.getPlaceTags().isDefined()) return PLACE;
        if (relativeLocation.getAreaType() != null) return (String)RefUtils.get(relativeLocation, "areaType.name");
        else return AreaType.COUNTRY;
    }

    private List<String> getEncompassementChoices() {
       List<String> choices = new ArrayList<String>();
        choices.add(PLACE);
        choices.addAll(AreaType.allAreaTypeNames());
        return choices;
    }
}
