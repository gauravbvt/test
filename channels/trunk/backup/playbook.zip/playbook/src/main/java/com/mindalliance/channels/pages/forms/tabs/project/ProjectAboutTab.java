package com.mindalliance.channels.pages.forms.tabs.project;

import com.mindalliance.channels.ifm.Channels;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.StringListPanel;
import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.query.Query;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.util.validators.UniqueValidator;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.markup.html.form.TextField;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 24, 2008
 * Time: 1:11:57 PM
 */
public class ProjectAboutTab extends AbstractFormTab {

    TextField nameField;
    TextArea descriptionField;
    StringListPanel goalsPanel;

    public ProjectAboutTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        // name
        nameField = new TextField("name", new RefPropertyModel(getElement(), "name"));
        nameField.add(UniqueValidator.inQuery(Channels.instance(), new Query("findAllProjectNamesExceptFor", getElement())));
        nameField.setRequired(true);
        addInputField(nameField);
        // description
        descriptionField = new TextArea("description", new RefPropertyModel(getElement(), "description"));
        addInputField(descriptionField);
        goalsPanel = new StringListPanel("goals", this, "goals", 25, 4);
        addReplaceable(goalsPanel);
    }
}
