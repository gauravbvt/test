package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.ifm.domain.Definition;
import com.mindalliance.channels.ifm.domain.EventDefinition;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.domain.AbstractDefinitionPanel;
import com.mindalliance.channels.pages.forms.panels.domain.AbstractSpecificationPanel;
import com.mindalliance.channels.pages.forms.panels.domain.EventDefinitionPanel;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;

import java.util.ArrayList;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jul 1, 2008
 * Time: 9:55:48 AM
 */
public class EventSpecificationPanel extends AbstractSpecificationPanel {

    public EventSpecificationPanel(
            String id, AbstractChannelsPanel parentPanel, String propPath ) {
        super( id, parentPanel, propPath );
    }

  @Override
    protected String getMatchingDomainName() {
        return "event";
    }

    @Override
    protected AbstractDefinitionPanel makeDefinitionEditor(
            String id, String propPath ) {
        return new EventDefinitionPanel( id, this, propPath );
    }

    @Override
    protected boolean isEnumerable() {
        return getScenario() != null;
    }

    @Override
    protected IModel<ArrayList<Ref>> getEnumerationChoicesModel() {
        if ( getScenario() != null ) {
            return new RefPropertyModel<ArrayList<Ref>>( getScenario(), "events" );
        } else {
            return new Model<ArrayList<Ref>>( new ArrayList<Ref>() );
        }
    }

    @Override
    protected Definition makeNewDefinition() {
        return new EventDefinition();
    }

}
