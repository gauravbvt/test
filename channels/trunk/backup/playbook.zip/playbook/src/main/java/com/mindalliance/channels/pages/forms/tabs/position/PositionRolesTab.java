package com.mindalliance.channels.pages.forms.tabs.position;

import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.support.models.RefQueryModel;
import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.filters.DynamicFilterTree;
import com.mindalliance.channels.pages.filters.Filter;
import com.mindalliance.channels.query.Query;
import org.apache.wicket.ajax.AjaxRequestTarget;

import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 24, 2008
 * Time: 9:21:40 AM
 */
public class PositionRolesTab extends AbstractFormTab {

    DynamicFilterTree roleTree;

    public PositionRolesTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        roleTree = new DynamicFilterTree("roles", new RefPropertyModel(getElement(), "roles"), 
                                                  new RefQueryModel(getProject(), new Query("findAllTypes", "Role"))) {
             public void onFilterSelect( AjaxRequestTarget target, Filter filter ) {
                List<Ref> newSelections = roleTree.getNewSelections();
                setProperty("roles", newSelections);
             }
        };
        addReplaceable(roleTree);
    }
}
