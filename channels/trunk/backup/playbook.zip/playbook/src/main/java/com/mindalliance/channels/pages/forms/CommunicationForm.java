package com.mindalliance.channels.pages.forms;

import com.mindalliance.channels.ref.Ref;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 9, 2008
 * Time: 9:52:16 PM
 */
public class CommunicationForm extends AbstractActionForm {

    public CommunicationForm(String id, Ref element) {
        super(id, element);
    }

    void loadTabs() {
        super.loadTabs();
    }
}
