package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.form.ListChoice;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;

import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 24, 2008
 * Time: 9:13:27 PM
 */
public class StringWithChoicesPanel extends AbstractComponentPanel {

    private int maxRows = 4;
    private int maxSize = 30;
    private IModel choices;
    private TextField<String> stringField;
    private String selectedString;
    private WebMarkupContainer choicesDiv;
    private ListChoice<String> stringsChoice;

    public StringWithChoicesPanel(String id, AbstractChannelsPanel parentPanel, String propPath, IModel choices, int maxRows, int maxSize) {
        super(id, parentPanel, propPath);
        this.maxRows = maxRows;
        this.maxSize = maxSize;
        this.choices = choices;
        doLoad();
    }


    public StringWithChoicesPanel(String id, AbstractChannelsPanel parentPanel, String propPath, IModel choices) {
        super(id, parentPanel, propPath);
        this.choices = choices;
        doLoad();
    }

    private void doLoad() {
        List<String> strings = (List <String>)choices.getObject();
        stringField = new TextField<String>("string", new RefPropertyModel<String>(getElement(), getFullPropertyPath()));
        stringField.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                selectedString = stringField.getModelObject();
                setProperty(selectedString.trim());
            }
        });
        addReplaceable(stringField);
        choicesDiv = new WebMarkupContainer("choicesDiv");
        setVisibility(choicesDiv, !strings.isEmpty());
        addReplaceable(choicesDiv);
        stringsChoice = new ListChoice<String>("choices", new Model<String>(), choices,
                new ChoiceRenderer<String>() {
                    @Override
                    public String getDisplayValue(String object) {
                        return RefUtils.summarize(object, maxSize);
                    }
                });
        stringsChoice.setMaxRows(Math.min(strings.size()+1, maxRows));
        stringsChoice.add(
                new AjaxFormComponentUpdatingBehavior("onchange") {
                    @Override
                    protected void onUpdate(AjaxRequestTarget target) {
                        selectedString = stringsChoice.getModelObject();
                        setProperty(selectedString);
                        updateStringField(target);
                    }
                });
        addReplaceableTo(stringsChoice, choicesDiv);
    }

    private void updateStringField(AjaxRequestTarget target) {
        stringField.setModelObject(selectedString);
        target.addComponent(stringField);
    }


}
