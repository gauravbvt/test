package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.scenario.PerformanceLevelPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.ifm.scenario.action.performance.PerformanceLevel;
import com.mindalliance.channels.ifm.scenario.action.performance.Performance;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.markup.html.form.ListChoice;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.Model;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.Component;

import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 3:51:11 PM
 */
public class PerformanceLevelsPanel extends AbstractComponentPanel {

    private Performance performance;
    private ListChoice<PerformanceLevel> performanceLevelsChoice;
    private Button addPerformanceLevelButton;
    private Button removePerformanceLevelButton;
    private WebMarkupContainer performanceLevelDiv;
    private Component performanceLevelPanel;
    private PerformanceLevel selectedPerformanceLevel;


    public PerformanceLevelsPanel(String id, AbstractChannelsPanel parentPanel, String propPath, Performance performance) {
        super(id, parentPanel, propPath);
        this.performance = performance;
        doLoad();
    }

    private void doLoad() {
        super.load();
        selectedPerformanceLevel = getDefaultSelectedPerformanceLevel();
        performanceLevelsChoice = new ListChoice<PerformanceLevel>("performanceLevels", new Model<PerformanceLevel>(selectedPerformanceLevel),
                                                         new RefPropertyModel(getElement(), getFullPropertyPath()));
        performanceLevelsChoice.add(
                new AjaxFormComponentUpdatingBehavior("onchange") {
                    @Override
                    protected void onUpdate(AjaxRequestTarget target) {
                        selectedPerformanceLevel = performanceLevelsChoice.getModelObject();
                        updatePerformanceLevelSelected(target);
                    }
                });
        performanceLevelsChoice.setMaxRows(3);
        addReplaceable(performanceLevelsChoice);
        addPerformanceLevelButton = new Button("addPerformanceLevel");
        addPerformanceLevelButton.add(new AjaxEventBehavior("onclick") {
            @Override
            protected void onEvent(AjaxRequestTarget target) {
                selectedPerformanceLevel = PerformanceLevel.from(performance);
                List<PerformanceLevel> performanceLevels = (List<PerformanceLevel>)getProperty();
                performanceLevels.add(selectedPerformanceLevel);
                setProperty(performanceLevels);
                performanceLevelsChoice.setModelObject(selectedPerformanceLevel);
                target.addComponent(performanceLevelsChoice);
                updatePerformanceLevelSelected(target);
            }
        });
        addReplaceable(addPerformanceLevelButton);
        removePerformanceLevelButton = new Button("removePerformanceLevel");
        removePerformanceLevelButton.add(new AjaxEventBehavior("onclick") {
            @Override
            protected void onEvent(AjaxRequestTarget target) {
                if (selectedPerformanceLevel != null) {
                    RefUtils.remove(getElement(), propPath, selectedPerformanceLevel);
                    selectedPerformanceLevel = null;
                    performanceLevelsChoice.setModelObject(selectedPerformanceLevel);
                    target.addComponent(performanceLevelsChoice);
                    updatePerformanceLevelSelected(target);
                }
            }
        });
        addReplaceable(removePerformanceLevelButton);
        performanceLevelDiv = new WebMarkupContainer("performanceLevelDiv");
        addReplaceable(performanceLevelDiv);
        updatePerformanceLevelSelected();
    }

    private PerformanceLevel getDefaultSelectedPerformanceLevel() {
        List<PerformanceLevel> performanceLevels = (List<PerformanceLevel>)getProperty();
        if (performanceLevels.size() > 0) {
            return performanceLevels.get(0);
        }
        else {
            return null;
        }
    }

    private int getPerformanceLevelIndex() {
        int index = -1;
        if (selectedPerformanceLevel != null) index = ((List<PerformanceLevel>)getProperty()).indexOf(selectedPerformanceLevel);
        return index;
    }

    private void updatePerformanceLevelSelected() {
        if (selectedPerformanceLevel != null) {
            performanceLevelPanel = new PerformanceLevelPanel("performanceLevel", this, "[" + getPerformanceLevelIndex() + "]", performance);
        }
        else {
            performanceLevelPanel = new WebMarkupContainer("performanceLevel");
        }
        addReplaceableTo(performanceLevelPanel, performanceLevelDiv);
        setVisibility(removePerformanceLevelButton, selectedPerformanceLevel != null);
        setVisibility(performanceLevelDiv, selectedPerformanceLevel != null);
    }

    private void updatePerformanceLevelSelected(AjaxRequestTarget target) {
        updatePerformanceLevelSelected();
        target.addComponent(performanceLevelPanel);
        target.addComponent(removePerformanceLevelButton);
        target.addComponent(performanceLevelDiv);
    }

    public Class getComparableClass() {
        return performance.comparableClass();
    }

    @Override
    public void elementChanged( String propPath, AjaxRequestTarget target ) {
        super.elementChanged( propPath, target );
        if ( propPath.matches(
                ".*\\.performanceLevels\\[.*" ) ) {
            target.addComponent( performanceLevelsChoice );
        }
    }

}
