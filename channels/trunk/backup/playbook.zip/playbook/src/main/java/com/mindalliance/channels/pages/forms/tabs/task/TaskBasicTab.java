package com.mindalliance.channels.pages.forms.tabs.task;

import com.mindalliance.channels.pages.filters.DynamicFilterTree;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.TimespanPanel;
import com.mindalliance.channels.pages.forms.tabs.action.ActionAboutTab;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.repeater.RefreshingView;

import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 9, 2008
 * Time: 9:25:34 PM
 */
public class TaskBasicTab extends ActionAboutTab {

    protected DynamicFilterTree taskTypeTree;
    protected WebMarkupContainer purposesDiv;
    protected RefreshingView purposesView;
    protected AjaxButton addPurposeButton;
    protected TimespanPanel durationPanel;

    public TaskBasicTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
 /*       final Task task = (Task)getElement().deref();
        taskTypeTree = new DynamicFilterTree("taskType", new RefPropertyModel(getElement(), "taskType"),
                new RefQueryModel(getProject(),
                        new Query("findAllTypes", "TaskType")), SINGLE_SELECTION) {
            public void onFilterSelect(AjaxRequestTarget target, Filter filter) {
                Ref selectedType = taskTypeTree.getNewSelection();
                setProperty("taskType", selectedType);
            }
        };
        addReplaceable(taskTypeTree);
        purposesDiv = new WebMarkupContainer("purposesDiv");
        addReplaceable(purposesDiv);
        purposesView = new RefreshingView("purposes", new RefPropertyModel(getElement(), "specificPurposes")) {
            protected Iterator getItemModels() {
                List<Integer> indices = listIndicesIn((List)purposesView.getDefaultModelObject());
                return new ModelIteratorAdapter(indices.iterator()) {
                    protected IModel model(Object index) {
                        return new Model((Integer) index);
                    }
                };
            }
            protected void populateItem(Item item) {
                final int index = (Integer)item.getModelObject();
                String purpose = (String)task.getSpecificPurposes().get(index);
                final TextArea purposeField = new TextArea("purpose", new Model(purpose));
                purposeField.add(new AjaxFormComponentUpdatingBehavior("onchange"){
                    protected void onUpdate(AjaxRequestTarget target) {
                        task.getSpecificPurposes().remove(index);
                        task.getSpecificPurposes().add(index, purposeField.getDefaultModelObjectAsString());
                        task.changed("specificPurposes");
                    }
                });
                item.add(purposeField);
                AjaxLink deleteLink = new AjaxLink("deletePurpose") {
                    public void onClick(AjaxRequestTarget target) {
                        task.getSpecificPurposes().remove(index);
                        task.changed("specificPurposes");
                        target.addComponent(purposesDiv);
                    }
                };
                item.add(deleteLink);
            }
        };
        addReplaceableTo(purposesView, purposesDiv);
        addPurposeButton = new AjaxButton("addPurpose") {
            protected void onSubmit(AjaxRequestTarget target, Form form) {
                task.getSpecificPurposes().add("");
                task.changed("specificPurposes");
                target.addComponent(purposesDiv);
            }
        };
        addReplaceableTo(addPurposeButton,purposesDiv);
        durationPanel = new TimespanPanel("duration", this, "duration");
        addReplaceable(durationPanel);*/
    }

    private List<Integer> listIndicesIn(List list) {
        List<Integer> indices = new ArrayList<Integer>();
        for (int i=0; i<list.size(); i++) {
            indices.add(i);
        }
        return indices;
    }

}
