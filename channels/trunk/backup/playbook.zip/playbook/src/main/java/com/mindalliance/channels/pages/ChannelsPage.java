package com.mindalliance.channels.pages;

import com.mindalliance.channels.ifm.Tab;
import com.mindalliance.channels.ifm.User;
import com.mindalliance.channels.mem.SessionMemory;
import com.mindalliance.channels.pages.filters.Filter;
import com.mindalliance.channels.pages.filters.UserScope;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.ref.Referenceable;
import com.mindalliance.channels.util.ChannelsSession;
import com.mindalliance.channels.support.models.ContainerSummary;
import com.mindalliance.channels.support.models.FilteredContainer;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.PageParameters;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.authentication.pages.SignOutPage;
import org.apache.wicket.authorization.strategies.role.annotations.AuthorizeInstantiation;
import org.apache.wicket.extensions.markup.html.tabs.AbstractTab;
import org.apache.wicket.extensions.markup.html.tabs.ITab;
import org.apache.wicket.extensions.markup.html.tabs.TabbedPanel;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.link.BookmarkablePageLink;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.AbstractReadOnlyModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.protocol.http.WebResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * ...
 */
@AuthorizeInstantiation( { "USER" } )
public class ChannelsPage extends WebPage {

    private Ref selectedTab;
    private TabbedPanel tabPanel;
    private UserScope scope;
    private Button saveButton;
    private Button revertButton;

    //-----------------------
    public ChannelsPage( PageParameters parms ){
        super( parms );
        scope = new UserScope();
        load();
    }

    private void load() {
        setDefaultModel( new Model<ChannelsSession>( getSession() ) );

        addOrReplace( new Label("title", new AbstractReadOnlyModel(){
            public Object getObject() {
                Ref ref = getSelectedTab();
                if ( ref == null )
                    return "Channels";
                else {
                    Tab tab = (Tab) ref.deref();
                    return tab.getName() + " - Channels" ;
                }
            }
        } ));
        addOrReplace( new Label("name", new RefPropertyModel(getDefaultModel(), "user.name")));
        addOrReplace( new BookmarkablePageLink("signout", SignOutPage.class, getPageParameters()));

        tabPanel = createTabPanel( "user-tabs" );
        addOrReplace( tabPanel );

        //--------------
        Form pageControls = new Form( "page_controls" );
        saveButton = new Button( "save_button" ) {
            public boolean isEnabled() {
                return !getSessionMemory().isEmpty();
            }

            public void onSubmit() {
                getSessionMemory().commit();
                scope.detach();
                load();
                setResponsePage( ChannelsPage.this );
            }
        };
        saveButton.setOutputMarkupId( true );
        revertButton = new Button( "revert_button" ) {
            public boolean isEnabled() {
                return !getSessionMemory().isEmpty();
            }

            public void onSubmit() {
                getSessionMemory().abort();
                scope.detach();
                load();
                setResponsePage( ChannelsPage.this );
            }
        };
        revertButton.setOutputMarkupId( true );
        pageControls.add( saveButton );
        pageControls.add( revertButton );
//        pageControls.add( new AjaxSelfUpdatingTimerBehavior( Duration.seconds(2) ) );
        addOrReplace( pageControls );

        User user = getUser();
        setSelectedTab( user.getSelectedTab() );
        tabPanel.setSelectedTab( user.getTabs().indexOf( this.selectedTab ) );
    }

    //-----------------------
    public ChannelsSession getSession() {
        return (ChannelsSession) super.getSession();
    }

    private Ref getUserRef() {
        return getSession().getUser();
    }

    private User getUser() {
        return (User) getUserRef().deref();
    }

    private SessionMemory getSessionMemory() {
        return getSession().getMemory();
    }

    //-----------------------
    public Ref getSelectedTab() {
        return selectedTab;
    }

    public void setSelectedTab( Ref selectedTab ) {

        if ( this.selectedTab == null || !this.selectedTab.equals( selectedTab ) ) {
            if ( this.selectedTab != null ) {
                Tab old = (Tab) this.selectedTab.deref();
                old.detach();
            }

            final Ref ref = getUserRef();
            ref.begin();
            final User user = (User) ref.deref();
            List<Ref> refList = user.getTabs();

            this.selectedTab = selectedTab == null ?
                               refList.get( 0 ) : selectedTab;

            user.setSelectedTab( this.selectedTab );
            user.changed( "selectedTab" );
            ref.commit();
            ref.detach();
            assert this.selectedTab.equals( getUser().getSelectedTab() );
            tabPanel.setSelectedTab( refList.indexOf( this.selectedTab ) );
        }
    }

    protected void configureResponse() {
        super.configureResponse();
        WebResponse response = getWebRequestCycle().getWebResponse();
        response.setContentType("application/xhtml+xml");
    }

    //-----------------------
    private TabbedPanel createTabPanel( String id ) {
        return new TabbedPanel( id, createUserTabs() ) {
            protected WebMarkupContainer newLink( String linkId, final int index ) {
                return new Link( linkId ) {
                    public void onClick() {
                        ChannelsPage.this.setSelectedTab( (Ref) getUser().getTabs().get( index ) );
                    }
                };
            }
        };
    }

    private List<ITab> createUserTabs() {
        List<ITab> result = new ArrayList<ITab>();

        final Ref userRef = getUserRef();
        User user = (User) userRef.deref();
        List<Ref> tabs = user.getTabs();
        if ( tabs.size() > 0 )
            for ( Ref ref : tabs ) {
                Tab t = (Tab) ref.deref();
                if ( t.getBase() instanceof UserScope )
                    scope = (UserScope) t.getBase();
                result.add( createTab( ref ) );
            }
        else {
            // TODO initialize from shared tabs

            final Tab tab = new Tab( scope );
            final Ref tabRef = tab.persist();
            userRef.begin();
            // The following is required, as the begin sometimes produces a copy
            user = (User) userRef.deref();
            assert !getSessionMemory().getChanges().contains( userRef );
            user.addTab( tabRef );
            assert getSessionMemory().getChanges().contains( userRef );
            tabRef.commit();
            userRef.commit();
            assert !getSessionMemory().getChanges().contains( userRef );

            result.add( createTab( tabRef ) );
            scope.detach();
        }

        return result;
    }

    private AbstractTab createTab( final Ref tab ) {
        return new AbstractTab( new RefPropertyModel( tab, "name" ) ) {
            private Panel panel;
            public Panel getPanel( String panelId ) {
                if ( panel == null )
                    panel = new TabPanel( panelId, new RefPropertyModel(ChannelsPage.this, "selectedTab") ) {
                        public void doAjaxSelection( Ref ref, AjaxRequestTarget target ) {
                            super.doAjaxSelection( ref, target );
                            target.addComponent( saveButton );
                            target.addComponent( revertButton );
                        }

                        protected void onFilterSave( Tab tab, Filter filter ) {
                            Tab newTab = new Tab( scope );
                            Ref newTabRef = newTab.persist();

                            try {
                                Filter f = filter.clone();
                                newTab.setBase( new FilteredContainer( tab.getBase(), f ) );
                            } catch ( CloneNotSupportedException e ) {
                                throw new RuntimeException( e );
                            }

                            Ref userRef = getUserRef();
                            userRef.begin();
                            User u = (User) userRef.deref();

                            List<Class<? extends Referenceable>> c = newTab.getAllowedClasses();
                            if ( c.size() == 1 ) {
                                newTab.setName( ContainerSummary.toDisplay( c.get(0).getSimpleName() ) + "s" );
                            } else
                                newTab.setName( "Tab " + (u.getTabs().size() + 1) );

                            u.addTab( newTabRef );
                            assert getSessionMemory().getChanges().contains( userRef );
                            newTab.detach();
                            newTabRef.commit();
                            userRef.commit();
                            assert !getSessionMemory().getChanges().contains( userRef );
                            assert !getSessionMemory().getBegun().containsKey( userRef );
                            assert !getSessionMemory().getChanges().contains( newTabRef );
                            assert !getSessionMemory().getBegun().containsKey( newTabRef );
                            ChannelsPage.this.detach();
                            load();
                        }
                    };
                return panel;
            }
        };
    }

    public UserScope getScope() {
        return scope;
    }

    public void detachModels() {
        super.detachModels();
        scope.detach();
    }
}
