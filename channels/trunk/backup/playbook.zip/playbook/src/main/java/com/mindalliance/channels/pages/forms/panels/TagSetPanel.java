package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import org.apache.wicket.model.IModel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 28, 2008
 * Time: 12:44:43 PM
 */
public class TagSetPanel extends AbstractComponentPanel {

    private IModel choices;

    public TagSetPanel(String id, AbstractChannelsPanel parentPanel, String propPath, IModel choices) {
        super(id, parentPanel, propPath);
        this.choices = choices;
        doLoad();
    }

    private void doLoad() {
        MultipleStringChooser tagsPanel = new MultipleStringChooser("tagSet", this, "tags", choices);
        addReplaceable(tagsPanel);
    }
}
