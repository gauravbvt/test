package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.ref.Bean;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.util.RefUtils;
import org.apache.log4j.Logger;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.html.panel.FeedbackPanel;
import org.apache.wicket.markup.html.form.FormComponent;

import java.io.Serializable;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved. Proprietary and Confidential. User: jf Date: Mar 28,
 * 2008 Time: 3:15:33 PM
 */
public abstract class AbstractComponentPanel extends AbstractChannelsPanel {

    public static final boolean SINGLE_SELECTION = true;

    protected AbstractChannelsPanel parentPanel;
    protected String propPath; // from parent element/component to the component being edited
    private Serializable editedComponent;

    public AbstractComponentPanel( String id, AbstractChannelsPanel parentPanel, String propPath ) {
        super( id );
        this.parentPanel = parentPanel;
        this.propPath = propPath;
        load();
        init();
    }

    @Override
    public FeedbackPanel getFeedback() {
        return parentPanel.getFeedback();
    }

    // Get absolute property path (from element)
    public String getFullPropertyPath() {
        String parentPath = parentPanel.getFullPropertyPath();
        if (parentPath.isEmpty()) {
            return propPath;
        }
        else {
            if (propPath.isEmpty()) {
                return parentPath;
            }
            else if (propPath.startsWith("[") || propPath.startsWith("(")) {
                return parentPath + propPath;
            }
            else {
                return parentPath + "." + propPath;
            }
        }
    }


    // ElementPanel

    public Ref getElement() {
        return parentPanel.getElement();
    }

    public Object getObject() {
        return getComponent();
    }

    public Serializable getComponent() {
        if ( editedComponent == null ) {
            editedComponent = (Serializable) RefUtils.get( getElement(), getFullPropertyPath() );
        }
        return editedComponent;
    }

    public Object getParentObject() {
        return parentPanel.getObject();
    }

    public void elementChanged( String fullPath, AjaxRequestTarget target ) {
        parentPanel.elementChanged( fullPath, target );
    }

    public AbstractElementForm getTopElementPanel() {
        return parentPanel.getTopElementPanel();
    }

    public boolean isReadOnly() {
        return parentPanel.isReadOnly();
    }


    public void edit( Ref ref, AjaxRequestTarget target ) {
        parentPanel.edit( ref, target );
    }

    // end ElementPanel

    protected void load() {
        // do nothing
    }

    protected void addInputField(FormComponent inputField, String propPath) {
        super.addInputField(inputField, getPropertyPath(propPath));  // substitute full property path
    }

    @Override
    public void onDetach() {
        try {
            Object component = getComponent();
            if ( component != null && component instanceof Bean )
                ( (Bean) component ).detach();
        } catch ( RuntimeException e ) {
            Logger.getLogger( getClass() ).error( "Error detaching " + getElement() + "'s " + getFullPropertyPath() );
            throw e;
        }
        super.onDetach();
    }

    protected void setProperty( Object value ) {
        RefUtils.set( getElement(), getFullPropertyPath(), value );
    }

    protected void setProperty(Object value, AjaxRequestTarget target ) {
        setProperty(value );
        elementChanged(  getFullPropertyPath(), target );
    }

    protected void setProperty( String property, Object value ) {
        RefUtils.set( getElement(), getPropertyPath(property), value );
    }

    protected void setProperty( String property, Object value, AjaxRequestTarget target ) {
        setProperty( property, value );
        elementChanged( getPropertyPath(property), target );
    }

    protected Object getProperty() {
        return RefUtils.get( getElement(), getFullPropertyPath() );
    }

    protected Object getProperty( String property ) {
        return RefUtils.get( getElement(), getPropertyPath(property) );
    }

    protected String getPropertyPath(String property) {  // extends full property path with a property
        String propertyPath = getFullPropertyPath();
        return propertyPath.isEmpty() ? property : ( propertyPath + '.' + property);
    }
}
