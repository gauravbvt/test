package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.pages.forms.panels.ReferencePanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.support.models.RefQueryModel;
import com.mindalliance.channels.ifm.scenario.timing.Timing;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.form.CheckBox;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 16, 2008
 * Time: 1:03:23 PM
 */
abstract public class AbstractTimingPanel extends AbstractComponentPanel {

    private AbstractComponentPanel delayPanel;
    private CheckBox startCheckBox;
    private CheckBox endCheckBox;
    private ReferencePanel antecedentPanel;
    private WebMarkupContainer conditionDiv;
    private CheckBox onSuccessOnlyCheckBox;
    private CheckBox onFailureOnlyCheckBox;
    private Timing timing;

    public AbstractTimingPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    abstract protected AbstractComponentPanel makeDelayPanel(String id, AbstractChannelsPanel parentPanel, String propPath);

    protected void load() {
        super.load();
        timing = (Timing) getComponent();
        delayPanel = makeDelayPanel("delay", this, "delay");
        addReplaceable(delayPanel);
        startCheckBox = new CheckBox("start", new Model<Boolean>(timing.isFromStart()));
        startCheckBox.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                boolean val = startCheckBox.getModelObject();
                setProperty("fromStart", val );
                endCheckBox.setModelObject(!val);
                target.addComponent(endCheckBox);
            }
        });
        addReplaceable(startCheckBox);
        endCheckBox = new CheckBox("end", new Model<Boolean>(timing.isFromEnd()));
        endCheckBox.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                boolean val = endCheckBox.getModelObject();
                setProperty("fromStart", !val);
                startCheckBox.setModelObject(!val);
                target.addComponent(startCheckBox);
            }
        });
        addReplaceable(endCheckBox);
        antecedentPanel = new ReferencePanel("antecedent", this, "antecedent",
                new RefQueryModel(getElement(),"findCandidateAntecedents"), "of");
        addReplaceable(antecedentPanel);
        conditionDiv = new WebMarkupContainer("conditionDiv");
        addReplaceable(conditionDiv);
        updateConditionVisibility();
        onSuccessOnlyCheckBox = new CheckBox("onSuccessOnly", new RefPropertyModel<Boolean>(getElement(), getPropertyPath("onSuccessOnly")));
        onSuccessOnlyCheckBox.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                target.addComponent(onFailureOnlyCheckBox);
            }
        });
        /*  {
            protected void onUpdate(AjaxRequestTarget target) {
                setProperty("onSuccessOnly", onSuccessOnlyCheckBox.getModelObject(), target);
                target.addComponent(onFailureOnlyCheckBox);
            }
        };*/
        addReplaceableTo(onSuccessOnlyCheckBox, conditionDiv);
        onFailureOnlyCheckBox = new CheckBox("onFailureOnly", new RefPropertyModel<Boolean>(getElement(), getPropertyPath("onFailureOnly")));
        onFailureOnlyCheckBox.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                target.addComponent(onSuccessOnlyCheckBox);
            }
        });
        /*       {
            protected void onUpdate(AjaxRequestTarget target) {
                setProperty("onFailureOnly", onFailureOnlyCheckBox.getModelObject(), target);
                target.addComponent(onSuccessOnlyCheckBox);
            }
        };*/
        addReplaceableTo(onFailureOnlyCheckBox, conditionDiv);
    }

    private void updateConditionVisibility() {
        setVisibility(conditionDiv, timing.hasConditions());
    }

    @Override
    public void elementChanged(String fullPath, AjaxRequestTarget target) {
        super.elementChanged(fullPath, target);
        if (fullPath.endsWith(".antecedent")) {
            target.addComponent(startCheckBox);
            target.addComponent(endCheckBox);
        }
        if (fullPath.matches(".*\\.fromStart")) {
            updateConditionVisibility();
            target.addComponent(conditionDiv);
        }
    }


}
