package com.mindalliance.channels.pages.forms.panels.domain;

import org.apache.wicket.model.IModel;
import com.mindalliance.channels.ifm.domain.Definition;
import com.mindalliance.channels.ifm.domain.OrganizationDefinition;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.domain.AbstractDefinitionPanel;
import com.mindalliance.channels.pages.forms.panels.domain.AbstractSpecificationPanel;
import com.mindalliance.channels.pages.forms.panels.domain.OrganizationDefinitionPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 30, 2008
 * Time: 7:29:31 PM
 */
public class OrganizationSpecificationPanel extends AbstractSpecificationPanel {

    public OrganizationSpecificationPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected String getMatchingDomainName() {
        return "organization";
     }

    protected IModel getEnumerationChoicesModel() {
        return new RefPropertyModel(getProject(), "organizations");
    }

    protected AbstractDefinitionPanel makeDefinitionEditor(String id, String propPath) {
        return new OrganizationDefinitionPanel(id, this, propPath);
    }

    protected Definition makeNewDefinition() {
        return new OrganizationDefinition();
    }

    protected boolean isEnumerable() {
        return true;
    }
}
