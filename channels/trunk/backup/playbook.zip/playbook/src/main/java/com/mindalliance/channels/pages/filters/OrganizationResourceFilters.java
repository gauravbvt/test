package com.mindalliance.channels.pages.filters;

import com.mindalliance.channels.ifm.resource.organization.InOrganization;
import com.mindalliance.channels.ifm.resource.organization.Organization;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.ref.Referenceable;
import com.mindalliance.channels.support.models.Container;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

/**
 * ...
 */
public class OrganizationResourceFilters extends AbstractFilters {

    public OrganizationResourceFilters() {
    }

    @Override
    void addFilters( Container container, List<Filter> results ) {
        Collection<Organization> orgs = new TreeSet<Organization>(
            new Comparator<Organization>(){
                public int compare( Organization o1, Organization o2 ) {
                    return o1.getName().compareTo( o2.getName() );
                }
            } );
        for ( Ref ref: container ) {
            Referenceable object = ref.deref();
            if ( object != null && object instanceof InOrganization ) {
                InOrganization pe = (InOrganization) object;
                Ref orgRef = pe.getOrganization();
                Organization org = (Organization) orgRef.deref();
                if ( org != null )
                    orgs.add( org );
            }
        }

        if ( orgs.size() > 1 )
            for ( Organization org: orgs ) {
                if ( org.getParent() == null )
                    results.add( new OrganizationFilter( org.getReference() ) );
            }
    }
}
