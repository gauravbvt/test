package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.ifm.TagSet;
import com.mindalliance.channels.ifm.domain.AgentSpecification;
import com.mindalliance.channels.ifm.domain.RelationshipDefinition;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.TagSetPanel;
import com.mindalliance.channels.support.models.RefQueryModel;
import org.apache.wicket.Component;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.Model;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 30, 2008
 * Time: 7:31:19 PM
 */
public class RelationshipDefinitionPanel extends AbstractDefinitionPanel {

    protected RelationshipDefinition relationshipDefinition;
    private AjaxCheckBox anyRelationshipTypeCheckBox;
    private WebMarkupContainer relationshipTypesDiv;
    protected TagSetPanel tagSetPanel;
    protected AjaxCheckBox anyAgentCheckBox;
    protected WebMarkupContainer agentSpecificationDiv;
    protected Component agentSpecificationPanel;

    public RelationshipDefinitionPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        relationshipDefinition = (RelationshipDefinition) getComponent();

        anyRelationshipTypeCheckBox = new AjaxCheckBox("anyRelationshipType", new Model<Boolean>(!relationshipDefinition.getTagSet().isDefined())){
             protected void onUpdate(AjaxRequestTarget target) {
                 boolean anyRelationshipType = anyRelationshipTypeCheckBox.getModelObject();
                 if (anyRelationshipType) {
                     setProperty("tagSet", new TagSet());
                 }
                 setVisibility(relationshipTypesDiv, !anyRelationshipType, target);
             }
         };
         addReplaceable(anyRelationshipTypeCheckBox);
         relationshipTypesDiv = new WebMarkupContainer("relationshipTypesDiv");
         setVisibility(relationshipTypesDiv, relationshipDefinition.getTagSet().isDefined());
         addReplaceable(relationshipTypesDiv);
        tagSetPanel = new TagSetPanel("tagSet", this, "tagSet",
                new RefQueryModel(getProject(), "findAllRelationshipTags"));
        addReplaceableTo(tagSetPanel, relationshipTypesDiv);

        anyAgentCheckBox = new AjaxCheckBox("anyAgent", new Model<Boolean>(relationshipDefinition.getWithAgentSpec().matchesAll())) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyAgent = anyAgentCheckBox.getModelObject();
                if (anyAgent) {
                    setProperty("withAgentSpec", new AgentSpecification());
                    agentSpecificationPanel = new AgentSpecificationPanel("agentSpec", RelationshipDefinitionPanel.this, "withAgentSpec");
                    addReplaceableTo(agentSpecificationPanel, agentSpecificationDiv);
                }
                setVisibility(agentSpecificationDiv, !anyAgent, target);
            }
        };
        addReplaceable(anyAgentCheckBox);
        agentSpecificationDiv = new WebMarkupContainer("agentSpecDiv");
        setVisibility(agentSpecificationDiv, !relationshipDefinition.getWithAgentSpec().matchesAll());
        addReplaceable(agentSpecificationDiv);
        agentSpecificationPanel = new AgentSpecificationPanel("agentSpec", this, "withAgentSpec");
        addReplaceableTo(agentSpecificationPanel, agentSpecificationDiv);
    }
}
