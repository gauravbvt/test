package com.mindalliance.channels.pages.forms.panels.resource;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.support.components.AutoCompleteTextFieldWithChoices;
import com.mindalliance.channels.support.models.RefQueryModel;
import com.mindalliance.channels.support.Level;
import com.mindalliance.channels.ifm.resource.Capability;
import com.mindalliance.channels.ifm.scenario.action.performance.Performance;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.model.Model;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import java.io.Serializable;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 12:53:18 PM
 */
public class CapabilityPanel extends AbstractComponentPanel {

    private DropDownChoice<Level> levelChoice;
    private AutoCompleteTextFieldWithChoices capabilityTagField;

    public CapabilityPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        Capability capability = (Capability)getComponent();
        levelChoice = new DropDownChoice("level", new Model<String>(capability.getLevel().toString()), new Model((Serializable)Level.valueStrings()));
        levelChoice.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                String levelString = (String)levelChoice.getDefaultModelObject();
                setProperty("level", Level.fromString(levelString), target);
            }
        });
        addReplaceable(levelChoice);
        capabilityTagField = new AutoCompleteTextFieldWithChoices("tag", new Model<String>(capability.getTag()),
                                                                   new RefQueryModel(getProject(), "findCapabilityTags"));
        capabilityTagField.add(
                new AjaxFormComponentUpdatingBehavior( "onchange" ) {
                    @Override
                    protected void onUpdate(
                            AjaxRequestTarget target ) {
                        String tag = capabilityTagField.getDefaultModelObjectAsString();
                        setProperty("tag", tag, target);
                    }
                } );
        addReplaceable(capabilityTagField);
    }
}
