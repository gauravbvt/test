package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.ifm.domain.EventDefinition;
import com.mindalliance.channels.ifm.domain.LocationDefinition;
import com.mindalliance.channels.ifm.domain.EventSpecification;
import com.mindalliance.channels.ifm.TagSet;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.TagSetPanel;
import com.mindalliance.channels.support.models.RefQueryModel;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.Model;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jul 1, 2008
 * Time: 10:10:59 AM
 */
public class EventDefinitionPanel extends AbstractDefinitionPanel {

    private AjaxCheckBox anyTagCheckBox;
    private WebMarkupContainer tagSetDiv;
    private TagSetPanel tagSetPanel;
    private AjaxCheckBox anyLocationCheckBox;
    private WebMarkupContainer locationDefinitionDiv;
    private LocationDefinitionPanel locationDefinitionPanel;
    private AjaxCheckBox anyPriorCheckBox;
    private WebMarkupContainer priorSpecificationDiv;
    private EventSpecificationPanel priorSpecificationPanel;

    public EventDefinitionPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    @Override
    protected void load() {
        super.load();
        EventDefinition eventDefinition = (EventDefinition)getComponent();

        anyTagCheckBox = new AjaxCheckBox("anyTag", new Model<Boolean>(
                !eventDefinition.getTagSet().isDefined() )){
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyTag = anyTagCheckBox.getModelObject();
                if (anyTag) {
                    setProperty("tagSet", new TagSet());
                    tagSetPanel = new TagSetPanel("tagSet", EventDefinitionPanel.this, "tagSet",
                                                 new RefQueryModel(getProject(), "findAllEventTags"));
                    addReplaceableTo(tagSetPanel, tagSetDiv);
                }
                setVisibility(tagSetDiv, !anyTag, target);
            }
        };
        addReplaceable(anyTagCheckBox);
        tagSetDiv = new WebMarkupContainer("tagSetDiv");
        setVisibility(tagSetDiv, eventDefinition.getTagSet().isDefined());
        addReplaceable(tagSetDiv);
        tagSetPanel = new TagSetPanel("tagSet", this, "tagSet", new RefQueryModel(getProject(), "findAllEventTags"));
        addReplaceableTo(tagSetPanel, tagSetDiv);

        anyLocationCheckBox = new AjaxCheckBox("anyLocation", new Model<Boolean>(
                eventDefinition.getLocationSpec().matchesAll() )){
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyLocation = anyLocationCheckBox.getModelObject();
                if (anyLocation) {
                    setProperty("locationDefinition", new LocationDefinition());
                    locationDefinitionPanel = new LocationDefinitionPanel("locationDefinition", EventDefinitionPanel.this, "locationDefinition");
                    addReplaceableTo(locationDefinitionPanel, locationDefinitionDiv);
                }
                setVisibility(locationDefinitionDiv, !anyLocation, target);
            }
        };
        addReplaceable(anyLocationCheckBox);
        locationDefinitionDiv = new WebMarkupContainer("locationDefinitionDiv");
        setVisibility(locationDefinitionDiv, !eventDefinition.getLocationSpec().matchesAll());
        addReplaceable(locationDefinitionDiv);
        locationDefinitionPanel = new LocationDefinitionPanel("locationDefinition", this, "locationDefinition");
        addReplaceableTo(locationDefinitionPanel, locationDefinitionDiv);

        anyPriorCheckBox = new AjaxCheckBox("anyPrior", new Model<Boolean>(
                eventDefinition.getPriorEventSpec().matchesAll() )){
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                boolean anyPrior = anyPriorCheckBox.getModelObject();
                if (anyPrior) {
                    setProperty("priorEventSpec", new EventSpecification());
                    priorSpecificationPanel = new EventSpecificationPanel("priorSpecification", EventDefinitionPanel.this, "priorEventSpec");
                    addReplaceableTo(priorSpecificationPanel, priorSpecificationDiv);
                }
                setVisibility(priorSpecificationDiv, !anyPrior, target);
            }
        };
        addReplaceable(anyPriorCheckBox);
        priorSpecificationDiv = new WebMarkupContainer("priorSpecificationDiv");
        setVisibility(priorSpecificationDiv, !eventDefinition.getPriorEventSpec().matchesAll());
        addReplaceable(priorSpecificationDiv);
        priorSpecificationPanel = new EventSpecificationPanel("priorSpecification", this, "priorEventSpec");
        addReplaceableTo(priorSpecificationPanel, priorSpecificationDiv);
    }

}
