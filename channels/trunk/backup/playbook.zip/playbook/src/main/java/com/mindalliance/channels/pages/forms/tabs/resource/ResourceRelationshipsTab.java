package com.mindalliance.channels.pages.forms.tabs.resource;

import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.RefListPanel;
import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.query.Query;
import com.mindalliance.channels.support.models.RefQueryModel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 13, 2008
 * Time: 12:45:14 PM
 */
public class ResourceRelationshipsTab extends AbstractFormTab {

    private RefListPanel relationshipsPanel;

    public ResourceRelationshipsTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        relationshipsPanel = new RefListPanel("relationships", this, new RefQueryModel(getProject(), new Query("findAllRelationshipsOf", getElement())));
        add(relationshipsPanel);
    }
 }
