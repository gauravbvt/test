package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.ifm.TagSet;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.form.ListChoice;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.Component;
import java.util.List;
import java.util.ArrayList;
import java.io.Serializable;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 28, 2008
 * Time: 12:58:44 PM
 */
public class TagSetsPanel extends AbstractListPanel {

    private IModel choices;

    public TagSetsPanel(String id, AbstractChannelsPanel parentPanel, String propPath, IModel choices) {
        super(id, parentPanel, propPath);
        this.choices = choices;
        doLoad();
    }

    protected TagSet makeNewItem() {
        return new TagSet();
    }

    protected Component makeItemPanel(String id, AbstractListPanel parentPanel, String propPath) {
        return new TagSetPanel(id, this, propPath, choices);
    }

    protected String getItemLegend() {
        return "(tags)";
    }

}
