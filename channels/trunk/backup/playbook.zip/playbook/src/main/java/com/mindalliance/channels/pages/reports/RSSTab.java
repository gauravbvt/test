package com.mindalliance.channels.pages.reports;

import org.apache.wicket.markup.html.WebPage;

/**
 * ...
 */

public class RSSTab extends WebPage {

}
