package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.ifm.domain.Definition;
import com.mindalliance.channels.ifm.domain.Specification;
import com.mindalliance.channels.pages.filters.DynamicFilterTree;
import com.mindalliance.channels.pages.filters.Filter;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.domain.AbstractDefinitionPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.util.RefUtils;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.Component;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.markup.html.form.ListChoice;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 23, 2008
 * Time: 8:31:05 PM
 */
public abstract class AbstractSpecificationPanel extends AbstractComponentPanel {

    protected static int MAX_SUMMARY_LENGTH = 16;
    protected static int MAX_CHOICE_ROWS = 3;

    protected TextArea<String> descriptionField;
    protected AjaxCheckBox affirmedCheckBox;
    protected AjaxCheckBox negatedCheckBox;
    protected AjaxCheckBox specifiedCheckBox;
    protected Label matchingDomainClassLabel;
    protected WebMarkupContainer specifiedDiv;
    protected WebMarkupContainer enumerationDiv;
    protected DynamicFilterTree enumerationTree;
    protected ListChoice<Definition> definitionsList;
    protected Definition selectedDefinition;
    protected Button addDefinitionButton;
    protected Button deleteDefinitionButton;
    protected WebMarkupContainer definitionDiv;
    Component definitionPanel;
    protected List<Ref> priorEnumeration;
    protected List<Definition> priorDefinitions;

    public AbstractSpecificationPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        final Specification specification = (Specification)getComponent();
        descriptionField = new TextArea<String>("description", new RefPropertyModel<String>(getElement(), getPropertyPath("description")));
        descriptionField.add(new AjaxFormComponentUpdatingBehavior("onchange") {

            @Override
                protected void onUpdate(AjaxRequestTarget target) {
                    elementChanged(getPropertyPath("description"), target);
                }
        });
        addReplaceable(descriptionField);
        affirmedCheckBox= new AjaxCheckBox("affirmed", new Model<Boolean>(!specification.isNegated())) {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                boolean affirmed = affirmedCheckBox.getModelObject();
                setProperty("negated", !affirmed, target);
                negatedCheckBox.setModelObject(!affirmed);
                target.addComponent(negatedCheckBox);
            }
        };
        addReplaceable(affirmedCheckBox);
        negatedCheckBox= new AjaxCheckBox("negated", new Model<Boolean>(specification.isNegated())) {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                boolean negated = negatedCheckBox.getModelObject();
                setProperty("negated", negated, target);
                affirmedCheckBox.setModelObject(!negated);
                target.addComponent(affirmedCheckBox);
            }
        };
        addReplaceable(negatedCheckBox);
        matchingDomainClassLabel = new Label("matchingDomainClass", getMatchingDomainName());
        addReplaceable(matchingDomainClassLabel);
        specifiedCheckBox = new AjaxCheckBox("specified", new Model<Boolean>(specification.isDefined())) {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                boolean specified = specifiedCheckBox.getModelObject();    // selected means does NOT match all
                if (specified) {
                    // reset enumeration and definitions
                    if (priorEnumeration != null) {
                        setProperty("enumeration", priorEnumeration, target);
                        enumerationTree.modelChanged();
                        target.addComponent(enumerationTree);
                    }
                    if (priorDefinitions != null) {
                        setProperty("definitions", priorDefinitions, target);
                        definitionsList.setModel(new Model<Definition>());
                        target.addComponent(definitionsList);
                    }
                }
                else {
                    priorEnumeration = specification.getEnumeration();
                    setProperty("enumeration", new ArrayList<Ref>(), target);
                    priorDefinitions = specification.getDefinitions();
                    setProperty("definitions", new ArrayList<Definition>(), target);
                }
                setVisibility(specifiedDiv, specifiedCheckBox.getModelObject(), target);
            }
        };
        addReplaceable(specifiedCheckBox);
        specifiedDiv = new WebMarkupContainer("specifiedDiv");
        addReplaceable(specifiedDiv);
        enumerationDiv = new WebMarkupContainer("enumerationDiv");
        setVisibility(enumerationDiv, isEnumerable());
        addReplaceableTo(enumerationDiv, specifiedDiv);
        enumerationTree = new DynamicFilterTree("enumeration", new RefPropertyModel(getComponent(), "enumeration"), getEnumerationChoicesModel()) {

            @Override
            public void onFilterSelect(AjaxRequestTarget target, Filter filter) {
                List<Ref> selections = enumerationTree.getNewSelections();
                setProperty("enumeration", selections, target);
            }
        };
        addReplaceableTo(enumerationTree, enumerationDiv);
        definitionsList = new ListChoice<Definition>("definitions", new Model<Definition>(selectedDefinition),
                                         new RefPropertyModel(getComponent(), "definitions"),
                                         new ChoiceRenderer<Definition>("summary"));
        definitionsList.setMaxRows(MAX_CHOICE_ROWS);
        definitionsList.add(new AjaxFormComponentUpdatingBehavior("onchange") {

            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                selectedDefinition = definitionsList.getModelObject();
                updateDefinitionPanel(target);
                enable(deleteDefinitionButton, selectedDefinition != null, target);
            }
        });
        addReplaceableTo(definitionsList, specifiedDiv);
        addDefinitionButton = new Button("addDefinition");
        addDefinitionButton.add(new AjaxEventBehavior("onclick"){

            @Override
            protected void onEvent(AjaxRequestTarget target) {
                selectedDefinition = makeNewDefinition();
                definitionsList.setModelObject(selectedDefinition);
                RefUtils.add(getElement(), getPropertyPath("definitions"), selectedDefinition);
                enable(deleteDefinitionButton, true, target);
                updateDefinitionPanel(target);
                target.addComponent(definitionsList);
            }
        });
        addReplaceableTo(addDefinitionButton, specifiedDiv);
        deleteDefinitionButton = new Button("deleteDefinition");
        deleteDefinitionButton.add(new AjaxEventBehavior("onclick"){

            @Override
            protected void onEvent(AjaxRequestTarget target) {
                RefUtils.remove(getElement(),getPropertyPath("definitions"), selectedDefinition);
                selectedDefinition = null;
                enable(deleteDefinitionButton, false, target);
                updateDefinitionPanel(target);
                target.addComponent(definitionsList);
            }
        });
        deleteDefinitionButton.setEnabled(false);
        addReplaceableTo(deleteDefinitionButton, specifiedDiv);
        definitionDiv = new WebMarkupContainer("definitionDiv");
        addReplaceableTo(definitionDiv, specifiedDiv);
        definitionPanel = new Label("definition", "");
        setVisibility(definitionDiv, selectedDefinition != null);
        addReplaceableTo(definitionPanel, definitionDiv);
        setVisibility(specifiedDiv, specifiedCheckBox.getModelObject());
    }

    private void updateDefinitionPanel(AjaxRequestTarget target) {
        Specification specification = (Specification)getComponent();
        definitionDiv.remove(definitionPanel);
        if (selectedDefinition != null) {
            int index = specification.getDefinitions().indexOf(selectedDefinition);
            definitionPanel = makeDefinitionEditor("definition", "definitions["+index+"]");
        }
        else {
            definitionPanel = new Label("definition", new Model<String>(""));
        }
        addReplaceableTo(definitionPanel, definitionDiv);
        setVisibility(definitionDiv, selectedDefinition != null, target);
    }


    @Override
    public void elementChanged(String fullPath, AjaxRequestTarget target) {
        super.elementChanged(fullPath, target);
        if (fullPath.matches(".*\\.definitions\\[\\d+\\]\\.description")) {
            target.addComponent(definitionsList);
        }
    }

    protected abstract String getMatchingDomainName();

    protected abstract IModel<?> getEnumerationChoicesModel();

    protected abstract AbstractDefinitionPanel makeDefinitionEditor(String id, String propPath);

    protected abstract Definition makeNewDefinition();

    protected abstract boolean isEnumerable();
}
