package com.mindalliance.channels.pages.forms.panels.location;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.location.AreaInfoPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.pages.forms.panels.location.LatLongPanel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 22, 2008
 * Time: 12:51:07 PM
 */
public class GeoLocationPanel extends AbstractComponentPanel {

    private static final long serialVersionUID = 3434516113648748749L;

    public GeoLocationPanel(
            String id, AbstractChannelsPanel parentPanel, String propPath ) {
        super( id, parentPanel, propPath );
    }

    @Override
    protected void load() {
        super.load();
        addReplaceable(
                new AreaInfoPanel("areaInfo", this, "areaInfo" ) );
        addReplaceable(
                new LatLongPanel("latLong", this, "latLong" ) );
    }
}
