package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.markup.html.form.TextArea;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved. Proprietary
 * and Confidential.
 * <p/>
 * User: jf Date: Jul 1, 2008 Time: 12:47:36 PM
 */
public abstract class AbstractDefinitionPanel extends AbstractComponentPanel {

    protected static final int MAX_CHOICE_ROWS = 3;

    protected AbstractDefinitionPanel(
            String id, AbstractChannelsPanel parentPanel, String propPath ) {
        super( id, parentPanel, propPath );
    }

    @Override
    protected void load() {
        super.load();
        TextArea descriptionField = new TextArea<String>("description",
                                                         new RefPropertyModel<String>(getElement(), getPropertyPath("description") ) );
        addInputField(descriptionField);
    }
}
