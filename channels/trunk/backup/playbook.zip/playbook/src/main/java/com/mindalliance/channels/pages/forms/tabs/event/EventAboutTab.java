package com.mindalliance.channels.pages.forms.tabs.event;

import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.TimespanPanel;
import com.mindalliance.channels.pages.forms.panels.scenario.EventTimingPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.support.models.RefQueryModel;
import com.mindalliance.channels.support.components.AutoCompleteTextFieldWithChoices;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 16, 2008
 * Time: 11:41:04 AM
 */
public class EventAboutTab extends AbstractFormTab {

    public EventAboutTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        TextField nameField = new TextField<String>("name", new RefPropertyModel<String>(getElement(), "name"));
        addInputField(nameField);
        TextArea descriptionField = new TextArea<String>("description", new RefPropertyModel<String>(getElement(), "description"));
        addInputField(descriptionField);
        AutoCompleteTextFieldWithChoices tagField = new AutoCompleteTextFieldWithChoices("tag", new RefPropertyModel<String>(getElement(), "tag"), new RefQueryModel(getProject(), "findAllEventTags"));
        addInputField(tagField);
        /*tagField.add(new AjaxFormComponentUpdatingBehavior("onchange") {
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                // do nothing
            }
        });*/
        addReplaceable(tagField);
        EventTimingPanel timingPanel = new EventTimingPanel("timing", this, "timing");
        addReplaceable(timingPanel);
        TimespanPanel durationPanel = new TimespanPanel("duration", this, "defaultDuration");
        addReplaceable(durationPanel);
    }
}
