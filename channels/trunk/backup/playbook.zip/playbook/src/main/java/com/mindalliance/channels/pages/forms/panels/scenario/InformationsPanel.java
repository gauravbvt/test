package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.pages.forms.panels.AbstractListPanel;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.ifm.information.Information;
import org.apache.wicket.Component;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 27, 2008
 * Time: 4:29:37 PM
 */
public class InformationsPanel extends AbstractListPanel {

    public InformationsPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
        doLoad();
    }

    public InformationsPanel(String id, AbstractChannelsPanel parentPanel, String propPath, int maxRows, int summarySize) {
        super(id, parentPanel, propPath, maxRows, summarySize);
        doLoad();
    }

    protected Information makeNewItem() {
        return new Information();
    }

    protected Component makeItemPanel(String id, AbstractListPanel parentPanel, String propPath) {
        return new InformationPanel(id, parentPanel, propPath);
    }

    protected String getItemLegend() {
        return "(information)";
    }

}
