package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.validation.validator.NumberValidator;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 4:45:16 PM
 */
public class ProbabilityPanel extends AbstractComponentPanel {

    public ProbabilityPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        TextField<Integer> probabilityField = new TextField<Integer>("probability", new RefPropertyModel<Integer>(getComponent(), "value"));
        probabilityField.setType( Integer.class );
        probabilityField.add( NumberValidator.minimum( 0 ) );
        probabilityField.add( NumberValidator.maximum( 100 ) );
        addInputField( probabilityField, "value" );  // by giving path, will raise change "event"
    }

}
