package com.mindalliance.channels.pages.filters;

import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.ref.Referenceable;
import com.mindalliance.channels.util.Mapper;
import com.mindalliance.channels.ifm.scenario.Scenario;
import com.mindalliance.channels.ifm.scenario.InScenario;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * ...
 */
public class ChannelsFilter extends Filter {

    private Ref scenario;

    public ChannelsFilter() {} // for persistency only

    public ChannelsFilter(Ref ref) {
        super("... in scenario " + getScenario(ref));
        setInclusion( true );
        this.scenario = ref;
    }

    static Scenario getScenario(Ref scenarioRef) {
        Scenario result = (Scenario) scenarioRef.deref();
        scenarioRef.detach();
        return result;
    }

    protected List<Filter> createChildren( boolean selectionState ) {
        return Collections.emptyList();
    }

    public boolean isMatching(Ref ref) {
        Referenceable object = ref.deref();
        if (object instanceof InScenario) {
            InScenario se = (InScenario) object;
            return scenario.equals(se.getScenario());
        }
        return false;
    }

    protected boolean allowsClassLocally(Class<?> c) {
        return InScenario.class.isAssignableFrom(c);
    }

    public Ref getScenario() {
        return scenario;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> map = super.toMap();
        map.put("scenario", (Object) Mapper.toPersistedValue( scenario ));
        return map;
    }

    public void initFromMap(Map<String,Object> map) {
        scenario = (Ref)Mapper.valueFromPersisted( map.get( "scenario" ));
        super.initFromMap(map);
    }
}
