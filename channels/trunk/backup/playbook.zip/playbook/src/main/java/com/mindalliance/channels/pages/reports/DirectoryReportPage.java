package com.mindalliance.channels.pages.reports;

import com.mindalliance.channels.ifm.Tab;
import com.mindalliance.channels.report.ResourceDirectory;
import com.mindalliance.channels.report.Report;
import org.apache.wicket.PageParameters;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jul 17, 2008
 * Time: 7:26:10 AM
 */
public class DirectoryReportPage extends ReportPage {

    public DirectoryReportPage(PageParameters parms) {
        super(parms);
    }

    Report makeReport(Tab tab) {
        return new ResourceDirectory(tab);
    }

}
