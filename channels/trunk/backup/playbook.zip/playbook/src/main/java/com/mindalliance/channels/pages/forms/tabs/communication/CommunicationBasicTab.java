package com.mindalliance.channels.pages.forms.tabs.communication;

import com.mindalliance.channels.pages.filters.DynamicFilterTree;
import com.mindalliance.channels.pages.filters.Filter;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.tabs.action.ActionAboutTab;
import com.mindalliance.channels.query.Query;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.support.models.RefQueryModel;
import org.apache.wicket.ajax.AjaxRequestTarget;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 9, 2008
 * Time: 8:40:30 PM
 */
public class CommunicationBasicTab extends ActionAboutTab {

    private DynamicFilterTree targetAgentTree;

    public CommunicationBasicTab( String id, AbstractElementForm elementForm ) {
        super( id, elementForm );
    }

    @Override
    protected void load() {
        super.load();
        targetAgentTree = new DynamicFilterTree(
                "targetAgent",
                new RefPropertyModel( getElement(), "targetAgent" ),
                new RefQueryModel(
                        getScenario(), new Query(
                        "findAllAgentablesExcept", getElement(), "actor" ) ),
                SINGLE_SELECTION ) {

            @Override
            public void onFilterSelect(
                    AjaxRequestTarget target, Filter filter ) {
                setProperty( "targetAgent", targetAgentTree.getNewSelection() );
            }
        };
        addReplaceable( targetAgentTree );
    }
}
