package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.filters.DynamicFilterTree;
import com.mindalliance.channels.pages.filters.Filter;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.util.RefUtils;

import java.util.List;
import java.io.Serializable;

import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.ListChoice;
import org.apache.wicket.markup.html.form.ChoiceRenderer;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Aug 20, 2008
 * Time: 2:32:25 PM
 */
// List of references (with edit action)
public class RefListPanel extends AbstractComponentPanel {

    private static final int MAX_SIZE = 30;
    private static final int MAX_ROWS = 4;

    private IModel references;
    // private ListChoice<Ref> referencesList;
    private DynamicFilterTree referencesTree;
    private Ref selection;
    private Button editButton;
    private int maxRows = 0;
    private int maxSize = 0;


    public RefListPanel(String id, AbstractChannelsPanel parentPanel, IModel<List<Ref>> references, int maxRows, int maxSize) {
        this(id, parentPanel, references);
        this.maxRows = maxRows;
        this.maxSize = maxSize;
    }

    public RefListPanel(String id, AbstractChannelsPanel parentPanel, IModel<List<Ref>> references) {
        super(id, parentPanel, "");
        this.references = references;
        doLoad();
    }

    private void doLoad() {
        /*referencesList = new ListChoice<Ref>("references",
                new Model<Ref>(),
                new Model((Serializable)RefUtils.sort((List<Ref>)references.getObject())),
                new ChoiceRenderer<Ref>() {
                    @Override
                    public String getDisplayValue(Ref reference) {
                        return RefUtils.summarize(reference.deref().about(), getMaxSize());
                    }
                }
        );
        referencesList.setMaxRows(getMaxRows());
        referencesList.add(
                new AjaxFormComponentUpdatingBehavior("onchange") {
                    @Override
                    protected void onUpdate(AjaxRequestTarget target) {
                        selection = (Ref) referencesList.getDefaultModelObject();
                        updateEditButton();
                        target.addComponent(editButton);
                    }
                });
        addReplaceable(referencesList);*/
        referencesTree = new DynamicFilterTree("references", new Model<Ref>(), references, SINGLE_SELECTION) {
            @Override
            public void onFilterSelect(AjaxRequestTarget target, Filter filter ) {
                selection = referencesTree.getNewSelection();
                updateEditButton();
                target.addComponent(editButton);
            }
        };
        addReplaceable(referencesTree);
        editButton = new Button("edit");
        editButton.add(
                new AjaxEventBehavior("onclick") {
                    @Override
                    protected void onEvent(AjaxRequestTarget target) {
                        if (selection != null) {
                            parentPanel.edit(selection, target);
                        }
                    }
                });
        updateEditButton();
        addReplaceable(editButton);
    }

    private int getMaxRows() {
        if (maxRows == 0) return MAX_ROWS;
        else return maxRows;
    }

    private int getMaxSize() {
        if (maxSize == 0) return MAX_SIZE;
        else return maxSize;
    }

    private void updateEditButton() {
        setVisibility(editButton, selection != null);
    }


}
