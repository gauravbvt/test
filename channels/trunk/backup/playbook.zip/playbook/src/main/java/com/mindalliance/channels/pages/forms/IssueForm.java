package com.mindalliance.channels.pages.forms;

import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.pages.forms.tabs.issue.IssueBasicTab;
import org.apache.wicket.extensions.markup.html.tabs.AbstractTab;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.panel.Panel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jul 16, 2008
 * Time: 2:56:08 PM
 */
public class IssueForm extends AbstractElementForm {

    public IssueForm(String id, Ref element) {
        super(id, element);
    }

    void loadTabs() {
        tabs.add(new AbstractTab(new Model<String>("Basic")) {
             public Panel getPanel(String panelId) {
                 return new IssueBasicTab(panelId, IssueForm.this);
             }
         });
    }
}
