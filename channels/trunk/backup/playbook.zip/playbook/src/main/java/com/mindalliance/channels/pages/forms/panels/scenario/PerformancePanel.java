package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.scenario.PerformanceLevelsPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.pages.forms.panels.TimespanPanel;
import com.mindalliance.channels.pages.forms.panels.ProbabilityPanel;
import com.mindalliance.channels.pages.forms.panels.CostPanel;
import com.mindalliance.channels.ifm.scenario.action.performance.Performance;
import com.mindalliance.channels.ifm.scenario.action.performance.PerformanceLevel;
import com.mindalliance.channels.ifm.Timespan;
import com.mindalliance.channels.ifm.Probability;
import com.mindalliance.channels.ifm.Cost;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.Model;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.ajax.AjaxRequestTarget;

import java.util.ArrayList;

import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 3:46:12 PM
 */
public class PerformancePanel extends AbstractComponentPanel {

    private Label atLeastOrMostLabel;
    private boolean actorIsGroup;
    private Label valueTypeLabel;
    private AbstractComponentPanel defaultValuePanel;
    private AjaxCheckBox subjectToCapabilitiesCheckBox;
    private WebMarkupContainer performanceLevelsDiv;
    private PerformanceLevelsPanel performanceLevelsPanel;
    private WebMarkupContainer anyOrAllDiv;
    private AjaxCheckBox anyCheckBox;
    private AjaxCheckBox allCheckBox;

    public PerformancePanel(String id, AbstractChannelsPanel parentPanel, String propPath, boolean actorIsGroup) {
        super(id, parentPanel, propPath);
        this.actorIsGroup = actorIsGroup;
        doLoad();
    }

    protected void doLoad() {
        final Performance performance = (Performance)getComponent();
        String valueType = RefUtils.decapitalize(RefUtils.pathEnd(getComparableClass().getName()));
        String atLeastOrMost = performance.isMinimized() ? "at most" : "at least";
        atLeastOrMostLabel = new Label("atLeastOrMost", new Model<String>(atLeastOrMost));
        addReplaceable(atLeastOrMostLabel);
        defaultValuePanel = makeComparablePanel();
        addReplaceable(defaultValuePanel);
        subjectToCapabilitiesCheckBox = new AjaxCheckBox("subjectToCapabilities", new Model(hasPerformanceLevels())) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean isSubjectToCapabilities = subjectToCapabilitiesCheckBox.getModelObject();
                if (!isSubjectToCapabilities) {
                    setProperty("performanceLevels", new ArrayList<PerformanceLevel>(), target);
                    performanceLevelsPanel = new PerformanceLevelsPanel("performanceLevels", PerformancePanel.this, "performanceLevels", performance);
                    addReplaceableTo(performanceLevelsPanel, performanceLevelsDiv);
                    target.addComponent(performanceLevelsPanel);
                }
                setVisibility(performanceLevelsDiv, isSubjectToCapabilities, target);
            }
        };
        addReplaceable(subjectToCapabilitiesCheckBox);
        performanceLevelsDiv = new WebMarkupContainer("performanceLevelsDiv");
        addReplaceable(performanceLevelsDiv);
        setVisibility(performanceLevelsDiv, subjectToCapabilitiesCheckBox.getModelObject());
        valueTypeLabel = new Label("valueType", new Model<String>(valueType));
        addReplaceableTo(valueTypeLabel, performanceLevelsDiv);
        performanceLevelsPanel = new PerformanceLevelsPanel("performanceLevels", this, "performanceLevels", performance);
        addReplaceableTo(performanceLevelsPanel, performanceLevelsDiv);
        anyOrAllDiv = new WebMarkupContainer("anyOrAllDiv");
        addReplaceableTo(anyOrAllDiv,performanceLevelsDiv);
        setVisibility(anyOrAllDiv, actorIsGroup);
        anyCheckBox = new AjaxCheckBox("any", new Model<Boolean>(!((Boolean)getProperty("allCapable")))) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean isAny = anyCheckBox.getModelObject();
                setProperty("allCapable", !isAny);
                allCheckBox.setModelObject(!isAny);
                target.addComponent(allCheckBox);
            }
        };
        addReplaceableTo(anyCheckBox, anyOrAllDiv);
        allCheckBox = new AjaxCheckBox("all", new Model<Boolean>(((Boolean)getProperty("allCapable")))) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean isAll = allCheckBox.getModelObject();
                setProperty("allCapable", isAll);
                anyCheckBox.setModelObject(!isAll);
                target.addComponent(anyCheckBox);
            }
        };
        addReplaceableTo(allCheckBox, anyOrAllDiv);
    }

    private Boolean hasPerformanceLevels() {
        return !((List<PerformanceLevel>)getProperty("performanceLevels")).isEmpty();
    }

    public Class getComparableClass() {
        Performance performance = (Performance)getProperty();
        return performance.getDefaultValue().getClass();
    }

    private AbstractComponentPanel makeComparablePanel() {
        Class comparableClass = getComparableClass();
        if (Timespan.class.isAssignableFrom(comparableClass)) {
            return new TimespanPanel("defaultValue", this, "defaultValue");
        }
        else if (Probability.class.isAssignableFrom(comparableClass)) {
            return new ProbabilityPanel("defaultValue", this, "defaultValue");
        }
        else if (Cost.class.isAssignableFrom(comparableClass)) {
            return new CostPanel("defaultValue", this, "defaultValue");
        }
        else {
            throw new RuntimeException("Not a comparable");
        }
    }

}
