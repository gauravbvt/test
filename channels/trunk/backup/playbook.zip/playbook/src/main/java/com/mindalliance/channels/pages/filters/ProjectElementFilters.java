package com.mindalliance.channels.pages.filters;

import com.mindalliance.channels.ifm.project.Project;
import com.mindalliance.channels.ifm.ContainedElement;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.support.models.Container;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

/** ... */
public class ProjectElementFilters extends AbstractFilters {

    public ProjectElementFilters() {
    }

    @Override
    public void addFilters( Container container, List<Filter> results ) {
        addProjectElementFilters( container, results );
    }

    private static void addProjectElementFilters(
            Iterable<Ref> container, Collection<Filter> results ) {
        Collection<Ref> projectRefs = new TreeSet<Ref>(
                new Comparator<Ref>() {
                    public int compare( Ref o1, Ref o2 ) {
                        Project p1 = (Project) o1.deref();
                        Project p2 = (Project) o2.deref();
                        return p1.getName().compareTo( p2.getName() );
                    }
                } );
        for ( Ref ref : container ) {
            Object object = ref.deref();
            if ( object instanceof ContainedElement) {
                ContainedElement child = (ContainedElement) object;
                Ref project = child.getProject();
                if (project != null) projectRefs.add( project );
            }
        }

        if ( projectRefs.size() > 1 )
            for ( Ref ref : projectRefs )
                results.add( new ProjectFilter( ref ) );
    }
}
