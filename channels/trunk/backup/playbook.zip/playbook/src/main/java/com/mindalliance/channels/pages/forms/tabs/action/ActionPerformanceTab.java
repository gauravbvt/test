package com.mindalliance.channels.pages.forms.tabs.action;

import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.panels.scenario.PerformancePanel;
import com.mindalliance.channels.ifm.scenario.action.Action;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 17, 2008
 * Time: 8:40:19 PM
 */
public class ActionPerformanceTab extends AbstractFormTab {

    public ActionPerformanceTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        Action act = (Action)getElement().deref();
        PerformancePanel durationPanel = new PerformancePanel("duration", this, "duration", act.actorIsGroup());
        addReplaceable(durationPanel);
        PerformancePanel costPanel = new PerformancePanel("cost", this, "cost", act.actorIsGroup());
        addReplaceable(costPanel);
        PerformancePanel successPanel = new PerformancePanel("success", this, "probabilityOfSuccess", act.actorIsGroup());
        addReplaceable(successPanel);
    }
}
