package com.mindalliance.channels.pages.forms.panels.resource;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.pages.forms.panels.resource.CapabilityPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.ifm.resource.Capability;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.markup.html.form.ListChoice;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.ajax.form.AjaxFormComponentUpdatingBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.model.Model;
import org.apache.wicket.Component;

import java.util.List;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 12:37:59 PM
 */
public class CapabilitiesPanel extends AbstractComponentPanel {

    private ListChoice<Capability> capabilitiesChoice;
    private Button addCapabilityButton;
    private Button removeCapabilityButton;
    private WebMarkupContainer capabilityDiv;
    private Component capabilityPanel;
    private Capability selectedCapability;

    public CapabilitiesPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        selectedCapability = getDefaultSelectedCapability();
        capabilitiesChoice = new ListChoice<Capability>("capabilities", new Model<Capability>(selectedCapability),
                                                         new RefPropertyModel(getElement(), getFullPropertyPath()));
        capabilitiesChoice.setMaxRows(3);
        capabilitiesChoice.add(
                new AjaxFormComponentUpdatingBehavior("onchange") {
                    @Override
                    protected void onUpdate(AjaxRequestTarget target) {
                        selectedCapability = capabilitiesChoice.getModelObject();
                        updateCapabilitySelected(target);
                    }
                });
        addReplaceable(capabilitiesChoice);
        addCapabilityButton = new Button("addCapability");
        addCapabilityButton.add(new AjaxEventBehavior("onclick") {
            @Override
            protected void onEvent(AjaxRequestTarget target) {
                selectedCapability = new Capability();
                RefUtils.add(getElement(), getFullPropertyPath(), selectedCapability);
                capabilitiesChoice.setModelObject(selectedCapability);
                target.addComponent(capabilitiesChoice);
                updateCapabilitySelected(target);
            }
        });
        addReplaceable(addCapabilityButton);
        removeCapabilityButton = new Button("removeCapability");
        removeCapabilityButton.add(new AjaxEventBehavior("onclick") {
            @Override
            protected void onEvent(AjaxRequestTarget target) {
                if (selectedCapability != null) {
                    RefUtils.remove(getElement(), getFullPropertyPath(), selectedCapability);
                    selectedCapability = null;
                    capabilitiesChoice.setModelObject(selectedCapability);
                    target.addComponent(capabilitiesChoice);
                    updateCapabilitySelected(target);
                }
            }
        });
        addReplaceable(removeCapabilityButton);
        capabilityDiv = new WebMarkupContainer("capabilityDiv");
        addReplaceable(capabilityDiv);
        updateCapabilitySelected();
    }

    private Capability getDefaultSelectedCapability() {
        List<Capability> capabilities = (List<Capability>)getProperty();
        if (capabilities.size() > 0) {
            return capabilities.get(0);
        }
        else {
            return null;
        }
    }

    private int getCapabilityIndex() {
        int index = -1;
        if (selectedCapability != null) index = ((List<Capability>)getProperty()).indexOf(selectedCapability);
        return index;
    }

    private void updateCapabilitySelected() {
        if (selectedCapability != null) {
            capabilityPanel = new CapabilityPanel("capability", this, "[" + getCapabilityIndex() + "]");
        }
        else {
            capabilityPanel = new WebMarkupContainer("capability");
        }
        addReplaceableTo(capabilityPanel, capabilityDiv);
        setVisibility(removeCapabilityButton, selectedCapability != null);
        setVisibility(capabilityDiv, selectedCapability != null);
    }

    private void updateCapabilitySelected(AjaxRequestTarget target) {
        updateCapabilitySelected();
        target.addComponent(capabilityPanel);
        target.addComponent(removeCapabilityButton);
        target.addComponent(capabilityDiv);
    }

    @Override
    public void elementChanged( String propPath, AjaxRequestTarget target ) {
        super.elementChanged( propPath, target );
        if ( propPath.matches(
                ".*\\.capabilities.*" ) ) {
            target.addComponent( capabilitiesChoice );
        }
    }

}
