package com.mindalliance.channels.pages.forms.tabs;

import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.util.RefUtils;
import org.apache.wicket.Component;
import org.apache.wicket.MarkupContainer;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.panel.FeedbackPanel;
import org.apache.wicket.model.Model;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 23, 2008
 * Time: 7:43:46 PM
 */
public class AbstractFormTab extends AbstractChannelsPanel {

    protected static final boolean EDITABLE = false;   // not readonly
    protected static final boolean SINGLE_SELECTION = true;

    protected Label readOnlyLabel;
    protected FeedbackPanel feedback;
    protected AbstractElementForm elementForm;
    private static final long serialVersionUID = 3519026609274108987L;

    public AbstractFormTab(String id, AbstractElementForm elementForm) {
        super(id);
        this.elementForm = elementForm;
        load();
        init();
    }

    public FeedbackPanel getFeedback() {
        return feedback;
    }

    public String getFullPropertyPath() {
        return "";
    }


    protected void load() {
        // feedback panel
        String owner = getElement().getOwner();
        String reasonReadOnly;
        if (owner != null) {
           reasonReadOnly = "The element is being edited by " + owner + ". You can not modify it.";
        }
        else {
            reasonReadOnly = "This element can not be changed.";
        }
        readOnlyLabel = new Label("readOnly", new Model<String>(reasonReadOnly));
        setVisibility(readOnlyLabel, getElement().isReadOnly());
        addReplaceable(readOnlyLabel);
        feedback = new FeedbackPanel("feedback");
        feedback.setOutputMarkupId(true);
        addReplaceable(feedback);
    }

    // ElementPanel

    public Object getObject() {
        return elementForm.getObject();
    }

    public Ref getElement() {
        return elementForm.getElement();
    }

    public void elementChanged(String fullPath, AjaxRequestTarget target) {
        elementForm.elementChanged(fullPath, target);
    }

    protected void setProperty(String propPath, Object value) {
        RefUtils.set(getElement(), propPath, value);
    }

    protected Object getProperty(String propPath) {
        return RefUtils.get(getElement(), propPath);
    }

    public AbstractElementForm getTopElementPanel() {
        return elementForm;
    }

    public boolean isReadOnly() {
        return getElement().isReadOnly();
    }

    public void edit(Ref ref, AjaxRequestTarget target) {
        elementForm.edit(ref, target);
    }

    // end ElementPanel

}
