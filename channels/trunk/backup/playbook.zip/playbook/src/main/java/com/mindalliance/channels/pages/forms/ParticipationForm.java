package com.mindalliance.channels.pages.forms;

import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.pages.forms.tabs.participation.ParticipationAboutTab;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.extensions.markup.html.tabs.AbstractTab;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 7, 2008
 * Time: 10:00:12 AM
 */
public class ParticipationForm extends AbstractElementForm {

    public ParticipationForm(String id, Ref element) {
        super(id, element);
    }

    void loadTabs() {
        tabs.add(new AbstractTab(new Model<String>("About participation")) {
            public Panel getPanel(String panelId) {
                return new ParticipationAboutTab(panelId, ParticipationForm.this);
            }
        });
    }

}
