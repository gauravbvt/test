package com.mindalliance.channels.pages.forms.panels.location;

import com.mindalliance.channels.ifm.location.GeoLocation;
import com.mindalliance.channels.ifm.location.Location;
import com.mindalliance.channels.pages.filters.DynamicFilterTree;
import com.mindalliance.channels.pages.filters.Filter;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.location.GeoLocationPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.Model;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Apr 21, 2008
 * Time: 7:32:03 PM
 */
public class LocationPanel extends AbstractComponentPanel {

    Location location;
    AjaxCheckBox isAPlaceCheckBox;
    AjaxCheckBox isAGeoLocationCheckBox;
    WebMarkupContainer placeDiv;
    DynamicFilterTree placeTree;
    WebMarkupContainer geoLocationDiv;
    GeoLocationPanel geoLocationPanel;
    Ref priorPlace;
    GeoLocation priorGeoLocation;

    public LocationPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    @Override
    protected void load() {
        super.load();
        location = (Location)getComponent();
        priorPlace = location.getPlace();
        priorGeoLocation = location.getGeoLocation();
        isAPlaceCheckBox = new AjaxCheckBox("isAPlace", new Model<Boolean>(location.isAPlace())){
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                toggle(isAPlaceCheckBox, isAGeoLocationCheckBox, target);
                updateLocationFlavor(target);
                target.addComponent(geoLocationDiv);
                target.addComponent(placeDiv);
            }
        };
        addReplaceable(isAPlaceCheckBox);
        isAGeoLocationCheckBox = new AjaxCheckBox("isAGeoLocation", new Model<Boolean>(location.isAGeoLocation())){
            @Override
            protected void onUpdate(AjaxRequestTarget target) {
                toggle(isAGeoLocationCheckBox,isAPlaceCheckBox,  target);
                updateLocationFlavor(target);
                target.addComponent(geoLocationDiv);
                target.addComponent(placeDiv);
            }
        };
        addReplaceable(isAGeoLocationCheckBox);
        placeDiv = new WebMarkupContainer("placeDiv");
        addReplaceable(placeDiv);
        replacePlaceTree(null);
        geoLocationDiv = new WebMarkupContainer("geoLocationDiv");
        addReplaceable(geoLocationDiv);
        geoLocationPanel = new GeoLocationPanel("geoLocation", this, "geoLocation");
        addReplaceableTo(geoLocationPanel, geoLocationDiv);
        setVisibility();
    }

    private void updateLocationFlavor(AjaxRequestTarget target) {
        boolean isAPlace = isAPlaceCheckBox.getModelObject();
        if (isAPlace) {
            priorGeoLocation = location.getGeoLocation();
            setProperty("geoLocation", new GeoLocation(), target);
            setProperty("place", priorPlace, target);
            replacePlaceTree(target);
            replaceGeoLocationPanel(target);
        }
        else {
            priorPlace = location.getPlace();
            setProperty("place", null, target);
            setProperty("geoLocation", priorGeoLocation, target);
            replaceGeoLocationPanel(target);
            replacePlaceTree(target);
        }
        setVisibility();
    }

    private void replacePlaceTree(AjaxRequestTarget target) {
        placeTree = new DynamicFilterTree("place", new RefPropertyModel(getElement(), "place"),
                                          new RefPropertyModel(getProject(), "places"), SINGLE_SELECTION) {

            @Override
            public void onFilterSelect(AjaxRequestTarget target, Filter filter) {
                setProperty("place", placeTree.getNewSelection() );
            }
        };
        addReplaceableTo(placeTree, placeDiv);
        if (target != null) target.addComponent(placeDiv);
    }

    private void replaceGeoLocationPanel(AjaxRequestTarget target) {
        geoLocationPanel = new GeoLocationPanel("geoLocation", this, "geoLocation");
        addReplaceableTo(geoLocationPanel, geoLocationDiv);
        target.addComponent(geoLocationDiv);
    }

    private void setVisibility() {
       boolean isAPlace = isAPlaceCheckBox.getModelObject();
        if (isAPlace) {
            display(placeDiv);
            hide(geoLocationDiv);
        }
        else {
            display(geoLocationDiv);
            hide(placeDiv);
        }
    }


}
