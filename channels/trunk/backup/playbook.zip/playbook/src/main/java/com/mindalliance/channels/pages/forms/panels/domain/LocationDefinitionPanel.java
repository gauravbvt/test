package com.mindalliance.channels.pages.forms.panels.domain;

import com.mindalliance.channels.ifm.domain.LocationDefinition;
import com.mindalliance.channels.ifm.location.RelativeLocation;
import com.mindalliance.channels.ifm.location.Location;
import com.mindalliance.channels.ifm.TagSet;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.location.LocationPanel;
import com.mindalliance.channels.pages.forms.panels.location.RelativeLocationPanel;
import com.mindalliance.channels.pages.forms.panels.TagSetsPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.support.models.RefQueryModel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxCheckBox;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.model.Model;
import org.apache.wicket.Component;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 24, 2008
 * Time: 1:10:46 PM
 */
public class LocationDefinitionPanel extends AbstractDefinitionPanel {

    private LocationDefinition locationDefinition;
    private AjaxCheckBox anywhereCheckBox;
    private WebMarkupContainer negatedDiv;
    private AjaxCheckBox negatedCheckBox;
    private WebMarkupContainer locationDefinitionDiv;
    private AjaxCheckBox aPlaceCheckBox;
    private WebMarkupContainer placeTagSetsDiv;
    private Component placeTagSetsPanel;
    private DropDownChoice relationChoice;
    private AjaxCheckBox absoluteCheckBox;
    private AjaxCheckBox relativeCheckBox;
    private AbstractComponentPanel relatedLocationPanel;

    public LocationDefinitionPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    @Override
    protected void load() {
        super.load();
        locationDefinition = (LocationDefinition)getComponent();
        anywhereCheckBox = new AjaxCheckBox("anywhere", new Model<Boolean>(!locationDefinition.isDefined())) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean isAnywhere = anywhereCheckBox.getModelObject();
                if (isAnywhere) {
                    locationDefinition.reset();
                }
                updateVisibilities(target);
            }
        };
        addReplaceable(anywhereCheckBox);
        negatedDiv = new WebMarkupContainer("negatedDiv");
        addReplaceable(negatedDiv);
        negatedCheckBox = new AjaxCheckBox("negated", new RefPropertyModel<Boolean>(getElement(), getPropertyPath("negated"))) {
            protected void onUpdate(AjaxRequestTarget target) {
                updateVisibilities(target);
            }
        };
        addReplaceableTo(negatedCheckBox, negatedDiv);
        locationDefinitionDiv = new WebMarkupContainer("locationDefinitionDiv");
        addReplaceable(locationDefinitionDiv);
        aPlaceCheckBox = new AjaxCheckBox("aPlace", new Model<Boolean>(!locationDefinition.getPlaceTagSets().isEmpty())) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean isAPlace = aPlaceCheckBox.getModelObject();
                if (!isAPlace) {
                    setProperty("placeTagSets", new ArrayList<TagSet>());
                }
                addTagSetsPanel(isAPlace);
                setVisibility(placeTagSetsDiv, isAPlace, target);
            }
        };
        addReplaceableTo(aPlaceCheckBox, locationDefinitionDiv);
        placeTagSetsDiv = new WebMarkupContainer("placeTagSetsDiv");
        setVisibility(placeTagSetsDiv,!locationDefinition.getPlaceTagSets().isEmpty());
        addReplaceableTo(placeTagSetsDiv, locationDefinitionDiv);
        addTagSetsPanel(!locationDefinition.getPlaceTagSets().isEmpty());
        relationChoice = new DropDownChoice<String>("relation", new RefPropertyModel<String>(getElement(), getPropertyPath("relation")),
                                             new Model((Serializable)LocationDefinition.RelationChoices));
        addInputFieldTo(relationChoice, locationDefinitionDiv);
        absoluteCheckBox = new AjaxCheckBox("absolute", new Model<Boolean>(locationDefinition.getAbsoluteLocation().isDefined() || !locationDefinition.getRelativeLocation().isDefined())) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean isAbsolute = absoluteCheckBox.getModelObject();
                relativeCheckBox.setModelObject(!isAbsolute);
                updateRelatedLocationPanel(target);
                target.addComponent(relativeCheckBox);
            }
        };
        addReplaceableTo(absoluteCheckBox, locationDefinitionDiv);
        relativeCheckBox = new AjaxCheckBox("relative", new Model<Boolean>(!locationDefinition.getAbsoluteLocation().isDefined() && locationDefinition.getRelativeLocation().isDefined())) {
            protected void onUpdate(AjaxRequestTarget target) {
                boolean isRelative = relativeCheckBox.getModelObject();
                absoluteCheckBox.setModelObject(!isRelative);
                updateRelatedLocationPanel(target);
                target.addComponent(absoluteCheckBox);
            }
        };
        addReplaceableTo(relativeCheckBox, locationDefinitionDiv);
        addRelatedLocationPanel();
        setVisibilities();
    }

    private void addTagSetsPanel(boolean isAPlace) {
        if (isAPlace) {
            placeTagSetsPanel = new TagSetsPanel("placeTagSets", this, "placeTagSets", new RefQueryModel(getProject(), "findAllPlaceTags"));
        }
        else {
            placeTagSetsPanel = new Label("placeTagSets", new Model<String>(""));
        }
        addReplaceableTo(placeTagSetsPanel, placeTagSetsDiv);

    }

    private void addRelatedLocationPanel() {
        boolean isAbsolute = absoluteCheckBox.getModelObject();
        if (isAbsolute) {
            setProperty("absoluteLocation", new Location());
            relatedLocationPanel = new LocationPanel("relatedLocation", this, "absoluteLocation");
        }
        else {
            setProperty("relativeLocation", new RelativeLocation());
            relatedLocationPanel = new RelativeLocationPanel("relatedLocation", this, "relativeLocation");
        }
        addReplaceableTo(relatedLocationPanel, locationDefinitionDiv);
    }

    private void updateRelatedLocationPanel(AjaxRequestTarget target) {
        addRelatedLocationPanel();
        target.addComponent(relatedLocationPanel);
    }

    private void setVisibilities() {
        boolean isAnywhere = anywhereCheckBox.getModelObject();
        boolean isNegated = negatedCheckBox.getModelObject();
        setVisibility(negatedDiv, isAnywhere);
        setVisibility(locationDefinitionDiv, !isAnywhere || isNegated);
    }

    private void updateVisibilities(AjaxRequestTarget target) {
        setVisibilities();
        target.addComponent(negatedDiv);
        target.addComponent(locationDefinitionDiv);
    }


}
