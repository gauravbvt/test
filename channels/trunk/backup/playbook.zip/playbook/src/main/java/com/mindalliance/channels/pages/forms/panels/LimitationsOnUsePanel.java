package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.domain.AgentSpecificationPanel;
import com.mindalliance.channels.pages.forms.panels.domain.TaskDefinitionPanel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 14, 2008
 * Time: 1:13:15 PM
 */
public class LimitationsOnUsePanel extends AbstractComponentPanel {

    public LimitationsOnUsePanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        TaskDefinitionPanel allowedTaskSpecPanel = new TaskDefinitionPanel("allowedTaskSpec", this, "allowedTaskSpec");
        addReplaceable(allowedTaskSpecPanel);
        AgentSpecificationPanel allowedRecipientPanel = new AgentSpecificationPanel("allowedRecipientSpec", this, "allowedRecipientSpec");
        addReplaceable(allowedRecipientPanel);
    }

}
