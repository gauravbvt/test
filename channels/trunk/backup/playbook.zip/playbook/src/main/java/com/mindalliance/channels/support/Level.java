package com.mindalliance.channels.support;

import java.util.List;
import java.util.ArrayList;
import java.io.Serializable;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Jun 17, 2008
 * Time: 4:05:38 PM
 */
public enum Level implements Serializable {

    NONE, LOW, MEDIUM, HIGH, VERY_HIGH, HIGHEST;

    public String toString() {
        if (this == NONE) return "None";
        else if (this == LOW) return "Low";
        else if (this == MEDIUM) return "Medium";
        else if (this == HIGH) return "High";
        else if (this == VERY_HIGH) return "Very high";
        else return "Highest";
    }

    public String confidence() {
        if (this == NONE) return "No way";
        else if (this == LOW) return "Doubtful";
        else if (this == MEDIUM) return "Somewhat confident";
        else if (this == HIGH) return "Fairly confident";
        else if (this == VERY_HIGH) return "Very confident";
        else return "Certain";
    }

    public Level opposite() {
        if (this == NONE) return HIGHEST;
        else if (this == LOW) return VERY_HIGH;
        else if (this == MEDIUM) return HIGH;
        else if (this == HIGH) return MEDIUM;
        else if (this == VERY_HIGH) return LOW;
        else return NONE;
    }

    static public List<String> valueStrings() {
        List<String> strings = new ArrayList<String>();
        for (Level level : values()) {
            strings.add(level.toString());
        }
        return strings;
    }
    
    static public Level fromString(String s) {
        if (s.equals(NONE.toString())) return NONE;
        else if (s.equals(LOW.toString())) return LOW;
        else if (s.equals(MEDIUM.toString())) return MEDIUM;
        else if (s.equals(HIGH.toString())) return HIGH;
        else if (s.equals(VERY_HIGH.toString())) return VERY_HIGH;
        else if (s.equals(HIGHEST.toString())) return HIGHEST;
        else throw new IllegalArgumentException("Can't convert " + s + " to a level");

    }
    
}
