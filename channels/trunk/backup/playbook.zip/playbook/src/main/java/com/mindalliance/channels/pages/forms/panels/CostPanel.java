package com.mindalliance.channels.pages.forms.panels;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.validation.validator.NumberValidator;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 14, 2008
 * Time: 5:27:55 PM
 */
public class CostPanel extends AbstractComponentPanel {

    public CostPanel(String id, AbstractChannelsPanel parentPanel, String propPath) {
        super(id, parentPanel, propPath);
    }

    protected void load() {
        super.load();
        TextField<Float> costField = new TextField<Float>("cost", new RefPropertyModel<Float>(getComponent(), "value"));
        costField.setType( Float.class );
        costField.add( NumberValidator.minimum( 0.0 ) );
        costField.add( NumberValidator.maximum( 100.0 ) );
        addInputField(costField, "value");  // by giving path, will raise change "event"
    }

}
