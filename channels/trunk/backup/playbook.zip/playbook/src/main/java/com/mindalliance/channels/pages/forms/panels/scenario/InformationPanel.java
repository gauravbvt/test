package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.ifm.information.Information;
import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.EOIsPanel;
import com.mindalliance.channels.pages.forms.panels.LimitationsOnUsePanel;
import com.mindalliance.channels.pages.forms.panels.ReferencePanel;
import com.mindalliance.channels.pages.forms.panels.ReferencesPanel;
import com.mindalliance.channels.support.components.AutoCompleteTextFieldWithChoices;
import com.mindalliance.channels.support.models.RefPropertyModel;
import com.mindalliance.channels.support.models.RefQueryModel;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.html.basic.Label;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved. Proprietary
 * and Confidential.
 * <p/>
 * User: jf Date: May 9, 2008 Time: 2:47:26 PM
 */
public class InformationPanel extends AbstractCommunicationPanel {

    private Information information;
    private ReferencePanel eventPanel;
    private Label baseTagLabel;
    private AutoCompleteTextFieldWithChoices tagField;
    private EOIsPanel eoisPanel;  // content
    private LimitationsOnUsePanel limitationsOnUsePanel;
    private ReferencesPanel sourcesPanel;

    public InformationPanel(
            String id, AbstractChannelsPanel parentPanel, String propPath ) {
        super( id, parentPanel, propPath );
    }

    @Override
    protected void load() {
        super.load();
        information = (Information) getComponent();
        information = (Information)getComponent();
        eventPanel = new ReferencePanel("event", this, "event",
                                        new RefQueryModel(getElement(), "findAllPastEvents"),
                                        "About", ReferencePanel.REQUIRED);
        addReplaceable(eventPanel);
        tagField = new AutoCompleteTextFieldWithChoices("tag",
                                                    new RefPropertyModel<String>(getElement(), getPropertyPath("tag")),
                                                    new RefQueryModel(getScenario(), "findAllInformationTagsForEvent", information.getEvent()));
        addInputField(tagField);
        baseTagLabel = new Label("baseTag", new RefPropertyModel<String>(information, "eventTag"));
        addReplaceable(baseTagLabel);
        eoisPanel = new EOIsPanel("eois", this, "eois", new RefQueryModel(getProject(), "findAllTopicsAbout", information.getEvent()));
        addReplaceable(eoisPanel);
        limitationsOnUsePanel = new LimitationsOnUsePanel("limitationsOnUse", this, "limitationsOnUse");
        addReplaceable(limitationsOnUsePanel);
        sourcesPanel = new ReferencesPanel("sources", this, "sources", new RefQueryModel(getScenario(), "findAllAgentables"));
        addReplaceable(sourcesPanel);
    }

    @Override
    public void elementChanged( String propPath, AjaxRequestTarget target ) {
        super.elementChanged( propPath, target );
        if ( propPath.endsWith(".tag") || propPath.endsWith(".event") ) {
            target.addComponent( eoisPanel );
        }
        if ( propPath.endsWith(".event") ) {
            target.addComponent( tagField );
            target.addComponent(baseTagLabel);
        }
    }
}

