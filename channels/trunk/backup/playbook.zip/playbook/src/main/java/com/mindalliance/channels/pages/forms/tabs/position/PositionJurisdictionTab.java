package com.mindalliance.channels.pages.forms.tabs.position;

import com.mindalliance.channels.pages.forms.tabs.AbstractFormTab;
import com.mindalliance.channels.pages.forms.panels.location.LocationPanel;
import com.mindalliance.channels.pages.forms.AbstractElementForm;
import com.mindalliance.channels.ifm.resource.Position;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 5, 2008
 * Time: 11:01:42 AM
 */
public class PositionJurisdictionTab extends AbstractFormTab {

    protected LocationPanel jurisdictionPanel;

    public PositionJurisdictionTab(String id, AbstractElementForm elementForm) {
        super(id, elementForm);
    }

    protected void load() {
        super.load();
        Position position = (Position)getElement().deref();
        jurisdictionPanel = new LocationPanel("jurisdiction", this, "jurisdiction");
        addReplaceable(jurisdictionPanel);
    }
}
