package com.mindalliance.channels.pages.forms;

import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.pages.forms.tabs.event.EventLocationTab;
import com.mindalliance.channels.pages.forms.tabs.event.EventAboutTab;
import com.mindalliance.channels.pages.forms.tabs.event.EventLiabilitiesTab;
import org.apache.wicket.extensions.markup.html.tabs.AbstractTab;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.panel.Panel;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: May 16, 2008
 * Time: 11:38:34 AM
 */
public class EventForm extends AbstractElementForm {

    public EventForm(String id, Ref element) {
        super(id, element);
    }

    @Override
    void loadTabs() {
        tabs.add(new AbstractTab(new Model<String>("About event")) {
            @Override
            public Panel getPanel(String panelId) {
                return new EventAboutTab(panelId, EventForm.this);
            }
        });
        tabs.add(new AbstractTab(new Model<String>("Location")) {
            @Override
            public Panel getPanel(String panelId) {
                return new EventLocationTab(panelId, EventForm.this);
            }
        });
        tabs.add(new AbstractTab(new Model<String>("Liabilities")) {
            @Override
            public Panel getPanel(String panelId) {
                return new EventLiabilitiesTab(panelId, EventForm.this);
            }
        });
    }
}
