package com.mindalliance.channels.pages.forms.panels.scenario;

import com.mindalliance.channels.pages.forms.AbstractChannelsPanel;
import com.mindalliance.channels.pages.forms.panels.domain.LocationDefinitionPanel;
import com.mindalliance.channels.pages.forms.panels.AbstractComponentPanel;
import com.mindalliance.channels.pages.forms.panels.ProbabilityPanel;
import com.mindalliance.channels.support.models.RefPropertyModel;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.form.CheckBox;

/**
 * Copyright (C) 2008 Mind-Alliance Systems. All Rights Reserved.
 * Proprietary and Confidential.
 * User: jf
 * Date: Oct 17, 2008
 * Time: 9:01:13 PM
 */
public class LocationRequirementPanel extends AbstractComponentPanel {

    boolean actorIsGroup;

    public LocationRequirementPanel(String id, AbstractChannelsPanel parentPanel, String propPath, boolean actorIsGroup) {
        super(id, parentPanel, propPath);
        this.actorIsGroup = actorIsGroup;
        doLoad();
    }

    private void doLoad() {
        WebMarkupContainer allRequiredDiv = new WebMarkupContainer("allRequiredDiv");
        setVisibility(allRequiredDiv, actorIsGroup);
        addReplaceable(allRequiredDiv);
        CheckBox allRequiredCheckBox = new CheckBox("allRequired", new RefPropertyModel<Boolean>(getComponent(), "allRequired"));
        addReplaceableTo(allRequiredCheckBox, allRequiredDiv);
        LocationDefinitionPanel locationSpecPanel = new LocationDefinitionPanel("locationSpec", this, "locationSpec");
        addReplaceable(locationSpecPanel);
        ProbabilityPanel successFactor = new ProbabilityPanel("successFactor", this, "successFactor");
        addReplaceable(successFactor);
    }
}
