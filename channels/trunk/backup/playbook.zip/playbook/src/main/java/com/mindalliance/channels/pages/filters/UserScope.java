package com.mindalliance.channels.pages.filters;

import com.mindalliance.channels.ifm.Channels;
import com.mindalliance.channels.ifm.User;
import com.mindalliance.channels.ifm.ContainedElement;
import com.mindalliance.channels.ifm.scenario.InScenario;
import com.mindalliance.channels.ifm.project.Project;
import com.mindalliance.channels.ref.Ref;
import com.mindalliance.channels.ref.Referenceable;
import com.mindalliance.channels.ref.impl.ReferenceableImpl;
import com.mindalliance.channels.util.ChannelsApplication;
import com.mindalliance.channels.util.ChannelsSession;
import com.mindalliance.channels.support.models.Container;
import com.mindalliance.channels.support.models.ContainerSummary;
import com.mindalliance.channels.support.models.RefModel;
import com.mindalliance.channels.support.persistence.Mappable;
import groovy.lang.MissingPropertyException;
import org.apache.wicket.Session;
import org.apache.wicket.model.IModel;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * Wrapper for all contents accessible by the current user (the object of this
 * model).
 */
public class UserScope implements Container, IModel<User> {

    private transient User user;
    private transient List<Ref> contents;
    private transient ContainerSummary summary;
    private transient List<Class<? extends Referenceable>> allowedClasses;
    private static final long serialVersionUID = 6321041288321505202L;

    public UserScope() {
    }

    @Override
    public String toString() {
        return MessageFormat.format( "{0}''s scope", getUser() );
    }

    //================================
    @SuppressWarnings( { "unchecked" } )
    /**
     * Return default classes a user is allowed to create anytime anywhere
     */
    public synchronized List<Class<? extends Referenceable>> getAllowedClasses() {
        if ( allowedClasses == null ) {
            Collection<Class<? extends Referenceable>> result =
                new TreeSet<Class<? extends Referenceable>>(
                    new Comparator<Class<?>>() {
                        public int compare( Class<?> o1, Class<?> o2 ) {
                            return ContainerSummary
                                    .toDisplay( o1.getSimpleName() )
                                    .compareTo(
                                            ContainerSummary.toDisplay(
                                                    o2.getSimpleName() ) );
                        }
                    } );
            User u = getUser();
            if ( u.getAdmin() )
                result.addAll( Channels.adminClasses() );
            if ( u.getManager() )
                result.addAll( Project.managerClasses() );

            result.addAll( User.contentClasses() );
            allowedClasses =
                new ArrayList<Class<? extends Referenceable>>( result );
        }
        return allowedClasses;
    }

    //================================
    @SuppressWarnings( { "unchecked" } )
    private synchronized List<Ref> getContents() {
        if ( contents == null ) {
            List<Ref> result = new ArrayList<Ref>();
            final Ref uRef = getSession().getUser();
            final User u = (User) uRef.deref();
            Channels channels = Channels.instance();
            if ( u.getAdmin() )
                result.addAll( channels.getUsers() );

            if ( u.getManager() ) {
                for ( Ref pRef : (List<Ref>) getApplication()
                        .findProjectsForUser( uRef ) ) {
                    Project p = (Project) pRef.deref();
                    if ( p != null && p.isManager( uRef ) ) {
                        result.add( pRef );
                        p.addManagerContents( result );
                    }
                    pRef.detach();
                }
            }

            // Add assigned project contents
            for ( Ref pRef : (List<Ref>) getApplication()
                    .findProjectsForUser( uRef ) ) {
                Project project = (Project) pRef.deref();
                if ( project != null )
                    project.addContents( result );
                pRef.detach();
            }

            // Add user tabs
            result.addAll( u.getTabs() );
            uRef.detach();
            contents = result;
        }

        return contents;
    }

    public Ref get( int index ) {
        return getContents().get( index );
    }

    public boolean contains( Ref ref ) {
        return getContents().contains( ref );
    }

    public Iterator<Ref> iterator( int first, int count ) {
        return getContents().subList( first, first + count ).iterator();
    }

    public Iterator<Ref> iterator() {
        return getContents().iterator();
    }

    public int size() {
        return getContents().size();
    }

    public int indexOf( Ref ref ) {
        return getContents().indexOf( ref );
    }

    //================================
    /**
     * Figure out what container to use to add/delete a given object.
     *
     * @param object the object
     * @return the likely container
     */
    private Ref getTarget( Referenceable object ) {
        final Class<? extends Referenceable> objectClass = object.getClass();

        if ( Channels.contentClasses().contains( objectClass ) )
            return Channels.reference();

        final Ref uRef = getSession().getUser();
        if ( uRef != null && User.contentClasses().contains( objectClass ) )
            return uRef;

        if ( object instanceof InScenario) {
            InScenario element = (InScenario) object;
            Ref scRef = element.getScenario();
            Ref pRef = element.getProject();
            if ( pRef == null )
                pRef = getDefaultProject();

            Project p = (Project) pRef.deref();
            if ( p != null && p.findParticipation( uRef ) != null ) {
                if ( scRef == null )
                    scRef = getDefaultScenario( pRef );
                pRef.detach();
                return scRef;
            }
            pRef.detach();
        } else if ( object instanceof ContainedElement && ((ContainedElement)object).isProjectElement()) {
            Ref pRef = ((ContainedElement)object).getProject();
            if ( pRef == null )
                pRef = getDefaultProject();
            return pRef;
        }

        throw new RuntimeException(
                MessageFormat.format(
                        "Unable to add objects of class {0}",
                        objectClass.getName() ) );
    }

    public void add( Referenceable object ) {
        add( getTarget( object ), object );
    }

    public void add( Ref target, Referenceable object ) {
        target.begin();
        try {
            target.add( object );
        } catch ( MissingPropertyException ignored ) {
            // TODO remove this hack
            final ReferenceableImpl ri = (ReferenceableImpl) target.deref();
            ri.doAddToField( object.getType(), object );
        }
        detach();
    }

    public void remove( Referenceable ref ) {
        remove( getTarget( ref ), ref );
    }

    public void remove( Ref target, Referenceable ref ) {
        boolean deleted = false;
        try {// remove AND delete
            target.begin();
            if ( target.isReadWrite() ) {// rw lock acquired?
                if ( ref.getReference().delete() ) {
                    // cascaded delete was successful
                    target.remove( ref );
                    target.commit();
                    deleted = true;
                }
            }
        } catch ( MissingPropertyException e ) {
            // TODO remove this hack
            LoggerFactory.getLogger( this.getClass() )
                    .error( "Missing property on remove: " + e );
            final ReferenceableImpl ri = (ReferenceableImpl) target.deref();
            ri.doRemoveFromField( ref.getType(), ref );
        } finally {
            target.reset();// clean up the begin no matter what
        }
        if ( deleted ) {
            detach();
        } else {
            // TODO -- Alert the user that (cascaded) delete failed because not all locks could be acquired
        }
    }

    public void remove( Ref ref ) {
        remove( ref.deref() );
    }

    public IModel<Ref> model( Ref object ) {
        return new RefModel( object );
    }

    public synchronized void detach() {
        user = null;
        contents = null;
        allowedClasses = null;
        if ( summary != null )
            summary.detach();
    }

    public synchronized ContainerSummary getSummary() {
        if ( summary == null )
            summary = new ContainerSummary( this );

        return summary;
    }

    //================================
    private ChannelsSession getSession() {
        return (ChannelsSession) Session.get();
    }

    private Ref getDefaultProject() {
        return getSession().getProject();
    }

    private Ref getDefaultScenario( Ref projectRef ) {
        if ( projectRef != null ) {
            Project project = (Project) projectRef.deref();
            List pbRefs = project.getScenarios();
            if ( pbRefs.size() > 0 )
                return (Ref) pbRefs.get( 0 );
        }

        return null;
    }

    private ChannelsApplication getApplication() {
        return (ChannelsApplication) getSession().getApplication();
    }

    /**
     * Get the user of this session.
     *
     * @return null when no user is logged in
     */
    public synchronized User getUser() {
        if ( user == null )
            user = (User) getSession().getUser().deref();

        return user;
    }

    //================================
    public User getObject() {
        return getUser();
    }

    public void setObject( User object ) {
        throw new RuntimeException( "Can't set the user of a scope" );
    }

    public Map<String, Object> toMap() {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put( Mappable.CLASS_NAME_KEY, getClass().getName() );
        return map;
    }

    public void initFromMap( Map<String, Object> map ) {
    }

    public Map beanProperties() {// all bean properties are transient
        return new HashMap();
    }
}
